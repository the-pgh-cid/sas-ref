A minimal base layer for starting SAS-to-target conversion projects with Claude AI assistance.

## What It Does

This repository provides a template for converting SAS programs to two data processing frameworks:

- **Target Platforms**: Python, R, or Python/R (combined)
- **Claude Integration**: Pre-configured settings, rules and skills for LLM-assisted conversion
- **Workflow Tools**: Validation, analysis and documentation templates

## Create Repo

### 1. Preview the Setup

Run a dry run to see what will be created:

```bash
./setup_repo/initialize.sh --test
# or
./setup_repo/initialize.sh --smoke
```

This shows where files will be created and what content will be pulled from templates.

### 2. Initialize Your Project

Remove the test flag to create the environment:

```bash
./setup_repo/initialize.sh
```

If you made a mistake, remove the folders it created and retry! It will reproduce it exactly, minus any changes :)


## What Gets Created

- **`.claude/`**: Claude AI configuration folder
  - Contains settings, skills, and rules that guide Claude through SAS conversion
  - Teaches Claude your project's patterns and conversion preferences (reduce variance and increase constraint)

- **`src/`**: Python source code folder
  - Where your converted Python modules will live
  - Organized structure for migrated SAS programs

- **`.venv/`**: Python virtual environment (created if Python is used)
  - Isolated Python packages for this project only
  - Prevents conflicts with other Python projects on your system

- **`.renv/`**: R virtual environment (created if R is chosen)
  - Isolated R packages for this project only
  - Keeps R dependencies separate from your system R installation

- **Conversion templates**: Pre-built structure for your migration workflow
  - Scaffolding for analysis reports, test plans, and validation results
  - Helps maintain consistency across conversions

## Conversion Workflow

1. **Analyze**: Assess SAS code complexity and dependencies
2. **Plan**: Choose target framework based on workload
3. **Convert**: Translate SAS to equivalent code
4. **Validate**: Compare SAS and converted outputs
5. **Document**: Record assumptions and edge cases

## Documentation

See [CLAUDE.md](CLAUDE.md) for detailed conversion approach and key considerations. See [Setup README.md](./.setup_repo/README.md) for initialization details. Checkout SAS Convert Docs for preliminary remapping content for SAS to Python [Polars](./sas_convert_doc/sas_to_polars.md) /[DuckDB](./sas_convert_doc/sas_to_duckdb.md) and [SAS to R](./sas_convert_doc/sas_to_r.md).

## Note

Create a `.claude/settings.local.json` with the contents of [.claude/settings.json](.claude/settings.json). The `.gitignore` ignores **all** files containing `*.local.*` to avoid sharing any details that are unintented.

The MCP file is currently blank. In the future, server information can be provided to enhance access to knowledgebases.