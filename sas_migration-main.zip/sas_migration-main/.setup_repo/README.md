Modular setup scripts for initializing the SAS migration project with Python and/or R environments.

## Quick Start

**Preview changes (recommended first):**
```bash
# view the files and update template files as you see fit (e.g. package lists)
./setup_repo/initialize.sh --smoke
```

**Run setup:**
```bash
./setup_repo/initialize.sh
```

Choose from: Python only, Python + R, or R only.

## Scripts

- **[initialize.sh](initialize.sh)** - Entry, with interactive prompts
- **[setup_python.sh](setup_python.sh)** - Creates venv, installs packages, sets up `src/` structure
- **[setup_r.sh](setup_r.sh)** - Configures renv, installs packages, sets up `R/` structure  (Note: need to refine install and install.packages requirements)
- **[setup_claude.sh](setup_claude.sh)** - Configures Claude Code settings and MCP

## What Gets Created

**Python:**
- `pyproject.toml`, `requirements.txt` (from templates)
- `.venv/` with pandas, polars, pyarrow, etc.
- `src/<name>/` with utils, converters, validators modules (<name> based on prompt)
- `tests/`

**R:**
- `.renv/`, `init_renv.R`
- `R/utils.R`
- tidyverse, haven, data.table, testthat packages

## After Setup

```bash
# Python
source .venv/bin/activate

# R (in R console)
renv::activate()
```
