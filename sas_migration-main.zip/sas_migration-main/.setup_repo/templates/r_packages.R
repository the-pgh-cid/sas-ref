# R Package Definitions for SAS Migration Project
#
# This file defines R packages with specific versions for reproducibility.
# Used by init_renv.R during setup.
#
# Format: list(name = "package_name", version = "x.y.z")
# Set version = NULL to use latest available version

packages_with_versions <- list(
    # ============================================================================
    # SAS File Reading and Data Import
    # ============================================================================
    list(name = "haven", version = "2.5.4"),        # Read SAS, SPSS, Stata files

    # ============================================================================
    # Core Tidyverse - Data Manipulation
    # ============================================================================
    list(name = "dplyr", version = "1.1.4"),        # Data manipulation verbs
    list(name = "tidyr", version = "1.3.1"),        # Data tidying (pivot, separate)
    list(name = "readr", version = "2.1.5"),        # Fast CSV reading
    list(name = "purrr", version = "1.0.2"),        # Functional programming

    # ============================================================================
    # Data Visualization
    # ============================================================================
    list(name = "ggplot2", version = "3.5.1"),      # Grammar of graphics

    # ============================================================================
    # High-Performance Data Manipulation
    # ============================================================================
    list(name = "data.table", version = "1.16.4"),  # Fast data manipulation (alternative to dplyr)

    # ============================================================================
    # String and Date Manipulation
    # ============================================================================
    list(name = "stringr", version = "1.5.1"),      # String manipulation
    list(name = "lubridate", version = "1.9.3"),    # Date/time handling

    # ============================================================================
    # Statistical Analysis (Base R packages - use latest)
    # ============================================================================
    list(name = "MASS", version = NULL),            # Statistical functions
    # list(name = "survival", version = NULL),      # Survival analysis
    # list(name = "nlme", version = NULL),          # Mixed effects models

    # ============================================================================
    # Testing and Development
    # ============================================================================
    list(name = "testthat", version = "3.2.1"),     # Unit testing framework
    # list(name = "devtools", version = NULL),      # Development tools (use latest)
    # list(name = "usethis", version = NULL),       # Project setup helpers

    # ============================================================================
    # Additional Utilities (Uncomment as needed)
    # ============================================================================
    # list(name = "janitor", version = "2.2.0"),    # Data cleaning helpers
    # list(name = "glue", version = "1.8.0"),       # String interpolation
    # list(name = "here", version = "1.0.1"),       # Project-relative paths
    # list(name = "arrow", version = "17.0.0"),     # Apache Arrow/Parquet support
    # list(name = "dbplyr", version = "2.5.0"),     # Database backend for dplyr

    # ============================================================================
    # Report Generation (Uncomment if needed)
    # ============================================================================
    # list(name = "rmarkdown", version = NULL),     # R Markdown documents
    # list(name = "knitr", version = NULL),         # Dynamic report generation

    # ============================================================================
    # Parallel Processing (Uncomment if needed)
    # ============================================================================
    # list(name = "parallel", version = NULL),      # Parallel computation (base R)
    # list(name = "future", version = "1.34.0"),    # Async/parallel framework
    # list(name = "furrr", version = "0.3.1")       # Parallel map functions
)

# Return the list
packages_with_versions
