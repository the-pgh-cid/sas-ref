# Code Style Guide - Combined (Python & R)

This guide covers code style for projects involving both Python and R code.

## Language-Specific Guidelines

For detailed language-specific guidelines, see:
- **Python**: [code-style_python.md](code-style_python.md)
- **R**: [code-style_r.md](code-style_r.md)

## Cross-Language Principles

When working with both Python and R in the same project (e.g., SAS migration supporting both target languages):

### 1. Consistent Naming Across Languages

Both Python and R use `snake_case` for functions and variables:

```python
# Python
def convert_sas_program(input_file: Path) -> dict:
    pass
```

```r
# R
convert_sas_program <- function(input_file) {
  ...
}
```

### 2. Parallel Module/Package Structure

Maintain similar organization in both languages:

```
project/
├── python/
│   ├── sas_migration/
│   │   ├── parsers/
│   │   ├── converters/
│   │   └── utils/
│   └── tests/
└── r/
    ├── R/
    │   ├── parsers.R
    │   ├── converters.R
    │   └── utils.R
    └── tests/testthat/
```

### 3. Consistent Documentation Style

Use similar documentation patterns in both languages:

**Python (Google-style docstrings):**
```python
def convert_proc_sql(sas_code: str, target: str) -> str:
    """Convert SAS PROC SQL to target language.

    Args:
        sas_code: SAS SQL code to convert
        target: Target language ('python' or 'r')

    Returns:
        Converted code as string
    """
```

**R (roxygen2):**
```r
#' Convert SAS PROC SQL to target language
#'
#' @param sas_code SAS SQL code to convert
#' @param target Target language ('python' or 'r')
#'
#' @return Converted code as string
#' @export
convert_proc_sql <- function(sas_code, target) {
  ...
}
```

### 4. Shared Configuration and Data Formats

Use language-agnostic formats for shared resources:

- **Configuration**: YAML or JSON (not language-specific formats)
- **Data exchange**: CSV, Parquet, or JSON
- **Logs**: Structured JSON logging in both languages

```yaml
# config.yaml (shared)
conversion:
  encoding: "UTF-8"
  strip_comments: true
  target_languages:
    - python
    - r
```

### 5. Consistent Error Messages

Use similar error message formats:

```python
# Python
raise ValueError(f"Unsupported SAS statement: {stmt_type}")
```

```r
# R
stop(sprintf("Unsupported SAS statement: %s", stmt_type))
```

### 6. Testing Conventions

Maintain parallel testing approaches:

**Python:**
```python
# tests/unit/test_converter.py
def test_convert_data_step_to_python():
    """Test DATA step conversion to Python."""
    pass

def test_convert_data_step_to_r():
    """Test DATA step conversion to R."""
    pass
```

**R:**
```r
# tests/testthat/test-converter.R
test_that("DATA step converts to Python correctly", {
  result <- convert_data_step(sas_code, target = "python")
  expect_true(is.character(result))
})

test_that("DATA step converts to R correctly", {
  result <- convert_data_step(sas_code, target = "r")
  expect_true(is.character(result))
})
```

### 7. Version Control Conventions

Use consistent commit message format and branch naming:

```
feat(python): add proc freq converter
feat(r): add proc freq converter
fix(converters): handle missing semicolons in both languages
test: add integration tests for python and r outputs
```

### 8. Function Naming for Language-Specific Operations

When implementing parallel functions, use consistent naming:

```python
# Python
def generate_python_imports(modules: list[str]) -> str:
    pass

def generate_r_imports(packages: list[str]) -> str:
    pass
```

```r
# R
generate_python_imports <- function(modules) { }
generate_r_imports <- function(packages) { }
```

### 9. Dataframe Operations

When dealing with dataframe operations (common in SAS migration), use idiomatic approaches per language:

**Python (pandas):**
```python
import pandas as pd

def filter_data(df: pd.DataFrame, condition: str) -> pd.DataFrame:
    """Filter dataframe using pandas query syntax."""
    return df.query(condition)
```

**R (dplyr):**
```r
library(dplyr)

#' Filter dataframe using dplyr syntax
filter_data <- function(df, condition) {
  df |> filter(!!rlang::parse_expr(condition))
}
```

### 10. CLI/API Consistency

If providing command-line tools in both languages, maintain consistent interfaces:

```bash
# Python CLI
sas2py convert input.sas --output output.py --format pandas

# R CLI
sas2r convert input.sas --output output.R --format tidyverse
```

## Project Layout for Dual-Language Projects

```
sas_migration/
├── shared/                 # Language-agnostic resources
│   ├── configs/
│   ├── test_data/
│   └── documentation/
├── python/
│   ├── sas_migration/     # Python package
│   ├── tests/
│   ├── setup.py
│   └── README.md
├── r/
│   ├── R/                 # R package source
│   ├── tests/testthat/
│   ├── DESCRIPTION
│   └── README.md
└── README.md              # Main project README
```

## When to Choose Python vs R

Unless necessary, **prioritize Python** for homogeneity. **Choose R when:**
- Statistical analysis is primary focus
- Working within R/RStudio ecosystem
- Generating reports with R Markdown
- Need specific statistical packages

## Summary

For dual-language projects:
1. **Use `snake_case`** in both languages
2. **Maintain parallel structures** for packages/modules
3. **Keep documentation consistent** in style and content
4. **Use language-agnostic formats** for shared resources
5. **Test both conversion targets** thoroughly
6. **Follow language idioms** within each implementation
