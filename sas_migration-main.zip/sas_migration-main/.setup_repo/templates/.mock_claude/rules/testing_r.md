# Testing Guidelines - R

## Core Principles

1. **Write tests only when explicitly requested** - Avoid creating tests proactively
2. **Never execute tests** - Return runnable test code for the user to execute
3. **Design for external execution** - Tests may run in constrained environments

## When to Write Tests

Write tests **only** when explicitly asked ("write tests", "add test coverage", "test this function").

**Do not** write tests proactively during feature implementation.

**Only execute tests** if they use mocked/fixture data. Otherwise, provide execution instructions:

```r
# To run this test:
testthat::test_file("tests/testthat/test-converter.R")

# To run all tests:
devtools::test()

# Or use R CMD check:
R CMD check --as-cran .
```

## Test Structure

### File Organization

```
tests/
├── testthat/              # testthat test files
│   ├── test-parser.R      # Unit tests for parser
│   ├── test-converter.R   # Unit tests for converter
│   ├── test-integration.R # Integration tests
│   └── helper.R           # Helper functions for tests
├── testthat.R            # testthat entry point
└── fixtures/             # Test data and fixtures
    ├── sas_samples/
    └── expected_outputs/
```

### Naming Conventions

- Test files: `test-<module>.R` (note hyphen, not underscore)
- Test descriptions: Start with verb, describe what's tested
- Helper files: `helper-<purpose>.R` or `setup.R`

```r
# tests/testthat/test-parser.R
test_that("parse_data_step handles valid input correctly", {
  code <- "DATA out; SET in; RUN;"
  result <- parse_data_step(code)
  expect_true(result$is_valid)
})

test_that("parse_data_step raises error on missing semicolon", {
  code <- "DATA out SET in RUN"
  expect_error(parse_data_step(code), "semicolon")
})
```

## Test Patterns

### Unit Tests with testthat

Focus on individual functions:

```r
library(testthat)

test_that("extract_variable_names finds all variables", {
  statement <- "x = y + z;"
  result <- extract_variable_names(statement)
  expect_equal(result, c("x", "y", "z"))
})

test_that("extract_variable_names handles empty input", {
  result <- extract_variable_names("")
  expect_equal(result, character(0))
})

test_that("calculation returns numeric result", {
  result <- calculate_statistic(c(1, 2, 3, 4, 5))
  expect_type(result, "double")
  expect_length(result, 1)
})
```

### Common Expectations

```r
# Equality
expect_equal(object, expected, tolerance = 1e-7)  # Numeric tolerance
expect_identical(object, expected)                 # Exact match

# Type and structure
expect_type(x, "double")
expect_s3_class(df, "data.frame")
expect_length(vec, 5)
expect_named(list, c("a", "b", "c"))

# Logical conditions
expect_true(condition)
expect_false(condition)
expect_null(value)

# Errors and warnings
expect_error(expr, regexp = "error pattern")
expect_warning(expr, regexp = "warning pattern")
expect_message(expr, regexp = "message pattern")
expect_silent(expr)

# Output
expect_output(print(x), "pattern")
expect_snapshot(complex_output())  # For complex output
```

### Integration Tests

Test workflows and component interactions:

```r
test_that("full conversion pipeline works end-to-end", {
  input_file <- test_path("fixtures", "sas_samples", "basic_proc.sas")
  output_file <- withr::local_tempfile(fileext = ".R")

  result <- convert_sas_file(input_file, output_file)

  expect_true(file.exists(output_file))
  expect_s3_class(result, "conversion_result")

  # Check output content
  output_lines <- readLines(output_file)
  expect_true(any(grepl("library\\(dplyr\\)", output_lines)))
})
```

### Fixtures and Test Data

Use fixtures for reusable test data:

```r
# tests/testthat/helper.R (or setup.R)
sample_sas_data_step <- function() {
  "DATA work.output;
    SET work.input;
    IF age > 18;
  RUN;"
}

create_test_dataframe <- function() {
  data.frame(
    id = 1:5,
    value = c("a", "b", "c", "d", "e"),
    stringsAsFactors = FALSE
  )
}

# tests/testthat/test-converter.R
test_that("converter handles DATA step", {
  sas_code <- sample_sas_data_step()
  result <- convert_data_step(sas_code)
  expect_type(result, "character")
})
```

### Using withr for Temporary Resources

```r
test_that("function creates temporary file correctly", {
  # Temporary file automatically cleaned up after test
  temp_file <- withr::local_tempfile(fileext = ".csv")

  write_data(data, temp_file)

  expect_true(file.exists(temp_file))
  result <- read.csv(temp_file)
  expect_equal(nrow(result), 100)
})

test_that("function respects working directory", {
  # Temporary directory automatically restored after test
  withr::local_dir(withr::local_tempdir())

  create_output_files()

  expect_true(file.exists("output.csv"))
})

test_that("function respects options", {
  # Option automatically restored after test
  withr::local_options(list(stringsAsFactors = TRUE))

  result <- process_data()
  expect_true(is.factor(result$category))
})
```

## Handling Data Access Constraints

### Mock External Data Sources

```r
test_that("load_data handles database connection", {
  # Mock database connection
  mockery::stub(
    load_data_from_db,
    'DBI::dbGetQuery',
    data.frame(id = 1:3, value = c("a", "b", "c"))
  )

  result <- load_data_from_db("test_table")
  expect_equal(nrow(result), 3)
})

# Or with testthat's local_mocked_bindings (testthat >= 3.1.0)
test_that("function calls external API", {
  local_mocked_bindings(
    fetch_api_data = function(url) {
      list(status = "ok", data = data.frame(x = 1:5))
    }
  )

  result <- process_api_data("http://example.com/api")
  expect_equal(nrow(result$data), 5)
})
```

### Use Sample Data

```r
test_that("process_large_dataset handles data correctly", {
  # Use small sample instead of full dataset
  sample_data <- data.frame(
    col1 = 1:100,  # Instead of 1M rows
    col2 = rep("value", 100)
  )

  result <- process_dataset(sample_data)
  expect_s3_class(result, "data.frame")
  expect_true(nrow(result) > 0)
})
```

## Test Organization and Markers

### Skip Tests Conditionally

```r
test_that("AWS S3 integration works", {
  skip_if_not(has_aws_credentials(), "AWS credentials not available")

  result <- load_from_s3("s3://bucket/data.csv")
  expect_s3_class(result, "data.frame")
})

test_that("parallel processing works", {
  skip_on_os("windows")  # Skip on Windows
  skip_if_not_installed("parallel")

  result <- parallel_process(data)
  expect_true(length(result) > 0)
})

test_that("feature works with optional dependency", {
  skip_if_not_installed("arrow")

  result <- process_parquet("data.parquet")
  expect_s3_class(result, "data.frame")
})
```

### Test Editions (testthat 3rd edition)

Configure test edition in `tests/testthat.R`:

```r
# tests/testthat.R
library(testthat)
library(yourpackage)

# Use 3rd edition features
testthat::local_edition(3)

test_check("yourpackage")
```

### Snapshot Tests

For complex outputs (plots, formatted text, data structures):

```r
test_that("report generates expected output", {
  report <- generate_summary_report(test_data)
  expect_snapshot(report)
})

test_that("plot creates expected visualization", {
  plt <- create_plot(data)
  vdiffr::expect_doppelganger("summary-plot", plt)
})
```

## Coverage

Use `covr` package to measure test coverage:

```r
# Check coverage for package
covr::package_coverage()

# Interactive coverage report
covr::report()

# Coverage for specific files
covr::file_coverage("R/converter.R", "tests/testthat/test-converter.R")
```

## Performance Testing

Use `bench` package for performance tests:

```r
test_that("conversion performance is acceptable", {
  skip_if_not_installed("bench")

  result <- bench::mark(
    convert_small = convert_sas_file(small_file),
    convert_large = convert_sas_file(large_file),
    iterations = 10
  )

  # Check median time is under threshold
  expect_lt(
    as.numeric(result$median[result$expression == "convert_small"]),
    0.1  # 100ms
  )
})
```

## Assertions and Error Testing

### Testing Errors

```r
test_that("function validates input correctly", {
  expect_error(
    process_data(NULL),
    "data must not be NULL"
  )

  expect_error(
    process_data("not a dataframe"),
    class = "invalid_input_error"
  )
})
```

### Custom Expectations

```r
# Define custom expectation
expect_valid_sas_conversion <- function(object) {
  act <- testthat::quasi_label(rlang::enquo(object), arg = "object")

  is_valid <- inherits(object, "sas_conversion") &&
              !is.null(object$code) &&
              nchar(object$code) > 0

  testthat::expect(
    is_valid,
    sprintf("%s is not a valid SAS conversion", act$lab)
  )

  invisible(act$val)
}

# Use in tests
test_that("conversion produces valid output", {
  result <- convert_sas("DATA x; RUN;")
  expect_valid_sas_conversion(result)
})
```

## Test Configuration

Configure testthat in `tests/testthat.R`:

```r
library(testthat)
library(yourpackage)

# 3rd edition features
local_edition(3)

# Parallel testing (experimental)
# options(testthat.parallel = TRUE)

# Run tests
test_check("yourpackage")
```

## Summary

Key principles for R testing:
1. **Use testthat** as the standard testing framework
2. **Follow `test-*.R` naming** convention
3. **Use descriptive test_that() descriptions**
4. **Leverage withr for temporary resources**
5. **Mock external dependencies** when needed
6. **Skip tests conditionally** with skip_* functions
7. **Measure coverage** with covr package
8. **Use snapshot tests** for complex outputs
