# Code Style Guide - R

## Core Principles

- **Readability**: Clear, idiomatic R code following tidyverse conventions
- **Consistency**: Uniform style across the codebase
- **Documentation**: Clear roxygen2 documentation for all exported functions

## Style Guide

Follow the [tidyverse style guide](https://style.tidyverse.org/) with these key points:

### Naming Conventions

- **Functions**: `snake_case`
- **Variables**: `snake_case`
- **Constants**: `UPPER_SNAKE_CASE`
- **Classes (S3/R6)**: `PascalCase`

```r
# Good
calculate_summary_stats <- function(data, group_var) {
  ...
}

MAX_ITERATIONS <- 1000
user_data <- read_csv("data.csv")

# Bad
CalculateSummaryStats <- function(data, group_var) {  # Wrong case
  ...
}
```

### Function Documentation

Use **roxygen2** for all exported functions:

```r
#' Convert SAS data step to dplyr code
#'
#' Parses a SAS DATA step and generates equivalent dplyr/tidyverse code.
#'
#' @param sas_code Character string containing SAS DATA step code
#' @param output_format Format for output: "script" or "function"
#'
#' @return Character string with R code
#' @export
#'
#' @examples
#' sas_code <- "DATA out; SET in; WHERE age > 18; RUN;"
#' convert_data_step(sas_code)
convert_data_step <- function(sas_code, output_format = "script") {
  # Implementation
}
```

### Documentation Format

```r
#' Short title (one line, ends at period or newline)
#'
#' Longer description providing more detail about what the function does,
#' edge cases, and any important behavior.
#'
#' @param param_name Description of parameter
#' @param another_param Description with details
#'
#' @return Description of return value
#' @export
#'
#' @examples
#' # Example usage
#' result <- my_function(x = 1, y = 2)
```

### Function Design

- Keep functions focused on a single task
- Prefer pure functions (no side effects) when possible
- Use meaningful parameter names
- Return consistent types

```r
# Good - focused, clear purpose
filter_outliers <- function(x, n_sd = 3) {
  mean_x <- mean(x, na.rm = TRUE)
  sd_x <- sd(x, na.rm = TRUE)
  x[abs(x - mean_x) <= n_sd * sd_x]
}

# Bad - doing too much
process_data <- function(file, clean, filter, aggregate, plot, save) {
  # Too many responsibilities
}
```

## Package Structure

Standard R package structure:

```
package/
├── R/              # R source files
│   ├── data.R      # Data documentation
│   ├── utils.R     # Utility functions
│   └── main.R      # Main functions
├── tests/
│   └── testthat/   # Test files
├── man/            # Generated documentation (don't edit manually)
├── vignettes/      # Long-form documentation
├── DESCRIPTION     # Package metadata
└── NAMESPACE       # Generated namespace (don't edit manually)
```

## Tidyverse Conventions

### Pipe Operator

Use the native pipe `|>` (R >= 4.1) or magrittr pipe `%>%`:

```r
# Good
result <- data |>
  filter(age > 18) |>
  select(name, age, score) |>
  arrange(desc(score))

# Also acceptable
result <- data %>%
  filter(age > 18) %>%
  select(name, age, score) %>%
  arrange(desc(score))
```

### Data Manipulation

Prefer tidyverse functions:

```r
# Good - tidyverse
library(dplyr)
library(tidyr)

result <- data |>
  filter(!is.na(value)) |>
  group_by(category) |>
  summarize(
    mean_value = mean(value),
    n = n()
  )

# Avoid - base R for complex operations (tidyverse is clearer)
result <- aggregate(value ~ category,
                   data = data[!is.na(data$value), ],
                   FUN = function(x) c(mean = mean(x), n = length(x)))
```

### Function Arguments

Use clear, descriptive parameter names:

```r
# Good
read_sas_file <- function(file_path, encoding = "UTF-8", strip_comments = TRUE) {
  ...
}

# Bad - unclear abbreviations
read_sas_file <- function(fp, enc = "UTF-8", sc = TRUE) {
  ...
}
```

## Code Organization

### Imports

Be explicit about package dependencies:

```r
# In DESCRIPTION file:
Imports:
    dplyr (>= 1.0.0),
    tidyr (>= 1.1.0),
    stringr (>= 1.4.0)

# In R files, use explicit imports
#' @importFrom dplyr filter select mutate
#' @importFrom tidyr pivot_longer

# Or import entire package if heavily used
#' @import dplyr
```

### Avoid `library()` in Package Code

```r
# Bad - don't use library() in package code
my_function <- function(data) {
  library(dplyr)  # Wrong!
  data |> filter(x > 0)
}

# Good - declare in DESCRIPTION and use ::
my_function <- function(data) {
  dplyr::filter(data, x > 0)
}

# Better - import with roxygen2
#' @importFrom dplyr filter
my_function <- function(data) {
  filter(data, x > 0)
}
```

## Code Quality

### Use Assertions

```r
# Good - validate inputs
process_dataframe <- function(data, id_col) {
  stopifnot(
    is.data.frame(data),
    id_col %in% names(data),
    nrow(data) > 0
  )

  # Process data
}
```

### Handle Missing Values Explicitly

```r
# Good - explicit NA handling
calculate_stats <- function(x, na.rm = TRUE) {
  list(
    mean = mean(x, na.rm = na.rm),
    median = median(x, na.rm = na.rm),
    sd = sd(x, na.rm = na.rm)
  )
}
```

### Avoid Growing Objects in Loops

```r
# Bad - slow, growing vector in loop
result <- c()
for (i in seq_along(values)) {
  result <- c(result, process(values[i]))
}

# Good - preallocate or use vectorization
result <- vector("list", length(values))
for (i in seq_along(values)) {
  result[[i]] <- process(values[i])
}

# Better - vectorize when possible
result <- purrr::map(values, process)
```

## Formatting

### Line Length

- Maximum 80 characters per line
- Break long function calls across lines

```r
# Good
result <- some_function(
  param1 = "value1",
  param2 = "value2",
  param3 = "value3"
)

# Bad
result <- some_function(param1 = "value1", param2 = "value2", param3 = "value3", param4 = "value4")
```

### Spacing

```r
# Good spacing
x <- 5
y <- x + 10
if (x > 0) {
  print(x)
}

# Bad spacing
x<-5
y<-x+10
if(x>0){
  print(x)
}
```

### Use styler Package

Apply consistent formatting with the `styler` package:

```r
# Format a file
styler::style_file("R/my_script.R")

# Format entire package
styler::style_pkg()
```

## Comments

```r
# Use comments to explain WHY, not WHAT

# Good - explains reasoning
# Use 1-based indexing to match SAS behavior
adjusted_index <- r_index + 1

# Bad - obvious from code
# Add 1 to r_index
adjusted_index <- r_index + 1

# Section headers for organizing code
# Data Import ----------------------------------------------------------

# Data Cleaning --------------------------------------------------------

# Analysis -------------------------------------------------------------
```

## Error Handling

```r
# Use specific error messages
validate_input <- function(x) {
  if (!is.numeric(x)) {
    stop("`x` must be numeric, not ", class(x)[1])
  }
  if (length(x) == 0) {
    stop("`x` must have length > 0")
  }
}

# Use rlang for better error messages in packages
validate_input <- function(x) {
  rlang::arg_match(type, c("simple", "complex", "advanced"))
}
```

## Summary

Key principles for R code:
1. **Follow tidyverse style guide**
2. **Use roxygen2 for all exported functions**
3. **Prefer tidyverse over base R for data manipulation**
4. **Be explicit about NA handling**
5. **Use meaningful names (snake_case)**
6. **Keep functions focused and pure**
7. **Document with examples**
