# Testing Guidelines - Combined (Python & R)

This guide covers testing practices for projects involving both Python and R code.

## Language-Specific Guidelines

For detailed language-specific testing guidelines, see:
- **Python**: [testing_python.md](testing_python.md)
- **R**: [testing_r.md](testing_r.md)

## Universal Testing Principles

Regardless of language:

1. **Write tests only when explicitly requested**
2. **Never execute tests automatically** (provide run instructions instead)
3. **Design for external execution** in constrained environments
4. **Test both success and failure cases**
5. **Use descriptive test names**
6. **Keep tests focused and independent**

## Cross-Language Testing Strategy

### Parallel Test Structure

Maintain similar organization in both languages:

```
project/
├── python/
│   ├── sas_migration/
│   └── tests/
│       ├── unit/
│       ├── integration/
│       └── fixtures/
├── r/
│   └── tests/
│       ├── testthat/
│       │   ├── test-unit-*.R
│       │   └── test-integration-*.R
│       └── fixtures/
└── shared_test_data/      # Shared test fixtures
    ├── sas_samples/
    └── expected_outputs/
```

### Shared Test Data

Use language-agnostic formats for test fixtures that both Python and R can read:

```
shared_test_data/
├── sas_samples/
│   ├── basic_data_step.sas
│   ├── proc_sql.sas
│   └── proc_freq.sas
└── expected_outputs/
    ├── python/
    │   ├── basic_data_step.py
    │   └── proc_sql.py
    └── r/
        ├── basic_data_step.R
        └── proc_sql.R
```

## Testing Conversion Output

### Test Both Target Languages

When testing SAS conversion, verify outputs for both Python and R:

**Python:**
```python
import pytest

@pytest.mark.parametrize("target", ["python", "r"])
def test_data_step_conversion(target):
    """Test DATA step conversion to both target languages."""
    sas_code = load_fixture("basic_data_step.sas")

    result = convert_data_step(sas_code, target=target)
    expected = load_expected_output(f"basic_data_step_{target}")

    assert result is not None
    assert target_specific_validation(result, target)
```

**R:**
```r
test_that("DATA step converts to both Python and R", {
  sas_code <- read_fixture("basic_data_step.sas")

  # Test Python output
  py_result <- convert_data_step(sas_code, target = "python")
  py_expected <- read_expected("expected_outputs/python/basic_data_step.py")
  expect_match(py_result, "import pandas", fixed = TRUE)

  # Test R output
  r_result <- convert_data_step(sas_code, target = "r")
  r_expected <- read_expected("expected_outputs/r/basic_data_step.R")
  expect_match(r_result, "library\\(dplyr\\)")
})
```

### Validate Generated Code

Test that generated code is valid syntax:

**Python:**
```python
def test_generated_python_is_valid_syntax():
    """Test that generated Python code can be parsed."""
    sas_code = "DATA out; SET in; x = 1; RUN;"
    result = convert_to_python(sas_code)

    # Verify Python syntax is valid
    try:
        compile(result, '<string>', 'exec')
    except SyntaxError as e:
        pytest.fail(f"Generated invalid Python syntax: {e}")
```

**R:**
```r
test_that("generated R code has valid syntax", {
  sas_code <- "DATA out; SET in; x = 1; RUN;"
  result <- convert_to_r(sas_code)

  # Parse R code to validate syntax
  expect_error(parse(text = result), NA)  # NA means no error expected
})
```

## Integration Testing Across Languages

### Test Data Flow Between Languages

When data needs to flow between Python and R:

```python
# Python test
def test_python_output_readable_by_r(tmp_path):
    """Test that Python-generated data can be read by R."""
    data = pd.DataFrame({'x': [1, 2, 3], 'y': [4, 5, 6]})
    output_file = tmp_path / "data.csv"

    # Write with Python
    data.to_csv(output_file, index=False)

    # Verify R can read it
    r_script = f"""
    data <- read.csv("{output_file}")
    stopifnot(nrow(data) == 3)
    stopifnot(all(names(data) == c("x", "y")))
    """
    subprocess.run(["Rscript", "-e", r_script], check=True)
```

```r
test_that("R output readable by Python", {
  data <- data.frame(x = 1:3, y = 4:6)
  temp_file <- withr::local_tempfile(fileext = ".csv")

  # Write with R
  write.csv(data, temp_file, row.names = FALSE)

  # Verify Python can read it
  py_script <- sprintf('
import pandas as pd
data = pd.read_csv("%s")
assert len(data) == 3
assert list(data.columns) == ["x", "y"]
  ', temp_file)

  system2("python", c("-c", shQuote(py_script)))
})
```

## Test Execution Instructions

### Python

```python
# Add execution instructions at module level or in docstring
"""
To run these tests:

# All tests
pytest tests/

# Specific test file
pytest tests/unit/test_converter.py

# Specific test
pytest tests/unit/test_converter.py::test_convert_data_step

# With coverage
pytest --cov=sas_migration tests/

# Fast tests only (skip slow/integration)
pytest -m "not slow and not integration" tests/
"""
```

### R

```r
# Add execution instructions as comments
# To run these tests:
#
# All tests:
# devtools::test()
#
# Specific file:
# testthat::test_file("tests/testthat/test-converter.R")
#
# With coverage:
# covr::package_coverage()
#
# Skip slow tests:
# devtools::test(filter = "^(?!.*slow).*$")
```

## Continuous Integration Setup

Example GitHub Actions workflow for dual-language testing:

```yaml
name: Tests

on: [push, pull_request]

jobs:
  test-python:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-python@v4
        with:
          python-version: '3.10'
      - run: |
          pip install -e python/
          pip install pytest pytest-cov
          pytest python/tests/ --cov=python/sas_migration

  test-r:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: r-lib/actions/setup-r@v2
      - run: |
          install.packages(c("devtools", "testthat", "covr"))
          devtools::install("r/")
          devtools::test("r/")
        shell: Rscript {0}
```

## Test Markers and Organization

### Python Markers

```python
@pytest.mark.unit          # Fast unit test
@pytest.mark.integration   # Integration test
@pytest.mark.python_target # Tests Python output
@pytest.mark.r_target      # Tests R output
@pytest.mark.slow          # Slow test
@pytest.mark.requires_data # Needs real data
```

### R Tests

```r
# Use descriptive test file names
# test-unit-parser.R
# test-unit-converter.R
# test-integration-pipeline.R
# test-python-output.R
# test-r-output.R

# Use skip conditionally
test_that("Python converter works", {
  skip_on_ci()  # If Python not available in CI
  skip_if_not(python_available())
  ...
})
```

## Coverage Targets

Set consistent coverage goals:

- **Overall**: ≥ 80% coverage
- **Core conversion logic**: ≥ 90% coverage
- **Utility functions**: ≥ 70% coverage

**Python:**
```ini
# .coveragerc or pyproject.toml
[coverage:run]
source = sas_migration
omit = */tests/*

[coverage:report]
fail_under = 80
```

**R:**
```r
# Check coverage and set threshold
cov <- covr::package_coverage()
covr::percent_coverage(cov)  # Should be >= 80
```

## Naming Conventions Across Languages

Keep test names consistent across languages:

**Python:** `test_<function>_<scenario>_<expected>`
```python
def test_convert_data_step_with_where_clause_generates_filter():
    pass
```

**R:** `"<function> <scenario> <expected>"`
```r
test_that("convert_data_step with WHERE clause generates filter", {
  ...
})
```

## Summary

For dual-language testing:

1. **Maintain parallel test structures** in Python and R
2. **Share test fixtures** using language-agnostic formats
3. **Test both conversion targets** (Python and R outputs)
4. **Validate generated code syntax** in both languages
5. **Use consistent naming conventions**
6. **Provide clear execution instructions** for both languages
7. **Set up CI** to test both languages
8. **Maintain consistent coverage targets**
9. **Only write tests when explicitly requested**
10. **Never auto-execute tests** that require real data
