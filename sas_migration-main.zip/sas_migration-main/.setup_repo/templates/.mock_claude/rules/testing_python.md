# Testing Guidelines

## Core Principles

1. **Write tests only when explicitly requested** - Avoid creating tests proactively to prevent unnecessary rewrites
2. **Never execute tests** - Return runnable test code for the user to execute in their environment
3. **Design for external execution** - Tests may need to run in environments with limited data access or specific security constraints

## When to Write and Execute Tests

Write tests **only** explicitly asks for tests ("write tests", "add test coverage", "test this function", "test the error handling")

**Do not** write tests proactively during feature implementation or when the user asks to "check if it works" (provide code review instead)

**Only execute tests automatically.** if they use fake / test data the is mocked via a fixutre. Otherwise, provide the user on how to execute the test:

```python
# To run this test:
pytest tests/test_converter.py::test_convert_basic_sas_program
# Or:
python -m pytest tests/

```

## Test Structure

### File Organization

```
tests/
├── unit/               # Unit tests for individual functions ()
├── integration/        # Integration tests for workflows
├── fixtures/           # Test data and fixtures
│   ├── sas_samples/   # Sample SAS files
│   └── expected/      # Expected outputs
└── conftest.py        # Shared pytest configuration
```

### Naming Conventions

- Test files: `test_<module>.py`
- Test functions: `test_<function>_<scenario>_<expected_result>`
- Test classes: `Test<ClassName>`

```python
# tests/unit/test_parser.py
def test_parse_data_step_with_valid_input_returns_ast():
    """Test DATA step parsing with valid SAS code."""
    pass

def test_parse_data_step_with_missing_semicolon_raises_syntax_error():
    """Test that missing semicolon triggers appropriate error."""
    pass
```

## Test Patterns

### Unit Tests

Focus on individual functions in isolation:

```python
def test_extract_variable_names_from_simple_statement():
    """Test variable extraction from basic assignment."""
    statement = "x = y + z;"
    result = extract_variable_names(statement)
    assert result == ["x", "y", "z"]

def test_extract_variable_names_from_empty_statement():
    """Test empty statement returns empty list."""
    result = extract_variable_names("")
    assert result == []
```

### Integration Tests

Test workflows and component interactions:

```python
def test_full_conversion_pipeline():
    """Test complete SAS to Python conversion workflow."""
    input_file = Path("fixtures/sas_samples/basic_proc.sas")
    output_dir = Path("tmp/output")

    result = convert_sas_file(input_file, output_dir)

    assert result.exists()
    assert result.suffix == ".py"
    # Further assertions on output content
```

### Fixtures

Use fixtures for reusable test data:

```python
# conftest.py
import pytest
from pathlib import Path

@pytest.fixture
def sample_sas_data_step() -> str:
    """Provide sample SAS DATA step code."""
    return """
    DATA work.output;
        SET work.input;
        IF age > 18;
    RUN;
    """

@pytest.fixture
def temp_output_dir(tmp_path) -> Path:
    """Provide temporary output directory."""
    output_dir = tmp_path / "output"
    output_dir.mkdir()
    return output_dir

# tests/test_converter.py
def test_convert_data_step(sample_sas_data_step, temp_output_dir):
    """Test DATA step conversion."""
    result = convert_data_step(sample_sas_data_step, temp_output_dir)
    assert result is not None
```

## Handling Data Access Constraints

Design tests to run in environments with limited data access:

### Mock External Data Sources

```python
from unittest.mock import Mock, patch

def test_load_data_from_database():
    """Test database loading with mocked connection."""
    with patch('module.database.connect') as mock_connect:
        mock_connect.return_value.query.return_value = pd.DataFrame({
            'id': [1, 2, 3],
            'value': ['a', 'b', 'c']
        })

        result = load_data_from_database('test_table')
        assert len(result) == 3
```

### Use Sample Data

```python
def test_process_large_dataset():
    """Test processing with small sample dataset."""
    # Use small representative sample instead of full data
    sample_data = pd.DataFrame({
        'col1': range(100),  # Instead of 1M rows
        'col2': ['value'] * 100
    })

    result = process_dataset(sample_data)
    assert result is not None
```

### Parametrize for Flexibility

```python
@pytest.mark.parametrize("data_source", [
    "fixtures/sample_data.csv",  # Local fixture
    pytest.param("s3://bucket/data.csv", marks=pytest.mark.skip("Requires AWS access"))
])
def test_load_from_various_sources(data_source):
    """Test loading from different data sources."""
    result = load_data(data_source)
    assert result is not None
```


## Test Markers and Decorators for Coverage

**Critical for accurate coverage reporting:** Always use proper decorators to ensure coverage tools can track which tests run, which are skipped, and why.

### Test Categorization Markers

Use markers to categorize tests and enable selective execution:

```python
import pytest

@pytest.mark.unit
def test_parse_simple_statement():
    """Fast unit test."""
    pass

@pytest.mark.integration
def test_full_conversion_pipeline():
    """Integration test requiring multiple components."""
    pass

@pytest.mark.slow
def test_convert_large_file():
    """Test requiring significant time or resources."""
    pass

@pytest.mark.requires_data
def test_with_real_dataset():
    """Test requiring access to actual data sources."""
    pass
```

Register markers in `pytest.ini` or `pyproject.toml`:

```ini
# pytest.ini
[pytest]
markers =
    unit: Fast unit tests
    integration: Integration tests
    slow: Slow-running tests
    requires_data: Tests requiring data access
```

```toml
# pyproject.toml
[tool.pytest.ini_options]
markers = [
    "unit: Fast unit tests",
    "integration: Integration tests",
    "slow: Slow-running tests",
    "requires_data: Tests requiring data access",
]
```

### Skip and Conditional Skip Decorators

Use `@pytest.mark.skip` and `@pytest.mark.skipif` with explicit reasons for accurate coverage tracking:

```python
import sys
import pytest

# Unconditional skip with reason
@pytest.mark.skip(reason="Feature not yet implemented")
def test_future_feature():
    """Test for planned functionality."""
    pass

# Conditional skip based on environment
@pytest.mark.skipif(sys.platform == "win32", reason="Unix-specific test")
def test_unix_file_permissions():
    """Test Unix file permission handling."""
    pass

# Skip if dependency unavailable
@pytest.mark.skipif(
    not HAVE_AWS_ACCESS,
    reason="Requires AWS credentials"
)
def test_s3_data_loading():
    """Test loading data from S3."""
    pass

# Skip entire test class
@pytest.mark.skip(reason="Deprecated module")
class TestLegacyParser:
    """Tests for legacy parser (deprecated)."""

    def test_old_format(self):
        pass
```

### Expected Failure Decorator

Use `@pytest.mark.xfail` for tests that are expected to fail (known bugs, platform issues):

```python
@pytest.mark.xfail(reason="Known bug in upstream library")
def test_edge_case_with_known_bug():
    """Test that triggers known pandas bug."""
    # This test is expected to fail until pandas fixes the issue
    pass

@pytest.mark.xfail(sys.platform == "darwin", reason="macOS threading issue")
def test_concurrent_processing():
    """Test concurrent data processing."""
    pass

# Strict xfail - fail if the test unexpectedly passes
@pytest.mark.xfail(strict=True, reason="Must fail until refactor complete")
def test_old_api_compatibility():
    """Test deprecated API still works."""
    pass
```

### Fixture Scope Decorators

Always specify fixture scope explicitly for proper setup/teardown tracking:

```python
# Function scope (default) - runs for each test
@pytest.fixture(scope="function")
def sample_dataframe() -> pd.DataFrame:
    """Create sample dataframe for each test."""
    return pd.DataFrame({'a': [1, 2, 3]})

# Module scope - runs once per module
@pytest.fixture(scope="module")
def database_connection():
    """Create database connection shared across module tests."""
    conn = create_connection()
    yield conn
    conn.close()

# Session scope - runs once per test session
@pytest.fixture(scope="session")
def test_data_directory(tmp_path_factory) -> Path:
    """Create temporary directory for entire test session."""
    return tmp_path_factory.mktemp("test_data")

# Class scope - runs once per test class
@pytest.fixture(scope="class")
def shared_resource():
    """Resource shared across test class."""
    resource = expensive_setup()
    yield resource
    resource.cleanup()
```

### Parametrize Decorator

Use `@pytest.mark.parametrize` for comprehensive coverage of input variations:

```python
# Basic parametrization
@pytest.mark.parametrize("input_val,expected", [
    (1, 2),
    (5, 6),
    (-1, 0),
])
def test_increment(input_val, expected):
    """Test increment function with various inputs."""
    assert increment(input_val) == expected

# Multiple parameters
@pytest.mark.parametrize("op,a,b,expected", [
    ("add", 2, 3, 5),
    ("subtract", 5, 3, 2),
    ("multiply", 2, 3, 6),
])
def test_operations(op, a, b, expected):
    """Test arithmetic operations."""
    result = calculate(op, a, b)
    assert result == expected

# Parametrize with conditional skip
@pytest.mark.parametrize("format,parser", [
    ("csv", parse_csv),
    ("json", parse_json),
    pytest.param(
        "parquet",
        parse_parquet,
        marks=pytest.mark.skipif(not HAS_PYARROW, reason="Requires pyarrow")
    ),
])
def test_file_formats(format, parser):
    """Test various file format parsers."""
    pass

```


## Assertions

Use clear, specific assertions:

```python
# Good - specific and informative
def test_conversion_output_format():
    """Test output format is correct."""
    result = convert("DATA x; RUN;")
    assert isinstance(result, dict)
    assert "code" in result
    assert result["code"].startswith("import pandas")

# Bad - vague
def test_conversion():
    """Test conversion."""
    result = convert("DATA x; RUN;")
    assert result  # What does this test?
```

## Error Testing

Test both success and failure cases:

```python
def test_parse_valid_syntax_succeeds():
    """Test parsing valid SAS code."""
    code = "DATA work.test; SET work.input; RUN;"
    result = parse_sas(code)
    assert result.is_valid

def test_parse_invalid_syntax_raises_error():
    """Test parsing invalid SAS code raises appropriate error."""
    code = "DATA work.test SET work.input RUN"  # Missing semicolons
    with pytest.raises(SyntaxError) as exc_info:
        parse_sas(code)
    assert "semicolon" in str(exc_info.value).lower()
```
