# Code Style Guide

## Core Principles

- **Simplicity**: Clear, straightforward code that's easy to understand
- **Modularity**: Break code into small, reusable, single-purpose functions and modules
- **Type Safety**: Use type hints for better IDE support and code clarity

## Type Hints

Always provide type hints in function signatures and variable definitions. **Do not duplicate type information in docstrings.**

```python
# Good - types in signature only
def process_data(input_file: Path, limit: int = 100) -> pd.DataFrame:
    """Process input file and return filtered data.

    Args:
        input_file: Path to the input file
        limit: Maximum number of rows to process

    Returns:
        Filtered dataframe
    """
    pass

# Bad - redundant type information in docstring
def process_data(input_file: Path, limit: int = 100) -> pd.DataFrame:
    """Process input file and return filtered data.

    Args:
        input_file (Path): Path to the input file
        limit (int): Maximum number of rows to process

    Returns:
        pd.DataFrame: Filtered dataframe
    """
    pass
```

## Docstrings

Use **Google-style docstrings** with **brief descriptions**.

### Format

```python
"""
Short summary.

Args:
    param1: description
    param2: description

Returns:
    description
"""
```

### Examples

```python
def convert_sas_to_python(sas_file: Path, output_dir: Path) -> Path:
    """Convert SAS file to Python script.

    Args:
        sas_file: Path to SAS source file
        output_dir: Directory for output files

    Returns:
        Path to generated Python file
    """
    pass

def calculate_statistics(df: pd.DataFrame, columns: list[str]) -> dict[str, float]:
    """Calculate summary statistics for specified columns.

    Args:
        df: Input dataframe
        columns: Column names to analyze

    Returns:
        Dictionary mapping column names to mean values
    """
    pass
```

### Rules

- Keep summaries to one line when possible
- Omit docstrings for trivial functions (getters, setters, obvious utilities)
- Concise but clear in parameter and return descriptions

## Function Design

- Functions should do one thing well
- Keep functions short (typically < 50 lines)
- Use descriptive names that indicate purpose
- Limit parameters (prefer < 5 parameters; use dataclasses for complex inputs)

```python
# Good - single purpose, clear name
def filter_outliers(data: pd.Series, threshold: float) -> pd.Series:
    """Remove values beyond threshold standard deviations."""
    return data[abs(data - data.mean()) <= threshold * data.std()]

# Bad - doing too much
def process_and_save_data(file: Path, output: Path, clean: bool,
                          filter: bool, aggregate: bool, format: str):
    """Process data with various options and save."""
    pass
```

## Module Organization

The below is an **example** structure.
```
project/
├── core/           # Core business logic
├── parsers/        # Input parsing (SAS, etc.)
├── converters/     # Conversion logic
├── utils/          # Utility functions
└── tests/          # Test modules mirroring source structure
```

- One class per file (unless tightly coupled)
- Group related functions in modules
- Use `__init__.py` to expose public API
- Keep modules focused on a single responsibility

## Imports

```python
# Standard library
from pathlib import Path
from typing import Any

# Third-party
import pandas as pd
import numpy as np

# Local
from sas_migration.core import Parser
from sas_migration.utils import logger
```

- Group imports: standard library, third-party, local
- Use absolute imports for clarity
- **Avoid** wildcard imports (`from module import *`)

## Naming Conventions

- **Functions/variables**: `snake_case`
- **Classes**: `PascalCase`
- **Constants**: `UPPER_SNAKE_CASE`
- **Private members**: `_leading_underscore`

```python
MAX_RETRIES = 3

class DataProcessor:
    def __init__(self):
        self._cache = {}

    def process_file(self, file_path: Path) -> pd.DataFrame:
        pass
```

## Code Simplicity

### Avoid Nested Logic

```python
# Good - early returns
def validate_input(data: dict) -> bool:
    """Check if input data is valid."""
    if not data:
        return False
    if "required_field" not in data:
        return False
    return True

# Bad - nested conditions
def validate_input(data: dict) -> bool:
    """Check if input data is valid."""
    if data:
        if "required_field" in data:
            return True
    return False
```

### Use Comprehensions

```python
# Good
valid_items = [item for item in items if item.is_valid()]

# Avoid when complex
results = [
    process_complex_logic(item, x, y, z)
    for item in items
    for x in item.children
    if x.condition and y.other_condition
]  # Too complex - use regular loop
```

## Error Handling

```python
# Specific exceptions
def load_config(path: Path) -> dict:
    """Load configuration from file."""
    try:
        return json.loads(path.read_text())
    except FileNotFoundError:
        logger.error(f"Config file not found: {path}")
        raise
    except json.JSONDecodeError as e:
        logger.error(f"Invalid JSON in {path}: {e}")
        raise
```

- Catch specific exceptions, not bare `except:`
- Log errors with context
- Re-raise if you can't handle

## Comments

```python
# Use comments sparingly - code should be self-documenting

# Good - explains WHY
# SAS uses 1-based indexing, Python uses 0-based
adjusted_index = sas_index - 1

# Bad - explains WHAT (obvious from code)
# Increment counter by 1
counter += 1
```

- Explain non-obvious decisions
- Avoid redundant comments
- Update or remove outdated comments


## Modern Python Features

Use modern Python features for clarity:

```python
# Type hints with modern syntax (Python 3.10+)
def process(data: list[str] | None = None) -> dict[str, Any]:
    pass

# Dataclasses for structured data
from dataclasses import dataclass

@dataclass
class ConversionResult:
    input_path: Path
    output_path: Path
    status: str
    errors: list[str]
```

## Formatting

Follow PEP 8 with these specifics:

- Line length: 88 characters (Black default)
- Use Black for consistent formatting
- 2 blank lines between top-level definitions
- 1 blank line between methods

## Summary

Optimize for:
1. **Readability**: Clear over clever
2. **Simplicity**: Straightforward solutions
3. **Modularity**: Small, reusable components
4. **Type Safety**: Explicit types in definitions
5. **Brevity**: Concise docstrings and comments
