---
name: migration-validate
description: Generate comprehensive validation tests for migrated SAS code to ensure behavioral equivalence
---

# Migration Validation

Generate validation tests and reconciliation reports to verify migrated code produces identical results to SAS.

## When to Use

- Migration conversion is complete and needs validation
- Need to create automated test suite
- User asks to "validate", "test", "verify", or "reconcile" migrated code
- Preparing for production deployment

## Required Reading

**Reference materials:**
- [references/validation-layers.md](references/validation-layers.md) - 10 validation layers (what to check)
- [references/test-templates_python.md](references/test-templates_python.md) - Python validation scripts
- [references/test-templates_r.md](references/test-templates_r.md) - R validation scripts

## Workflow

### 1. Understand Migration Context
- Review original SAS program
- Identify complexity patterns (from sas-analyze if available)
- Review target language (Python/R)
- Note semantic traps requiring validation

### 2. Determine Validation Layers Needed
**Select from `validation-layers.md`:**
1. Schema validation
2. Row count validation
3. Key/distinct value validation
4. Null/missing value validation
5. Numeric aggregate validation
6. Row-level (cell-wise) validation
7. Date function edge cases
8. BY-group processing validation
9. LAG/DIF semantics validation
10. Character variable validation

### 3. Generate Validation Scripts
**Create runnable validation scripts using templates:**
- Each layer as standalone .py or .R script
- Load data directly (no fixtures/test functions)
- Print PASS/FAIL with clear details
- Exit with code 0 (pass) or 1 (fail)
- Configure paths at top of each script

### 4. Add Reconciliation Report Generator
**Generate script to:**
- Compare SAS vs. migrated outputs
- Create detailed diff reports
- Flag discrepancies with context
- Export results for review

### 5. Document Validation Requirements
**Include:**
- Test execution instructions
- Expected outputs
- Edge cases covered
- Known limitations

## Rules

### Validate Appropriately
- **Schema → Counts → Aggregates → Cell-wise** (increasing specificity)
- Use appropriate tolerances (floating-point requires tolerance)
- Validate with representative data when possible
- Don't skip edge cases identified in analysis

### Script Configuration
- Put configuration at top (file paths, tolerances, column names)
- Make paths easily adjustable per environment
- Comment what each configuration variable controls
- Provide example values in comments

### Generate Runnable Scripts
- Each script is standalone and executable
- Print clear PASS/FAIL for each check
- Exit with proper status code (0=pass, 1=fail)
- Provide execution instructions at top of file

## Output Structure

### For Python
```
validation/
├── validate_layer1_schema.py
├── validate_layer2_row_counts.py
├── validate_layer3_keys.py
├── validate_layer4_missing_values.py
├── validate_layer5_aggregates.py
├── validate_layer6_cell_wise.py
├── validate_layer7_date_edges.py
├── validate_layer8_by_groups.py
├── validate_layer9_lag_dif.py
├── validate_layer10_char_vars.py
├── generate_reconciliation_report.py
├── run_all_validations.sh
└── fixtures/
    └── sas_outputs/
        └── expected_output.csv
```

### For R
```
validation/
├── validate_layer1_schema.R
├── validate_layer2_row_counts.R
├── validate_layer3_keys.R
├── validate_layer4_missing_values.R
├── validate_layer5_aggregates.R
├── validate_layer6_cell_wise.R
├── validate_layer7_date_edges.R
├── validate_layer8_by_groups.R
├── validate_layer9_lag_dif.R
├── validate_layer10_char_vars.R
├── generate_reconciliation_report.R
├── run_all_validations.sh
└── fixtures/
    └── sas_outputs/
        └── expected_output.csv
```

## Validation Script Guidelines

### Approach
Generate **runnable validation scripts**, not test functions. Each script:
- Loads SAS and migrated outputs directly
- Performs comparisons
- Prints PASS/FAIL with details
- Exits with code 0 (pass) or 1 (fail)

### 1. Schema Validation (Always Include)
```python
# validate_layer1_schema.py
# Load both outputs
sas_output = pl.read_csv("sas_output.csv")
migrated_output = pl.read_parquet("migrated_output.parquet")

# Compare columns
if sas_output.columns == migrated_output.columns:
    print("✓ PASS: Schema matches")
else:
    print("✗ FAIL: Schema mismatch")
    sys.exit(1)
```

### 2. Row Count Validation (Always Include)
```python
# validate_layer2_row_counts.py
# Compare row counts
if len(sas_output) == len(migrated_output):
    print(f"✓ PASS: Row counts match ({len(sas_output)} rows)")
else:
    print(f"✗ FAIL: Row count mismatch")
    sys.exit(1)
```

### 3. Aggregate Validation (Always Include)
```python
# validate_layer5_aggregates.py
for col in numeric_columns:
    sas_sum = sas_output[col].sum()
    migrated_sum = migrated_output[col].sum()
    if abs(sas_sum - migrated_sum) < tolerance:
        print(f"✓ {col} sum matches")
    else:
        print(f"✗ {col} sum mismatch")
```

### 4. Edge Case Tests (Based on Complexity)
```python
# validate_layer7_date_edges.py
# Test month-end dates
test_cases = [(date(2024, 1, 31), date(2024, 2, 29))]
for input_date, expected_date in test_cases:
    result = your_date_function(input_date)
    if result == expected_date:
        print(f"✓ {input_date} handled correctly")
```

### 5. Reconciliation Report
```python
# generate_reconciliation_report.py
report = {
    "timestamp": datetime.now().isoformat(),
    "validation_passed": True,
    "layers": {...}
}
# Write to JSON
with open("reconciliation_report.json", "w") as f:
    json.dump(report, f, indent=2)
```

## Key References

- **Validation layers:** What to validate → [references/validation-layers.md](references/validation-layers.md)
- **Python validation scripts:** Runnable validation code → [references/test-templates_python.md](references/test-templates_python.md)
- **R validation scripts:** Runnable validation code → [references/test-templates_r.md](references/test-templates_r.md)
