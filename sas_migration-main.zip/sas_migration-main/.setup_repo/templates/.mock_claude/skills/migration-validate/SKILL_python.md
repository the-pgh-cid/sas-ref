---
name: migration-validate
description: Generate comprehensive validation tests for migrated SAS code to ensure behavioral equivalence
---

# Migration Validation

Generate validation tests and reconciliation reports to verify migrated code produces identical results to SAS.

## When to Use

- Migration conversion is complete and needs validation
- Need to create automated test suite
- User asks to "validate", "test", "verify", or "reconcile" migrated code
- Preparing for production deployment

## Required Reading

**Reference materials:**
- [references/validation-layers.md](references/validation-layers.md) - 10 validation layers (what to check)
- [references/test-templates_python.md](references/test-templates_python.md) - Python validation scripts


## Workflow

### 1. Understand Migration Context
- Review original SAS program
- Identify complexity patterns (from sas-analyze if available)
- Review target language (Python)
- Note semantic traps requiring validation

### 2. Determine Validation Layers Needed
**Select from `validation-layers.md`:**
1. Schema validation
2. Row count validation
3. Key/distinct value validation
4. Null/missing value validation
5. Numeric aggregate validation
6. Row-level (cell-wise) validation
7. Date function edge cases
8. BY-group processing validation
9. LAG/DIF semantics validation
10. Character variable validation

### 3. Generate Validation Scripts
**Create runnable validation scripts using templates:**
- Each layer as standalone .py script
- Load data directly (no fixtures/test functions)
- Print PASS/FAIL with clear details
- Exit with code 0 (pass) or 1 (fail)
- Configure paths at top of each script

### 4. Add Reconciliation Report Generator
**Generate script to:**
- Compare SAS vs. migrated outputs
- Create detailed diff reports
- Flag discrepancies with context
- Export results for review

### 5. Document Validation Requirements
**Include:**
- Test execution instructions
- Expected outputs
- Edge cases covered
- Known limitations

## Rules

### Validate Appropriately
- **Schema → Counts → Aggregates → Cell-wise** (increasing specificity)
- Use appropriate tolerances (floating-point requires tolerance)
- Validate with representative data when possible
- Don't skip edge cases identified in analysis

### Script Configuration
- Put configuration at top (file paths, tolerances, column names)
- Make paths easily adjustable per environment
- Comment what each configuration variable controls
- Provide example values in comments

### Generate Runnable Scripts
- Each script is standalone and executable
- Print clear PASS/FAIL for each check
- Exit with proper status code (0=pass, 1=fail)
- Provide execution instructions at top of file

## Output Structure

### For Python
```
validation/
├── validate_layer1_schema.py
├── validate_layer2_row_counts.py
├── validate_layer3_keys.py
├── validate_layer4_missing_values.py
├── validate_layer5_aggregates.py
├── validate_layer6_cell_wise.py
├── validate_layer7_date_edges.py
├── validate_layer8_by_groups.py
├── validate_layer9_lag_dif.py
├── validate_layer10_char_vars.py
├── generate_reconciliation_report.py
├── run_all_validations.sh
└── fixtures/
    └── sas_outputs/
        └── expected_output.csv
```


## Validation Script Guidelines

### Approach
Generate **runnable validation scripts**, not test functions. Each script:
- Loads SAS and migrated outputs directly
- Performs comparisons
- Prints PASS/FAIL with details
- Exits with code 0 (pass) or 1 (fail)

### 1. Schema Validation (Always Include)
```python
# validate_layer1_schema.py
import polars as pl
import sys

# Scan datasets (lazy - no data loaded yet)
sas_output = pl.scan_csv("sas_output.csv")
migrated_output = pl.scan_parquet("migrated_output.parquet")

# Compare columns (still lazy)
if sas_output.columns == migrated_output.columns:
    print("✓ PASS: Schema matches")
else:
    print("✗ FAIL: Schema mismatch")
    sys.exit(1) # exit and do not proceed.
```

### 2. Row Count Validation (Always Include)
```python
# validate_layer2_row_counts.py
import polars as pl
# import sys

# Scan datasets (lazy)
sas_output = pl.scan_csv("sas_output.csv")
migrated_output = pl.scan_parquet("migrated_output.parquet")

# Count rows (lazy aggregation, only materialized on collect)
sas_count = sas_output.select(pl.count()).collect().item()
migrated_count = migrated_output.select(pl.count()).collect().item()

# Compare row counts
if sas_count == migrated_count:
    print(f"✓ PASS: Row counts match ({sas_count} rows)")
else:
    print(f"✗ FAIL: Row count mismatch")
    # sys.exit(1) # exit and do not proceed
```

### 3. Aggregate Validation (Always Include)
```python
# validate_layer5_aggregates.py
import polars as pl

# Scan datasets (lazy)
sas_output = pl.scan_csv("sas_output.csv")
migrated_output = pl.scan_parquet("migrated_output.parquet")

tolerance = 1e-6
numeric_columns = ["col1", "col2", "col3"]

for col in numeric_columns:
    # Lazy aggregation - only computed on collect()
    sas_sum = sas_output.select(pl.col(col).sum()).collect().item()
    migrated_sum = migrated_output.select(pl.col(col).sum()).collect().item()

    if abs(sas_sum - migrated_sum) < tolerance:
        print(f"✓ {col} sum matches")
    else:
        print(f"✗ {col} sum mismatch")
```

### 4. Edge Case Tests (Based on Complexity)
```python
# validate_layer7_date_edges.py
import polars as pl
from datetime import date

# Scan datasets (lazy) and filter to edge cases
sas_output = pl.scan_csv("sas_output.csv")
migrated_output = pl.scan_parquet("migrated_output.parquet")

# Compare date columns on edge cases (lazy until collect)
edge_dates = [date(2024, 1, 31), date(2024, 2, 29), date(2024, 12, 31)]
sas_edges = sas_output.filter(pl.col("date_col").is_in(edge_dates)).collect()
migrated_edges = migrated_output.filter(pl.col("date_col").is_in(edge_dates)).collect()

# Compare results
if sas_edges.equals(migrated_edges):
    print("✓ Date edge cases handled correctly")
else:
    print("✗ Date edge case mismatch")
```

### 5. Reconciliation Report
```python
# generate_reconciliation_report.py
import json
from datetime import datetime

report = {
    "timestamp": datetime.now().isoformat(),
    "validation_passed": True,
    "layers": {}
}
# Write to JSON
with open("reconciliation_report.json", "w") as f:
    json.dump(report, f, indent=2)
```

## Key References

- **Validation layers:** What to validate → [references/validation-layers.md](references/validation-layers.md)
- **Python validation scripts:** Runnable validation code → [references/test-templates_python.md](references/test-templates_python.md)
