# Validation Scripts for Python Migration

Runnable validation code chunks for comparing SAS output with migrated Python output.

## Key Feature: Lazy Loading with Polars

**These scripts use lazy evaluation** for memory efficiency with large datasets:
- **Schema checks**: Read schema without loading data
- **Row counts**: Compute counts without materializing full dataset
- **Aggregates**: Compute statistics in single pass, only selected columns
- **Group operations**: Process by group without loading entire dataset
- **Cell-wise**: Requires eager loading for full comparison


## Usage

Each validation layer is a standalone Python script that:
1. Scans SAS reference output and migrated Python output (lazy)
2. Performs comparisons for that layer
3. Reports PASS/FAIL with details
4. Exits with code 0 (pass) or 1 (fail)

Run validation scripts directly:
```bash
python validate_layer1_schema.py
python validate_layer2_row_counts.py
# etc.
```

---

## Configuration

Create a config at the top of each validation script:

```python
# Configuration
SAS_OUTPUT_PATH = "tests/fixtures/sas_outputs/expected_output.csv"
MIGRATED_OUTPUT_PATH = "output/migrated_output.parquet"
TOLERANCE = 1e-8  # Floating-point tolerance

# Use lazy loading for efficiency with large datasets
USE_LAZY = True  # Set False for small datasets or cell-wise validation
```

## Lazy vs Eager Loading

**Lazy loading** (recommended for large datasets):
- Use `pl.scan_parquet()` / `pl.scan_csv()`
- Only materialize data when needed via `.collect()`
- More memory efficient
- Layers 1-5, 7-9: Use lazy evaluation

**Eager loading** (for small datasets or full scans):
- Use `pl.read_parquet()` / `pl.read_csv()`
- Layer 6 (cell-wise): Requires eager for full comparison
- Layer 10 (char vars): May need eager for string operations

---

## Layer 1: Schema Validation

**File:** `validate_layer1_schema.py`

```python
#!/usr/bin/env python3
"""Validate schema matches between SAS and migrated output."""

import sys
import polars as pl
from pathlib import Path

# Configuration
SAS_OUTPUT_PATH = "tests/fixtures/sas_outputs/expected_output.csv"
MIGRATED_OUTPUT_PATH = "output/migrated_output.parquet"

def main():
    """Run schema validation."""
    print("=" * 60)
    print("Layer 1: Schema Validation")
    print("=" * 60)

    # Use lazy loading - only reads schema, not data
    print(f"\nScanning SAS output: {SAS_OUTPUT_PATH}")
    sas_lazy = pl.scan_csv(SAS_OUTPUT_PATH)

    print(f"Scanning migrated output: {MIGRATED_OUTPUT_PATH}")
    migrated_lazy = pl.scan_parquet(MIGRATED_OUTPUT_PATH)

    # Get schemas without loading data
    sas_schema = sas_lazy.schema
    migrated_schema = migrated_lazy.schema

    failed = False

    # Check column names
    print("\n--- Column Names ---")
    sas_cols = list(sas_schema.keys())
    migrated_cols = list(migrated_schema.keys())

    if sas_cols == migrated_cols:
        print(f"✓ PASS: Column names match ({len(sas_cols)} columns)")
    else:
        print("✗ FAIL: Column name mismatch")
        missing = set(sas_cols) - set(migrated_cols)
        extra = set(migrated_cols) - set(sas_cols)
        if missing:
            print(f"  Missing columns: {sorted(missing)}")
        if extra:
            print(f"  Extra columns: {sorted(extra)}")
        failed = True

    # Check data types
    print("\n--- Data Types ---")
    type_mismatches = []
    for col in sas_cols:
        if col in migrated_schema:
            sas_type = str(sas_schema[col])
            migrated_type = str(migrated_schema[col])
            if sas_type != migrated_type:
                type_mismatches.append((col, sas_type, migrated_type))

    if not type_mismatches:
        print("✓ PASS: All data types match")
    else:
        print("✗ FAIL: Data type mismatches found:")
        for col, sas_type, migrated_type in type_mismatches:
            print(f"  {col}: {sas_type} (SAS) vs {migrated_type} (migrated)")
        failed = True

    # Summary
    print("\n" + "=" * 60)
    if failed:
        print("RESULT: FAILED")
        sys.exit(1)
    else:
        print("RESULT: PASSED")
        sys.exit(0)

if __name__ == "__main__":
    main()
```

---

## Layer 2: Row Count Validation

**File:** `validate_layer2_row_counts.py`

```python
#!/usr/bin/env python3
"""Validate row counts match between SAS and migrated output."""

import sys
import polars as pl

# Configuration
SAS_OUTPUT_PATH = "tests/fixtures/sas_outputs/expected_output.csv"
MIGRATED_OUTPUT_PATH = "output/migrated_output.parquet"
GROUP_BY_COLUMN = "category"  # Adjust based on your data

def main():
    """Run row count validation."""
    print("=" * 60)
    print("Layer 2: Row Count Validation")
    print("=" * 60)

    # Use lazy loading - only compute counts, don't load data
    sas_lazy = pl.scan_csv(SAS_OUTPUT_PATH)
    migrated_lazy = pl.scan_parquet(MIGRATED_OUTPUT_PATH)

    failed = False

    # Overall row count - lazy evaluation
    print("\n--- Overall Row Count ---")
    sas_count = sas_lazy.select(pl.count()).collect().item()
    migrated_count = migrated_lazy.select(pl.count()).collect().item()

    if sas_count == migrated_count:
        print(f"✓ PASS: Row counts match ({sas_count} rows)")
    else:
        print(f"✗ FAIL: Row count mismatch")
        print(f"  SAS output: {sas_count} rows")
        print(f"  Migrated output: {migrated_count} rows")
        print(f"  Difference: {migrated_count - sas_count:+d} rows")
        failed = True

    # Group-level row counts (if applicable) - lazy evaluation
    if GROUP_BY_COLUMN in sas_lazy.schema:
        print(f"\n--- Row Counts by {GROUP_BY_COLUMN} ---")
        sas_groups = (sas_lazy
                      .group_by(GROUP_BY_COLUMN)
                      .agg(pl.count().alias("sas_count"))
                      .sort(GROUP_BY_COLUMN)
                      .collect())

        migrated_groups = (migrated_lazy
                          .group_by(GROUP_BY_COLUMN)
                          .agg(pl.count().alias("migrated_count"))
                          .sort(GROUP_BY_COLUMN)
                          .collect())

        # Join to compare (already collected, so this is eager)
        comparison = sas_groups.join(migrated_groups, on=GROUP_BY_COLUMN, how="outer")

        # Check for mismatches
        mismatches = comparison.filter(
            pl.col("sas_count") != pl.col("migrated_count")
        )

        if len(mismatches) == 0:
            print(f"✓ PASS: All group row counts match ({len(sas_groups)} groups)")
        else:
            print(f"✗ FAIL: Group row count mismatches ({len(mismatches)} groups)")
            print("\nMismatched groups:")
            print(mismatches)
            failed = True

    # Summary
    print("\n" + "=" * 60)
    if failed:
        print("RESULT: FAILED")
        sys.exit(1)
    else:
        print("RESULT: PASSED")
        sys.exit(0)

if __name__ == "__main__":
    main()
```

---

## Layer 3: Key Validation

**File:** `validate_layer3_keys.py`

```python
#!/usr/bin/env python3
"""Validate distinct key values match between outputs."""

import sys
import polars as pl

# Configuration
SAS_OUTPUT_PATH = "tests/fixtures/sas_outputs/expected_output.csv"
MIGRATED_OUTPUT_PATH = "output/migrated_output.parquet"
KEY_COLUMNS = ["customer_id"]  # Adjust to your keys

def main():
    """Run key validation."""
    print("=" * 60)
    print("Layer 3: Key Validation")
    print("=" * 60)

    # Use lazy loading - only select and collect key columns
    sas_lazy = pl.scan_csv(SAS_OUTPUT_PATH)
    migrated_lazy = pl.scan_parquet(MIGRATED_OUTPUT_PATH)

    failed = False

    for key_col in KEY_COLUMNS:
        print(f"\n--- Distinct Values: {key_col} ---")

        # Only select the key column and get unique values
        sas_keys = set(
            sas_lazy.select(pl.col(key_col)).unique().collect()[key_col].to_list()
        )
        migrated_keys = set(
            migrated_lazy.select(pl.col(key_col)).unique().collect()[key_col].to_list()
        )

        missing = sas_keys - migrated_keys
        extra = migrated_keys - sas_keys

        if not missing and not extra:
            print(f"✓ PASS: All distinct values match ({len(sas_keys)} unique values)")
        else:
            print(f"✗ FAIL: Distinct value mismatch")
            if missing:
                print(f"  Missing in migrated: {sorted(list(missing)[:10])}")
                if len(missing) > 10:
                    print(f"  ... and {len(missing) - 10} more")
            if extra:
                print(f"  Extra in migrated: {sorted(list(extra)[:10])}")
                if len(extra) > 10:
                    print(f"  ... and {len(extra) - 10} more")
            failed = True

    # Summary
    print("\n" + "=" * 60)
    if failed:
        print("RESULT: FAILED")
        sys.exit(1)
    else:
        print("RESULT: PASSED")
        sys.exit(0)

if __name__ == "__main__":
    main()
```

---

## Layer 4: Missing Value Validation

**File:** `validate_layer4_missing_values.py`

```python
#!/usr/bin/env python3
"""Validate missing value counts match between outputs."""

import sys
import polars as pl

# Configuration
SAS_OUTPUT_PATH = "tests/fixtures/sas_outputs/expected_output.csv"
MIGRATED_OUTPUT_PATH = "output/migrated_output.parquet"

def main():
    """Run missing value validation."""
    print("=" * 60)
    print("Layer 4: Missing Value Validation")
    print("=" * 60)

    # Use lazy loading - compute null counts without loading full data
    sas_lazy = pl.scan_csv(SAS_OUTPUT_PATH)
    migrated_lazy = pl.scan_parquet(MIGRATED_OUTPUT_PATH)

    failed = False

    print("\n--- Null Counts by Column ---")

    # Get null counts for all columns in one pass
    sas_nulls_df = sas_lazy.select([
        pl.col(col).null_count().alias(col) for col in sas_lazy.schema.keys()
    ]).collect()

    migrated_nulls_df = migrated_lazy.select([
        pl.col(col).null_count().alias(col) for col in migrated_lazy.schema.keys()
    ]).collect()

    for col in sas_lazy.schema.keys():
        if col not in migrated_lazy.schema:
            continue

        sas_nulls = sas_nulls_df[col].item()
        migrated_nulls = migrated_nulls_df[col].item()

        if sas_nulls == migrated_nulls:
            print(f"✓ {col}: {sas_nulls} nulls")
        else:
            print(f"✗ {col}: MISMATCH")
            print(f"    SAS: {sas_nulls} nulls")
            print(f"    Migrated: {migrated_nulls} nulls")
            failed = True

    # Summary
    print("\n" + "=" * 60)
    if failed:
        print("RESULT: FAILED")
        sys.exit(1)
    else:
        print("RESULT: PASSED")
        sys.exit(0)

if __name__ == "__main__":
    main()
```

---

## Layer 5: Aggregate Validation

**File:** `validate_layer5_aggregates.py`

```python
#!/usr/bin/env python3
"""Validate numeric aggregates match between outputs."""

import sys
import polars as pl

# Configuration
SAS_OUTPUT_PATH = "tests/fixtures/sas_outputs/expected_output.csv"
MIGRATED_OUTPUT_PATH = "output/migrated_output.parquet"
TOLERANCE = 1e-8
NUMERIC_COLUMNS = ["amount", "quantity", "price"]  # Adjust to your data

def main():
    """Run aggregate validation."""
    print("=" * 60)
    print("Layer 5: Aggregate Validation")
    print("=" * 60)

    # Use lazy loading - compute all aggregates in a single pass
    sas_lazy = pl.scan_csv(SAS_OUTPUT_PATH)
    migrated_lazy = pl.scan_parquet(MIGRATED_OUTPUT_PATH)

    failed = False

    # Filter to only numeric columns that exist in both
    valid_cols = [
        col for col in NUMERIC_COLUMNS
        if col in sas_lazy.schema and col in migrated_lazy.schema
    ]

    if not valid_cols:
        print("\n⚠ No valid numeric columns to check")
        sys.exit(0)

    # Compute all aggregates in one pass for efficiency
    print("\nComputing aggregates...")
    sas_aggs = sas_lazy.select([
        pl.col(col).sum().alias(f"{col}_sum"),
        pl.col(col).mean().alias(f"{col}_mean"),
        pl.col(col).std().alias(f"{col}_std")
        for col in valid_cols
    ]).collect()

    migrated_aggs = migrated_lazy.select([
        pl.col(col).sum().alias(f"{col}_sum"),
        pl.col(col).mean().alias(f"{col}_mean"),
        pl.col(col).std().alias(f"{col}_std")
        for col in valid_cols
    ]).collect()

    # Compare aggregates
    for col in valid_cols:
        print(f"\n--- {col} ---")

        # Sum
        sas_sum = sas_aggs[f"{col}_sum"].item()
        migrated_sum = migrated_aggs[f"{col}_sum"].item()
        diff = abs(sas_sum - migrated_sum)

        if diff < TOLERANCE:
            print(f"✓ Sum: {migrated_sum:.4f} (diff: {diff:.2e})")
        else:
            print(f"✗ Sum: MISMATCH")
            print(f"    SAS: {sas_sum:.4f}")
            print(f"    Migrated: {migrated_sum:.4f}")
            print(f"    Diff: {diff:.2e}")
            failed = True

        # Mean
        sas_mean = sas_aggs[f"{col}_mean"].item()
        migrated_mean = migrated_aggs[f"{col}_mean"].item()
        diff = abs(sas_mean - migrated_mean)

        if diff < TOLERANCE:
            print(f"✓ Mean: {migrated_mean:.4f} (diff: {diff:.2e})")
        else:
            print(f"✗ Mean: MISMATCH")
            print(f"    SAS: {sas_mean:.4f}")
            print(f"    Migrated: {migrated_mean:.4f}")
            print(f"    Diff: {diff:.2e}")
            failed = True

        # Std
        sas_std = sas_aggs[f"{col}_std"].item()
        migrated_std = migrated_aggs[f"{col}_std"].item()
        diff = abs(sas_std - migrated_std)

        if diff < TOLERANCE:
            print(f"✓ Std: {migrated_std:.4f} (diff: {diff:.2e})")
        else:
            print(f"✗ Std: MISMATCH")
            print(f"    SAS: {sas_std:.4f}")
            print(f"    Migrated: {migrated_std:.4f}")
            print(f"    Diff: {diff:.2e}")
            failed = True

    # Summary
    print("\n" + "=" * 60)
    if failed:
        print("RESULT: FAILED")
        sys.exit(1)
    else:
        print("RESULT: PASSED")
        sys.exit(0)

if __name__ == "__main__":
    main()
```

---

## Layer 6: Cell-Wise Validation

**File:** `validate_layer6_cell_wise.py`

```python
#!/usr/bin/env python3
"""Validate cell-by-cell accuracy between outputs."""

import sys
import polars as pl

# Configuration
SAS_OUTPUT_PATH = "tests/fixtures/sas_outputs/expected_output.csv"
MIGRATED_OUTPUT_PATH = "output/migrated_output.parquet"
TOLERANCE = 1e-8
SORT_KEYS = ["customer_id", "date"]  # Adjust to your keys; if the row counts differ, cell-values will **always** have failures

def main():
    """Run cell-wise validation."""
    print("=" * 60)
    print("Layer 6: Cell-Wise Validation")
    print("=" * 60)
    print("\n  WARNING: This is a comprehensive check. May take time for large datasets.")
    print(" NOTE: Uses eager loading - full dataset loaded into memory.\n")

    # Cell-wise comparison requires eager loading
    sas_output = pl.read_csv(SAS_OUTPUT_PATH)
    migrated_output = pl.read_parquet(MIGRATED_OUTPUT_PATH)

    # Sort both by keys
    print(f"Sorting by: {SORT_KEYS}")
    sas_sorted = sas_output.sort(SORT_KEYS)
    migrated_sorted = migrated_output.sort(SORT_KEYS)

    failed = False

    for col in sas_sorted.columns:
        if col not in migrated_sorted.columns:
            continue

        print(f"\n--- {col} ---")

        sas_col = sas_sorted[col]
        migrated_col = migrated_sorted[col]

        # Check if numeric
        if sas_col.dtype in [pl.Float64, pl.Float32, pl.Int64, pl.Int32]:
            # Numeric comparison with tolerance
            diff = (sas_col - migrated_col).abs()
            max_diff = diff.max()

            if max_diff < TOLERANCE:
                print(f"✓ PASS: All cells match (max diff: {max_diff:.2e})")
            else:
                mismatch_count = (diff >= TOLERANCE).sum()
                print(f"✗ FAIL: {mismatch_count} cells differ")
                print(f"    Max diff: {max_diff:.4f}")

                # Show first few mismatches
                mismatches = diff.arg_sort(descending=True).head(5)
                print(f"    Worst mismatches (row indices): {mismatches.to_list()}")
                failed = True
        else:
            # Exact comparison for non-numeric
            mismatches = (sas_col != migrated_col).sum()

            if mismatches == 0:
                print(f"✓ PASS: All cells match exactly")
            else:
                print(f"✗ FAIL: {mismatches} cells differ")

                # Show first few mismatches
                mismatch_mask = sas_col != migrated_col
                mismatch_indices = mismatch_mask.arg_true().head(5)
                print(f"    First mismatches (row indices): {mismatch_indices.to_list()}")
                failed = True

    # Summary
    print("\n" + "=" * 60)
    if failed:
        print("RESULT: FAILED")
        sys.exit(1)
    else:
        print("RESULT: PASSED - Complete cell-wise match")
        sys.exit(0)

if __name__ == "__main__":
    main()
```

---

## Layer 7: Date Edge Cases

**File:** `validate_layer7_date_edges.py`

```python
#!/usr/bin/env python3
"""Validate date function edge cases match SAS behavior."""

import sys
import polars as pl
from datetime import date

# Configuration
# For edge cases, you might not compare against SAS output
# but rather verify expected behavior with test cases

def main():
    """Run date edge case validation."""
    print("=" * 60)
    print("Layer 7: Date Edge Case Validation")
    print("=" * 60)

    failed = False

    # Test month-end handling
    print("\n--- Month-End Date Handling ---")

    # Example: Test INTNX-like behavior
    # Jan 31 + 1 month should give Feb 28/29
    test_cases = [
        (date(2024, 1, 31), date(2024, 2, 29)),  # Leap year
        (date(2023, 1, 31), date(2023, 2, 28)),  # Non-leap year
        (date(2024, 3, 31), date(2024, 4, 30)),  # 31 -> 30 day month
    ]

    for input_date, expected_date in test_cases:
        # Call your migrated date logic here
        # result_date = your_add_month_function(input_date)

        # For demonstration:
        result_date = expected_date  # Replace with actual call

        if result_date == expected_date:
            print(f"✓ {input_date} + 1 month = {result_date}")
        else:
            print(f"✗ {input_date} + 1 month = {result_date} (expected {expected_date})")
            failed = True

    # Test leap year handling
    print("\n--- Leap Year Handling ---")

    leap_years = [2020, 2024]
    non_leap_years = [2021, 2023]

    for year in leap_years:
        feb29 = date(year, 2, 29)
        # Verify date is valid
        print(f"✓ {year} is leap year: Feb 29 exists")

    print("\n⚠ Add more edge case tests based on your date logic")

    # Summary
    print("\n" + "=" * 60)
    if failed:
        print("RESULT: FAILED")
        sys.exit(1)
    else:
        print("RESULT: PASSED")
        sys.exit(0)

if __name__ == "__main__":
    main()
```

---

## Layer 8: BY-Group Processing

**File:** `validate_layer8_by_groups.py`

```python
#!/usr/bin/env python3
"""Validate BY-group processing matches SAS behavior."""

import sys
import polars as pl

# Configuration
SAS_OUTPUT_PATH = "tests/fixtures/sas_outputs/expected_output.csv"
MIGRATED_OUTPUT_PATH = "output/migrated_output.parquet"
BY_VARIABLES = ["customer_id"]  # Adjust to your BY variables
SORT_WITHIN_GROUP = ["date"]  # Sort order within groups

def main():
    """Run BY-group validation."""
    print("=" * 60)
    print("Layer 8: BY-Group Processing Validation")
    print("=" * 60)

    sas_output = pl.read_csv(SAS_OUTPUT_PATH)
    migrated_output = pl.read_parquet(MIGRATED_OUTPUT_PATH)

    failed = False

    # Check sorting
    print(f"\n--- Sorting by BY variables: {BY_VARIABLES} ---")

    full_sort = BY_VARIABLES + SORT_WITHIN_GROUP
    sas_sorted = sas_output.sort(full_sort)
    migrated_sorted = migrated_output.sort(full_sort)

    print(f"✓ Both outputs sorted by: {full_sort}")

    # Verify group counts match
    print(f"\n--- Group Counts ---")

    sas_groups = sas_sorted.group_by(BY_VARIABLES).len().sort(BY_VARIABLES)
    migrated_groups = migrated_sorted.group_by(BY_VARIABLES).len().sort(BY_VARIABLES)

    if sas_groups.equals(migrated_groups):
        print(f"✓ PASS: Group counts match ({len(sas_groups)} groups)")
    else:
        print("✗ FAIL: Group count mismatch")
        failed = True

    # Check first/last row per group (if you have FIRST./LAST. logic)
    print(f"\n--- First/Last Row Detection ---")
    print("⚠ Verify your FIRST./LAST. logic produces same boundary rows as SAS")

    # You would add specific checks here based on your logic

    # Summary
    print("\n" + "=" * 60)
    if failed:
        print("RESULT: FAILED")
        sys.exit(1)
    else:
        print("RESULT: PASSED")
        sys.exit(0)

if __name__ == "__main__":
    main()
```

---

## Layer 9: LAG/DIF Semantics

**File:** `validate_layer9_lag_dif.py`

```python
#!/usr/bin/env python3
"""Validate LAG/DIF semantics match SAS queue behavior."""

import sys
import polars as pl

# Configuration
SAS_OUTPUT_PATH = "tests/fixtures/sas_outputs/expected_output_with_lag.csv"
MIGRATED_OUTPUT_PATH = "output/migrated_output_with_lag.parquet"
LAG_COLUMNS = ["prev_value", "prev_prev_value"]  # Columns with LAG results

def main():
    """Run LAG/DIF validation."""
    print("=" * 60)
    print("Layer 9: LAG/DIF Semantics Validation")
    print("=" * 60)
    print("\n⚠ CRITICAL: LAG must use queue semantics, not simple shift\n")

    sas_output = pl.read_csv(SAS_OUTPUT_PATH)
    migrated_output = pl.read_parquet(MIGRATED_OUTPUT_PATH)

    failed = False

    for lag_col in LAG_COLUMNS:
        if lag_col not in sas_output.columns or lag_col not in migrated_output.columns:
            print(f"⚠ Skipping {lag_col}: not found in both outputs")
            continue

        print(f"\n--- {lag_col} ---")

        # Compare LAG column values
        sas_vals = sas_output[lag_col]
        migrated_vals = migrated_output[lag_col]

        # Count mismatches (handle nulls)
        mismatches = (
            ((sas_vals != migrated_vals) & (~sas_vals.is_null()) & (~migrated_vals.is_null()))
            | (sas_vals.is_null() != migrated_vals.is_null())
        ).sum()

        if mismatches == 0:
            print(f"✓ PASS: All LAG values match")
        else:
            print(f"✗ FAIL: {mismatches} mismatches")

            # Show first few mismatches
            mismatch_mask = (sas_vals != migrated_vals) | (sas_vals.is_null() != migrated_vals.is_null())
            mismatch_indices = mismatch_mask.arg_true().head(5)
            print(f"    First mismatches (row indices): {mismatch_indices.to_list()}")

            failed = True

    # Summary
    print("\n" + "=" * 60)
    if failed:
        print("RESULT: FAILED")
        print("\n⚠ Check if conditional LAG was used in SAS - requires queue implementation")
        sys.exit(1)
    else:
        print("RESULT: PASSED")
        sys.exit(0)

if __name__ == "__main__":
    main()
```

---

## Layer 10: Character Variables

**File:** `validate_layer10_char_vars.py`

```python
#!/usr/bin/env python3
"""Validate character variable handling matches SAS (padding, truncation)."""

import sys
import polars as pl

# Configuration
SAS_OUTPUT_PATH = "tests/fixtures/sas_outputs/expected_output.csv"
MIGRATED_OUTPUT_PATH = "output/migrated_output.parquet"
CHAR_COLUMNS = ["customer_name", "status_code"]  # Adjust to your char columns

def main():
    """Run character variable validation."""
    print("=" * 60)
    print("Layer 10: Character Variable Validation")
    print("=" * 60)
    print("\n⚠ SAS fixed-length strings may have trailing spaces\n")

    sas_output = pl.read_csv(SAS_OUTPUT_PATH)
    migrated_output = pl.read_parquet(MIGRATED_OUTPUT_PATH)

    failed = False

    for col in CHAR_COLUMNS:
        if col not in sas_output.columns or col not in migrated_output.columns:
            print(f"⚠ Skipping {col}: not in both outputs")
            continue

        print(f"\n--- {col} ---")

        sas_vals = sas_output[col]
        migrated_vals = migrated_output[col]

        # Exact comparison
        exact_mismatches = (sas_vals != migrated_vals).sum()

        # Trimmed comparison (ignore trailing spaces)
        trimmed_mismatches = (
            sas_vals.str.strip_chars() != migrated_vals.str.strip_chars()
        ).sum()

        if exact_mismatches == 0:
            print(f"✓ PASS: Exact match")
        elif trimmed_mismatches == 0:
            print(f"⚠ WARNING: Matches after trim, but {exact_mismatches} have space differences")
            print("  (This may be acceptable if SAS used fixed-length)")
        else:
            print(f"✗ FAIL: {trimmed_mismatches} mismatches (even after trim)")

            # Show first few mismatches
            mismatch_mask = sas_vals.str.strip_chars() != migrated_vals.str.strip_chars()
            mismatch_indices = mismatch_mask.arg_true().head(3)

            for idx in mismatch_indices.to_list():
                sas_val = sas_output[col][idx]
                migrated_val = migrated_output[col][idx]
                print(f"  Row {idx}:")
                print(f"    SAS: '{sas_val}'")
                print(f"    Migrated: '{migrated_val}'")

            failed = True

    # Summary
    print("\n" + "=" * 60)
    if failed:
        print("RESULT: FAILED")
        sys.exit(1)
    else:
        print("RESULT: PASSED")
        sys.exit(0)

if __name__ == "__main__":
    main()
```

---

## Full Reconciliation Report

**File:** `generate_reconciliation_report.py`

```python
#!/usr/bin/env python3
"""Generate comprehensive reconciliation report across all validation layers."""

import json
import sys
from datetime import datetime
from pathlib import Path
import polars as pl

# Configuration
SAS_OUTPUT_PATH = "tests/fixtures/sas_outputs/expected_output.csv"
MIGRATED_OUTPUT_PATH = "output/migrated_output.parquet"
REPORT_OUTPUT_PATH = "reconciliation_report.json"
TOLERANCE = 1e-8

def main():
    """Generate reconciliation report."""
    print("=" * 60)
    print("Reconciliation Report Generator")
    print("=" * 60)

    report = {
        "timestamp": datetime.now().isoformat(),
        "sas_output": str(SAS_OUTPUT_PATH),
        "migrated_output": str(MIGRATED_OUTPUT_PATH),
        "validation_passed": True,
        "layers": {}
    }

    # Use lazy loading for efficiency
    print("\nScanning outputs...")
    sas_lazy = pl.scan_csv(SAS_OUTPUT_PATH)
    migrated_lazy = pl.scan_parquet(MIGRATED_OUTPUT_PATH)

    # Layer 1: Schema
    print("Checking schema...")
    sas_schema = sas_lazy.schema
    migrated_schema = migrated_lazy.schema
    schema_passed = (list(sas_schema.keys()) == list(migrated_schema.keys()))
    report["layers"]["schema"] = {
        "passed": schema_passed,
        "sas_columns": len(sas_schema),
        "migrated_columns": len(migrated_schema)
    }
    report["validation_passed"] &= schema_passed

    # Layer 2: Row counts
    print("Checking row counts...")
    sas_count = sas_lazy.select(pl.count()).collect().item()
    migrated_count = migrated_lazy.select(pl.count()).collect().item()
    row_count_passed = (sas_count == migrated_count)
    report["layers"]["row_counts"] = {
        "passed": row_count_passed,
        "sas_rows": sas_count,
        "migrated_rows": migrated_count
    }
    report["validation_passed"] &= row_count_passed

    # Layer 4: Missing values
    print("Checking missing values...")

    # Compute all null counts in one pass
    sas_nulls_df = sas_lazy.select([
        pl.col(col).null_count().alias(col) for col in sas_schema.keys()
    ]).collect()

    migrated_nulls_df = migrated_lazy.select([
        pl.col(col).null_count().alias(col)
        for col in migrated_schema.keys()
    ]).collect()

    null_checks = []
    for col in sas_schema.keys():
        if col in migrated_schema:
            sas_nulls = sas_nulls_df[col].item()
            migrated_nulls = migrated_nulls_df[col].item()
            null_checks.append({
                "column": col,
                "passed": sas_nulls == migrated_nulls,
                "sas_nulls": sas_nulls,
                "migrated_nulls": migrated_nulls
            })

    report["layers"]["missing_values"] = {
        "passed": all(c["passed"] for c in null_checks),
        "checks": null_checks
    }
    report["validation_passed"] &= all(c["passed"] for c in null_checks)

    # Layer 5: Aggregates
    print("Checking aggregates...")

    # Get numeric columns
    numeric_cols = [
        col for col, dtype in sas_schema.items()
        if col in migrated_schema and dtype in [pl.Float64, pl.Float32, pl.Int64, pl.Int32]
    ]

    agg_checks = []
    if numeric_cols:
        # Compute all aggregates in one pass
        sas_aggs = sas_lazy.select([
            pl.col(col).sum().alias(col) for col in numeric_cols
        ]).collect()

        migrated_aggs = migrated_lazy.select([
            pl.col(col).sum().alias(col) for col in numeric_cols
        ]).collect()

        for col in numeric_cols:
            sas_sum = sas_aggs[col].item()
            migrated_sum = migrated_aggs[col].item()
            diff = abs(sas_sum - migrated_sum)

            agg_checks.append({
                "column": col,
                "metric": "sum",
                "passed": diff < TOLERANCE,
                "sas_value": float(sas_sum),
                "migrated_value": float(migrated_sum),
                "difference": float(diff)
            })

    report["layers"]["aggregates"] = {
        "passed": all(c["passed"] for c in agg_checks) if agg_checks else True,
        "checks": agg_checks
    }
    report["validation_passed"] &= all(c["passed"] for c in agg_checks) if agg_checks else True

    # Write report
    print(f"\nWriting report to: {REPORT_OUTPUT_PATH}")
    with open(REPORT_OUTPUT_PATH, "w") as f:
        json.dump(report, f, indent=2)

    # Print summary
    print("\n" + "=" * 60)
    print("RECONCILIATION SUMMARY")
    print("=" * 60)
    print(f"Overall validation: {'PASSED' if report['validation_passed'] else 'FAILED'}")
    print(f"Schema: {'PASS' if report['layers']['schema']['passed'] else 'FAIL'}")
    print(f"Row counts: {'PASS' if report['layers']['row_counts']['passed'] else 'FAIL'}")
    print(f"Missing values: {'PASS' if report['layers']['missing_values']['passed'] else 'FAIL'}")
    print(f"Aggregates: {'PASS' if report['layers']['aggregates']['passed'] else 'FAIL'}")
    print(f"\nFull report: {REPORT_OUTPUT_PATH}")

    sys.exit(0 if report["validation_passed"] else 1)

if __name__ == "__main__":
    main()
```

---

## Running All Validations

**File:** `run_all_validations.sh`

```bash
#!/bin/bash
# Run all validation layers in sequence

set -e  # Exit on first failure

echo "Running SAS Migration Validation Suite"
echo "========================================"

FAILED=0

# Run each layer
for script in validate_layer*.py; do
    if [ -f "$script" ]; then
        echo ""
        python "$script" || FAILED=1
    fi
done

# Generate reconciliation report
echo ""
python generate_reconciliation_report.py || FAILED=1

# Summary
echo ""
echo "========================================"
if [ $FAILED -eq 0 ]; then
    echo "ALL VALIDATIONS PASSED"
    exit 0
else
    echo "SOME VALIDATIONS FAILED"
    exit 1
fi
```

Make executable:
```bash
chmod +x run_all_validations.sh
```

---

## Summary

All validation scripts:
- Load data directly
- Perform specific layer checks
- Print clear PASS/FAIL with details
- Exit with code 0 (success) or 1 (failure)
- Can be run independently or in sequence
- No test framework required - just Python scripts

Adjust configuration variables in each script to match your data paths and column names.
