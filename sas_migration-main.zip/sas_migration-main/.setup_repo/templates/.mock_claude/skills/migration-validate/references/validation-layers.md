# Validation Layers for SAS Migration

10-layer validation approach from structural to cell-wise accuracy.

## Layer 1: Schema Validation

**What:** Verify data structure matches (columns, types, order if relevant).

**Why:** Catch structural mismatches before data comparison.

**Tests:**
- Column names match
- Data types match
- Column order (if business logic depends on it)

**Tolerance:** Exact match

---

## Layer 2: Row Count Validation

**What:** Verify total rows and by-group row counts.

**Why:** Catch filtering errors, join cardinality issues.

**Tests:**
- Overall row count
- Row counts per key group
- Empty vs. non-empty groups

**Tolerance:** Exact match

---

## Layer 3: Key/Distinct Value Validation

**What:** Verify unique keys and distinct values match.

**Why:** Catch missing/extra records, join issues.

**Tests:**
- Distinct keys present in both outputs
- No unexpected keys in result
- Distinct value counts per categorical column

**Tolerance:** Exact match

---

## Layer 4: Null/Missing Value Validation

**What:** Verify null/missing counts match.

**Why:** SAS special missing vs. target language null handling.

**Tests:**
- Null count per column
- Special missing encoding (if applicable)
- Missing value patterns in BY-groups

**Tolerance:** Exact match

**Critical for SAS:** Special missing (._,  .A-.Z) must be encoded/validated correctly.

---

## Layer 5: Numeric Aggregate Validation

**What:** Compare summary statistics.

**Why:** Catch calculation errors, rounding issues, aggregation logic.

**Tests:**
- Sum, mean, std per numeric column
- Min, max values
- Aggregates by group
- Percentiles (25th, 50th, 75th)

**Tolerance:** Floating-point tolerance (e.g., 1e-8 or business requirement)

---

## Layer 6: Row-Level (Cell-Wise) Validation

**What:** Every cell matches SAS output.

**Why:** Gold standard for regulated work - complete behavioral equivalence.

**Tests:**
- Sort both outputs by keys
- Cell-by-cell comparison
- Numeric columns with tolerance
- String columns exact match

**Tolerance:**
- Numeric: Business requirement (e.g., $0.01 for currency)
- String: Exact match

**Use when:** Production validation, regulated environments, high-risk migrations.

---

## Layer 7: Date Function Edge Cases

**What:** Test date-specific edge cases identified in analysis.

**Why:** INTCK, INTNX, YRDIF have SAS-specific boundary rules.

**Tests:**
- Month-end dates (Jan 31 + 1 month)
- Leap years (Feb 29)
- Year/quarter boundaries
- Business day calculations
- INTNX alignment options

**Tolerance:** Exact date match

**Critical patterns:**
- INTCK: Test boundary crossing rules
- INTNX: Test SAME, BEGINNING, END alignment
- YRDIF: Test basis conventions

---

## Layer 8: BY-Group Processing Validation

**What:** Verify BY-group semantics match SAS.

**Why:** SAS BY-group processing has specific ordering and boundary rules.

**Tests:**
- Data sorted by BY variables
- FIRST./LAST. indicators correct (if present)
- Cumulative operations within groups
- Group boundaries preserved

**Tolerance:** Exact match

**Critical checks:**
- Sort order matches SAS BY statement
- Row order within groups preserved
- FIRST row per group correctly identified

---

## Layer 9: LAG/DIF Semantics Validation

**What:** Verify LAG/DIF behavior matches SAS (especially queue semantics).

**Why:** SAS LAG uses queue that tracks across conditions, not simple shift.

**Tests:**
- Unconditional LAG (should work with shift)
- Conditional LAG (requires queue reproduction)
- Multiple LAG calls
- LAG within loops
- DIF with conditional execution

**Tolerance:** Exact match

**Critical:** Test conditional LAG separately - this is where queue semantics matter.

---

## Layer 10: Character Variable Validation

**What:** Verify string handling matches SAS.

**Why:** SAS fixed-length character variables can have padding/truncation.

**Tests:**
- String lengths match
- Trailing/leading spaces handled correctly
- Substring operations match
- String comparisons in joins

**Tolerance:** Exact match (after handling expected padding)

**Critical for:**
- Keys used in joins
- String comparisons in filters
- SUBSTR operations

---

## Validation Strategy by Complexity

### Low Complexity Migration
**Required:**
- Layer 1: Schema
- Layer 2: Row counts
- Layer 3: Keys
- Layer 5: Aggregates

### Medium Complexity
**Add:**
- Layer 4: Missing values
- Layer 7: Date edge cases (if dates present)
- Layer 8: BY-group (if BY processing present)

### High Complexity
**Add:**
- Layer 6: Cell-wise (for critical paths)
- Layer 9: LAG/DIF (if present)
- Layer 10: Character variables (if padding issues)

### Very High / Regulated
**All Layers:** Complete cell-wise validation with full edge case coverage.

---

## Validation Sequencing

Run in order for efficient debugging:

1. **Schema** → Catch structural issues first
2. **Row counts** → Catch major filtering/join errors
3. **Keys** → Verify record presence
4. **Nulls** → Check missing value handling
5. **Aggregates** → Test calculation logic
6. **Edge cases** → Test semantic traps
7. **Cell-wise** → Final verification

If early layers fail, fix before proceeding to later layers.

---

## Test Organization

```
tests/validation/
├── test_01_schema.py           # Layer 1
├── test_02_row_counts.py       # Layer 2
├── test_03_keys.py             # Layer 3
├── test_04_missing_values.py   # Layer 4
├── test_05_aggregates.py       # Layer 5
├── test_06_cell_wise.py        # Layer 6
├── test_07_date_edges.py       # Layer 7
├── test_08_by_groups.py        # Layer 8
├── test_09_lag_dif.py          # Layer 9
├── test_10_char_vars.py        # Layer 10
└── test_reconciliation.py      # Full report
```

Number tests to reflect validation sequence.

---

## Reconciliation Report

Generate comprehensive report covering all layers:

```json
{
  "timestamp": "2026-10-12T14:00:00",
  "validation_passed": true,
  "layers": {
    "schema": {"passed": true, "details": {...}},
    "row_counts": {"passed": true, "details": {...}},
    "keys": {"passed": true, "details": {...}},
    "missing_values": {"passed": true, "details": {...}},
    "aggregates": {"passed": true, "details": {...}},
    "cell_wise": {"passed": true, "details": {...}},
    "date_edges": {"passed": true, "details": {...}},
    "by_groups": {"passed": true, "details": {...}},
    "lag_dif": {"passed": true, "details": {...}},
    "char_vars": {"passed": true, "details": {...}}
  },
  "summary": {
    "total_checks": 50,
    "passed": 50,
    "failed": 0,
    "warnings": 0
  }
}
```

Include:
- Pass/fail per layer
- Detailed diffs for failures
- Warnings for close mismatches
- Execution time per layer
- Data paths used
