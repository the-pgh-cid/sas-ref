# Validation Scripts for R Migration

Runnable validation code chunks for comparing SAS output with migrated R output.

## Key Feature: Lazy Loading with Arrow

**These scripts use lazy evaluation** for memory efficiency with large datasets:
-  **Schema checks**: Read schema without loading data
-  **Row counts**: Compute counts without materializing full dataset
-  **Aggregates**: Compute statistics in single pass, only selected columns
-  **Group operations**: Process by group without loading entire dataset
-  **Cell-wise**: Requires eager loading for full comparison


## Usage

Each validation layer is a standalone R script that:
1. Scans SAS reference output and migrated R output (lazy)
2. Performs comparisons for that layer
3. Reports PASS/FAIL with details
4. Exits with code 0 (pass) or 1 (fail)

Run validation scripts directly:
```bash
Rscript validate_layer1_schema.R
Rscript validate_layer2_row_counts.R
# etc.
```

---

## Configuration

Create configuration at the top of each validation script:

```r
# Configuration
SAS_OUTPUT_PATH <- "tests/fixtures/sas_outputs/expected_output.csv"
MIGRATED_OUTPUT_PATH <- "output/migrated_output.csv"  # or .parquet
TOLERANCE <- 1e-8  # Floating-point tolerance

# Use lazy loading for efficiency with large datasets
USE_LAZY <- TRUE  # Set FALSE for small datasets or cell-wise validation
```

## Lazy vs Eager Loading

**Lazy loading** (recommended for large datasets):
- Use `arrow::open_dataset()` or DuckDB for lazy evaluation
- Only materialize data when needed via `collect()`
- More memory efficient
- Layers 1-5, 7-9: Use lazy evaluation

**Eager loading** (for small datasets or full scans):
- Use `data.table::fread()` or `read.csv()`
- Layer 6 (cell-wise): Requires eager for full comparison
- Layer 10 (char vars): May need eager for string operations

---

## Layer 1: Schema Validation

**File:** `validate_layer1_schema.R`

```r
#!/usr/bin/env Rscript
# Validate schema matches between SAS and migrated output

library(arrow)

# Configuration
SAS_OUTPUT_PATH <- "tests/fixtures/sas_outputs/expected_output.csv"
MIGRATED_OUTPUT_PATH <- "output/migrated_output.parquet"  # or .csv

main <- function() {
  cat(rep("=", 60), "\n", sep = "")
  cat("Layer 1: Schema Validation\n")
  cat(rep("=", 60), "\n", sep = "")

  # Use lazy loading - only reads schema, not data
  cat("\nScanning SAS output:", SAS_OUTPUT_PATH, "\n")
  if (grepl("\\.csv$", SAS_OUTPUT_PATH)) {
    sas_dataset <- open_csv_dataset(SAS_OUTPUT_PATH)
  } else {
    sas_dataset <- open_dataset(SAS_OUTPUT_PATH)
  }

  cat("Scanning migrated output:", MIGRATED_OUTPUT_PATH, "\n")
  if (grepl("\\.csv$", MIGRATED_OUTPUT_PATH)) {
    migrated_dataset <- open_csv_dataset(MIGRATED_OUTPUT_PATH)
  } else {
    migrated_dataset <- open_dataset(MIGRATED_OUTPUT_PATH)
  }

  # Get schemas without loading data
  sas_schema <- sas_dataset$schema
  migrated_schema <- migrated_dataset$schema

  failed <- FALSE

  # Check column names
  cat("\n--- Column Names ---\n")
  sas_cols <- names(sas_schema)
  migrated_cols <- names(migrated_schema)

  if (identical(sas_cols, migrated_cols)) {
    cat("✓ PASS: Column names match (", length(sas_cols), " columns)\n", sep = "")
  } else {
    cat("✗ FAIL: Column name mismatch\n")
    missing <- setdiff(sas_cols, migrated_cols)
    extra <- setdiff(migrated_cols, sas_cols)
    if (length(missing) > 0) {
      cat("  Missing columns:", paste(missing, collapse = ", "), "\n")
    }
    if (length(extra) > 0) {
      cat("  Extra columns:", paste(extra, collapse = ", "), "\n")
    }
    failed <- TRUE
  }

  # Check data types
  cat("\n--- Data Types ---\n")
  type_mismatches <- list()

  for (col in sas_cols) {
    if (col %in% migrated_cols) {
      sas_type <- as.character(sas_schema[[col]]$type)
      migrated_type <- as.character(migrated_schema[[col]]$type)
      if (sas_type != migrated_type) {
        type_mismatches[[length(type_mismatches) + 1]] <- list(
          col = col,
          sas_type = sas_type,
          migrated_type = migrated_type
        )
      }
    }
  }

  if (length(type_mismatches) == 0) {
    cat("✓ PASS: All data types match\n")
  } else {
    cat("✗ FAIL: Data type mismatches found:\n")
    for (tm in type_mismatches) {
      cat("  ", tm$col, ": ", tm$sas_type, " (SAS) vs ",
          tm$migrated_type, " (migrated)\n", sep = "")
    }
    failed <- TRUE
  }

  # Summary
  cat("\n", rep("=", 60), "\n", sep = "")
  if (failed) {
    cat("RESULT: FAILED\n")
    quit(status = 1)
  } else {
    cat("RESULT: PASSED\n")
    quit(status = 0)
  }
}

main()
```

---

## Layer 2: Row Count Validation

**File:** `validate_layer2_row_counts.R`

```r
#!/usr/bin/env Rscript
# Validate row counts match between SAS and migrated output

library(arrow)
library(dplyr)

# Configuration
SAS_OUTPUT_PATH <- "tests/fixtures/sas_outputs/expected_output.csv"
MIGRATED_OUTPUT_PATH <- "output/migrated_output.parquet"
GROUP_BY_COLUMN <- "category"  # Adjust based on your data

main <- function() {
  cat(rep("=", 60), "\n", sep = "")
  cat("Layer 2: Row Count Validation\n")
  cat(rep("=", 60), "\n", sep = "")

  # Use lazy loading - only compute counts, don't load data
  if (grepl("\\.csv$", SAS_OUTPUT_PATH)) {
    sas_dataset <- open_csv_dataset(SAS_OUTPUT_PATH)
  } else {
    sas_dataset <- open_dataset(SAS_OUTPUT_PATH)
  }

  if (grepl("\\.csv$", MIGRATED_OUTPUT_PATH)) {
    migrated_dataset <- open_csv_dataset(MIGRATED_OUTPUT_PATH)
  } else {
    migrated_dataset <- open_dataset(MIGRATED_OUTPUT_PATH)
  }

  failed <- FALSE

  # Overall row count - lazy evaluation
  cat("\n--- Overall Row Count ---\n")
  sas_count <- sas_dataset %>% count() %>% collect() %>% pull(n)
  migrated_count <- migrated_dataset %>% count() %>% collect() %>% pull(n)

  if (sas_count == migrated_count) {
    cat("✓ PASS: Row counts match (", sas_count, " rows)\n", sep = "")
  } else {
    cat("✗ FAIL: Row count mismatch\n")
    cat("  SAS output:", sas_count, "rows\n")
    cat("  Migrated output:", migrated_count, "rows\n")
    cat("  Difference:", migrated_count - sas_count, "rows\n")
    failed <- TRUE
  }

  # Group-level row counts (if applicable) - lazy evaluation
  if (GROUP_BY_COLUMN %in% names(sas_dataset$schema)) {
    cat("\n--- Row Counts by", GROUP_BY_COLUMN, "---\n")

    sas_groups <- sas_dataset %>%
      group_by(!!sym(GROUP_BY_COLUMN)) %>%
      summarise(sas_count = n()) %>%
      arrange(!!sym(GROUP_BY_COLUMN)) %>%
      collect()

    migrated_groups <- migrated_dataset %>%
      group_by(!!sym(GROUP_BY_COLUMN)) %>%
      summarise(migrated_count = n()) %>%
      arrange(!!sym(GROUP_BY_COLUMN)) %>%
      collect()

    # Merge to compare
    comparison <- full_join(sas_groups, migrated_groups, by = GROUP_BY_COLUMN)
    comparison$sas_count[is.na(comparison$sas_count)] <- 0
    comparison$migrated_count[is.na(comparison$migrated_count)] <- 0

    mismatches <- comparison %>% filter(sas_count != migrated_count)

    if (nrow(mismatches) == 0) {
      cat("✓ PASS: All group row counts match (", nrow(sas_groups), " groups)\n", sep = "")
    } else {
      cat("✗ FAIL: Group row count mismatches (", nrow(mismatches), " groups)\n", sep = "")
      cat("\nMismatched groups:\n")
      print(mismatches)
      failed <- TRUE
    }
  }

  # Summary
  cat("\n", rep("=", 60), "\n", sep = "")
  if (failed) {
    cat("RESULT: FAILED\n")
    quit(status = 1)
  } else {
    cat("RESULT: PASSED\n")
    quit(status = 0)
  }
}

main()
```

---

## Layer 3: Key Validation

**File:** `validate_layer3_keys.R`

```r
#!/usr/bin/env Rscript
# Validate distinct key values match between outputs

library(data.table)

# Configuration
SAS_OUTPUT_PATH <- "tests/fixtures/sas_outputs/expected_output.csv"
MIGRATED_OUTPUT_PATH <- "output/migrated_output.csv"
KEY_COLUMNS <- c("customer_id")  # Adjust to your keys

main <- function() {
  cat(rep("=", 60), "\n", sep = "")
  cat("Layer 3: Key Validation\n")
  cat(rep("=", 60), "\n", sep = "")

  sas_output <- fread(SAS_OUTPUT_PATH)
  migrated_output <- fread(MIGRATED_OUTPUT_PATH)

  failed <- FALSE

  for (key_col in KEY_COLUMNS) {
    cat("\n--- Distinct Values:", key_col, "---\n")

    sas_keys <- unique(sas_output[[key_col]])
    migrated_keys <- unique(migrated_output[[key_col]])

    missing <- setdiff(sas_keys, migrated_keys)
    extra <- setdiff(migrated_keys, sas_keys)

    if (length(missing) == 0 && length(extra) == 0) {
      cat("✓ PASS: All distinct values match (", length(sas_keys), " unique values)\n", sep = "")
    } else {
      cat("✗ FAIL: Distinct value mismatch\n")
      if (length(missing) > 0) {
        show_missing <- head(sort(missing), 10)
        cat("  Missing in migrated:", paste(show_missing, collapse = ", "))
        if (length(missing) > 10) {
          cat(" ... and", length(missing) - 10, "more")
        }
        cat("\n")
      }
      if (length(extra) > 0) {
        show_extra <- head(sort(extra), 10)
        cat("  Extra in migrated:", paste(show_extra, collapse = ", "))
        if (length(extra) > 10) {
          cat(" ... and", length(extra) - 10, "more")
        }
        cat("\n")
      }
      failed <- TRUE
    }
  }

  # Summary
  cat("\n", rep("=", 60), "\n", sep = "")
  if (failed) {
    cat("RESULT: FAILED\n")
    quit(status = 1)
  } else {
    cat("RESULT: PASSED\n")
    quit(status = 0)
  }
}

main()
```

---

## Layer 4: Missing Value Validation

**File:** `validate_layer4_missing_values.R`

```r
#!/usr/bin/env Rscript
# Validate missing value counts match between outputs

library(data.table)

# Configuration
SAS_OUTPUT_PATH <- "tests/fixtures/sas_outputs/expected_output.csv"
MIGRATED_OUTPUT_PATH <- "output/migrated_output.csv"

main <- function() {
  cat(rep("=", 60), "\n", sep = "")
  cat("Layer 4: Missing Value Validation\n")
  cat(rep("=", 60), "\n", sep = "")

  sas_output <- fread(SAS_OUTPUT_PATH)
  migrated_output <- fread(MIGRATED_OUTPUT_PATH)

  failed <- FALSE

  cat("\n--- Null Counts by Column ---\n")

  for (col in names(sas_output)) {
    if (!(col %in% names(migrated_output))) {
      next
    }

    sas_nulls <- sum(is.na(sas_output[[col]]))
    migrated_nulls <- sum(is.na(migrated_output[[col]]))

    if (sas_nulls == migrated_nulls) {
      cat("✓", col, ":", sas_nulls, "nulls\n")
    } else {
      cat("✗", col, ": MISMATCH\n")
      cat("    SAS:", sas_nulls, "nulls\n")
      cat("    Migrated:", migrated_nulls, "nulls\n")
      failed <- TRUE
    }
  }

  # Summary
  cat("\n", rep("=", 60), "\n", sep = "")
  if (failed) {
    cat("RESULT: FAILED\n")
    quit(status = 1)
  } else {
    cat("RESULT: PASSED\n")
    quit(status = 0)
  }
}

main()
```

---

## Layer 5: Aggregate Validation

**File:** `validate_layer5_aggregates.R`

```r
#!/usr/bin/env Rscript
# Validate numeric aggregates match between outputs

library(data.table)

# Configuration
SAS_OUTPUT_PATH <- "tests/fixtures/sas_outputs/expected_output.csv"
MIGRATED_OUTPUT_PATH <- "output/migrated_output.csv"
TOLERANCE <- 1e-8
NUMERIC_COLUMNS <- c("amount", "quantity", "price")  # Adjust to your data

main <- function() {
  cat(rep("=", 60), "\n", sep = "")
  cat("Layer 5: Aggregate Validation\n")
  cat(rep("=", 60), "\n", sep = "")

  sas_output <- fread(SAS_OUTPUT_PATH)
  migrated_output <- fread(MIGRATED_OUTPUT_PATH)

  failed <- FALSE

  for (col in NUMERIC_COLUMNS) {
    if (!(col %in% names(sas_output)) || !(col %in% names(migrated_output))) {
      cat("\n⚠ Skipping", col, ": not in both outputs\n")
      next
    }

    cat("\n---", col, "---\n")

    # Sum
    sas_sum <- sum(sas_output[[col]], na.rm = TRUE)
    migrated_sum <- sum(migrated_output[[col]], na.rm = TRUE)
    diff <- abs(sas_sum - migrated_sum)

    if (diff < TOLERANCE) {
      cat(sprintf("✓ Sum: %.4f (diff: %.2e)\n", migrated_sum, diff))
    } else {
      cat("✗ Sum: MISMATCH\n")
      cat(sprintf("    SAS: %.4f\n", sas_sum))
      cat(sprintf("    Migrated: %.4f\n", migrated_sum))
      cat(sprintf("    Diff: %.2e\n", diff))
      failed <- TRUE
    }

    # Mean
    sas_mean <- mean(sas_output[[col]], na.rm = TRUE)
    migrated_mean <- mean(migrated_output[[col]], na.rm = TRUE)
    diff <- abs(sas_mean - migrated_mean)

    if (diff < TOLERANCE) {
      cat(sprintf("✓ Mean: %.4f (diff: %.2e)\n", migrated_mean, diff))
    } else {
      cat("✗ Mean: MISMATCH\n")
      cat(sprintf("    SAS: %.4f\n", sas_mean))
      cat(sprintf("    Migrated: %.4f\n", migrated_mean))
      cat(sprintf("    Diff: %.2e\n", diff))
      failed <- TRUE
    }

    # Std
    sas_std <- sd(sas_output[[col]], na.rm = TRUE)
    migrated_std <- sd(migrated_output[[col]], na.rm = TRUE)
    diff <- abs(sas_std - migrated_std)

    if (diff < TOLERANCE) {
      cat(sprintf("✓ Std: %.4f (diff: %.2e)\n", migrated_std, diff))
    } else {
      cat("✗ Std: MISMATCH\n")
      cat(sprintf("    SAS: %.4f\n", sas_std))
      cat(sprintf("    Migrated: %.4f\n", migrated_std))
      cat(sprintf("    Diff: %.2e\n", diff))
      failed <- TRUE
    }
  }

  # Summary
  cat("\n", rep("=", 60), "\n", sep = "")
  if (failed) {
    cat("RESULT: FAILED\n")
    quit(status = 1)
  } else {
    cat("RESULT: PASSED\n")
    quit(status = 0)
  }
}

main()
```

---

## Layer 6: Cell-Wise Validation

**File:** `validate_layer6_cell_wise.R`

```r
#!/usr/bin/env Rscript
# Validate cell-by-cell accuracy between outputs

library(data.table)

# Configuration
SAS_OUTPUT_PATH <- "tests/fixtures/sas_outputs/expected_output.csv"
MIGRATED_OUTPUT_PATH <- "output/migrated_output.csv"
TOLERANCE <- 1e-8
SORT_KEYS <- c("customer_id", "date")  # Adjust to your keys

main <- function() {
  cat(rep("=", 60), "\n", sep = "")
  cat("Layer 6: Cell-Wise Validation\n")
  cat(rep("=", 60), "\n", sep = "")
  cat("\n⚠ WARNING: Comprehensive check. May take time for large datasets.\n\n")

  sas_output <- fread(SAS_OUTPUT_PATH)
  migrated_output <- fread(MIGRATED_OUTPUT_PATH)

  # Sort both by keys
  cat("Sorting by:", paste(SORT_KEYS, collapse = ", "), "\n")
  setorderv(sas_output, SORT_KEYS)
  setorderv(migrated_output, SORT_KEYS)

  failed <- FALSE

  for (col in names(sas_output)) {
    if (!(col %in% names(migrated_output))) {
      next
    }

    cat("\n---", col, "---\n")

    sas_col <- sas_output[[col]]
    migrated_col <- migrated_output[[col]]

    # Check if numeric
    if (is.numeric(sas_col)) {
      # Numeric comparison with tolerance
      diff <- abs(sas_col - migrated_col)
      max_diff <- max(diff, na.rm = TRUE)

      if (max_diff < TOLERANCE) {
        cat(sprintf("✓ PASS: All cells match (max diff: %.2e)\n", max_diff))
      } else {
        mismatch_count <- sum(diff >= TOLERANCE, na.rm = TRUE)
        cat(sprintf("✗ FAIL: %d cells differ\n", mismatch_count))
        cat(sprintf("    Max diff: %.4f\n", max_diff))

        # Show worst mismatches
        worst_indices <- head(order(diff, decreasing = TRUE, na.last = NA), 5)
        cat("    Worst mismatches (row indices):", paste(worst_indices, collapse = ", "), "\n")
        failed <- TRUE
      }
    } else {
      # Exact comparison for non-numeric
      mismatches <- sum(sas_col != migrated_col, na.rm = TRUE)

      if (mismatches == 0) {
        cat("✓ PASS: All cells match exactly\n")
      } else {
        cat(sprintf("✗ FAIL: %d cells differ\n", mismatches))

        # Show first few mismatches
        mismatch_indices <- head(which(sas_col != migrated_col), 5)
        cat("    First mismatches (row indices):", paste(mismatch_indices, collapse = ", "), "\n")
        failed <- TRUE
      }
    }
  }

  # Summary
  cat("\n", rep("=", 60), "\n", sep = "")
  if (failed) {
    cat("RESULT: FAILED\n")
    quit(status = 1)
  } else {
    cat("RESULT: PASSED - Complete cell-wise match\n")
    quit(status = 0)
  }
}

main()
```

---

## Layer 7: Date Edge Cases

**File:** `validate_layer7_date_edges.R`

```r
#!/usr/bin/env Rscript
# Validate date function edge cases match SAS behavior

library(data.table)

main <- function() {
  cat(rep("=", 60), "\n", sep = "")
  cat("Layer 7: Date Edge Case Validation\n")
  cat(rep("=", 60), "\n", sep = "")

  failed <- FALSE

  # Test month-end handling
  cat("\n--- Month-End Date Handling ---\n")

  # Example: Test INTNX-like behavior
  test_cases <- data.table(
    input_date = as.Date(c("2024-01-31", "2023-01-31", "2024-03-31")),
    expected_next = as.Date(c("2024-02-29", "2023-02-28", "2024-04-30"))
  )

  for (i in seq_len(nrow(test_cases))) {
    input_date <- test_cases$input_date[i]
    expected_date <- test_cases$expected_next[i]

    # Call your migrated date logic here
    # result_date <- your_add_month_function(input_date)

    # For demonstration:
    result_date <- expected_date  # Replace with actual call

    if (result_date == expected_date) {
      cat("✓", as.character(input_date), "+ 1 month =", as.character(result_date), "\n")
    } else {
      cat("✗", as.character(input_date), "+ 1 month =", as.character(result_date),
          "(expected", as.character(expected_date), ")\n")
      failed <- TRUE
    }
  }

  # Test leap year handling
  cat("\n--- Leap Year Handling ---\n")

  leap_years <- c(2020, 2024)

  for (year in leap_years) {
    feb29 <- as.Date(paste0(year, "-02-29"))
    cat("✓", year, "is leap year: Feb 29 exists\n")
  }

  cat("\n⚠ Add more edge case tests based on your date logic\n")

  # Summary
  cat("\n", rep("=", 60), "\n", sep = "")
  if (failed) {
    cat("RESULT: FAILED\n")
    quit(status = 1)
  } else {
    cat("RESULT: PASSED\n")
    quit(status = 0)
  }
}

main()
```

---

## Layer 8: BY-Group Processing

**File:** `validate_layer8_by_groups.R`

```r
#!/usr/bin/env Rscript
# Validate BY-group processing matches SAS behavior

library(data.table)

# Configuration
SAS_OUTPUT_PATH <- "tests/fixtures/sas_outputs/expected_output.csv"
MIGRATED_OUTPUT_PATH <- "output/migrated_output.csv"
BY_VARIABLES <- c("customer_id")  # Adjust to your BY variables
SORT_WITHIN_GROUP <- c("date")  # Sort order within groups

main <- function() {
  cat(rep("=", 60), "\n", sep = "")
  cat("Layer 8: BY-Group Processing Validation\n")
  cat(rep("=", 60), "\n", sep = "")

  sas_output <- fread(SAS_OUTPUT_PATH)
  migrated_output <- fread(MIGRATED_OUTPUT_PATH)

  failed <- FALSE

  # Check sorting
  cat("\n--- Sorting by BY variables:", paste(BY_VARIABLES, collapse = ", "), "---\n")

  full_sort <- c(BY_VARIABLES, SORT_WITHIN_GROUP)
  setorderv(sas_output, full_sort)
  setorderv(migrated_output, full_sort)

  cat("✓ Both outputs sorted by:", paste(full_sort, collapse = ", "), "\n")

  # Verify group counts match
  cat("\n--- Group Counts ---\n")

  sas_groups <- sas_output[, .N, by = BY_VARIABLES]
  setorderv(sas_groups, BY_VARIABLES)

  migrated_groups <- migrated_output[, .N, by = BY_VARIABLES]
  setorderv(migrated_groups, BY_VARIABLES)

  if (identical(sas_groups, migrated_groups)) {
    cat("✓ PASS: Group counts match (", nrow(sas_groups), " groups)\n", sep = "")
  } else {
    cat("✗ FAIL: Group count mismatch\n")
    failed <- TRUE
  }

  # Check first/last row per group
  cat("\n--- First/Last Row Detection ---\n")
  cat("⚠ Verify your FIRST./LAST. logic produces same boundary rows as SAS\n")

  # You would add specific checks here based on your logic

  # Summary
  cat("\n", rep("=", 60), "\n", sep = "")
  if (failed) {
    cat("RESULT: FAILED\n")
    quit(status = 1)
  } else {
    cat("RESULT: PASSED\n")
    quit(status = 0)
  }
}

main()
```

---

## Layer 9: LAG/DIF Semantics

**File:** `validate_layer9_lag_dif.R`

```r
#!/usr/bin/env Rscript
# Validate LAG/DIF semantics match SAS queue behavior

library(data.table)

# Configuration
SAS_OUTPUT_PATH <- "tests/fixtures/sas_outputs/expected_output_with_lag.csv"
MIGRATED_OUTPUT_PATH <- "output/migrated_output_with_lag.csv"
LAG_COLUMNS <- c("prev_value", "prev_prev_value")  # Columns with LAG results

main <- function() {
  cat(rep("=", 60), "\n", sep = "")
  cat("Layer 9: LAG/DIF Semantics Validation\n")
  cat(rep("=", 60), "\n", sep = "")
  cat("\n⚠ CRITICAL: LAG must use queue semantics, not simple shift\n\n")

  sas_output <- fread(SAS_OUTPUT_PATH)
  migrated_output <- fread(MIGRATED_OUTPUT_PATH)

  failed <- FALSE

  for (lag_col in LAG_COLUMNS) {
    if (!(lag_col %in% names(sas_output)) || !(lag_col %in% names(migrated_output))) {
      cat("⚠ Skipping", lag_col, ": not found in both outputs\n")
      next
    }

    cat("\n---", lag_col, "---\n")

    sas_vals <- sas_output[[lag_col]]
    migrated_vals <- migrated_output[[lag_col]]

    # Count mismatches (handle NAs)
    mismatches <- sum(
      (!is.na(sas_vals) & !is.na(migrated_vals) & sas_vals != migrated_vals) |
      (is.na(sas_vals) != is.na(migrated_vals))
    )

    if (mismatches == 0) {
      cat("✓ PASS: All LAG values match\n")
    } else {
      cat(sprintf("✗ FAIL: %d mismatches\n", mismatches))

      # Show first few mismatches
      mismatch_indices <- head(which(
        (!is.na(sas_vals) & !is.na(migrated_vals) & sas_vals != migrated_vals) |
        (is.na(sas_vals) != is.na(migrated_vals))
      ), 5)
      cat("    First mismatches (row indices):", paste(mismatch_indices, collapse = ", "), "\n")

      failed <- TRUE
    }
  }

  # Summary
  cat("\n", rep("=", 60), "\n", sep = "")
  if (failed) {
    cat("RESULT: FAILED\n")
    cat("\n⚠ Check if conditional LAG was used in SAS - requires queue implementation\n")
    quit(status = 1)
  } else {
    cat("RESULT: PASSED\n")
    quit(status = 0)
  }
}

main()
```

---

## Layer 10: Character Variables

**File:** `validate_layer10_char_vars.R`

```r
#!/usr/bin/env Rscript
# Validate character variable handling matches SAS (padding, truncation)

library(data.table)

# Configuration
SAS_OUTPUT_PATH <- "tests/fixtures/sas_outputs/expected_output.csv"
MIGRATED_OUTPUT_PATH <- "output/migrated_output.csv"
CHAR_COLUMNS <- c("customer_name", "status_code")  # Adjust to your char columns

main <- function() {
  cat(rep("=", 60), "\n", sep = "")
  cat("Layer 10: Character Variable Validation\n")
  cat(rep("=", 60), "\n", sep = "")
  cat("\n⚠ SAS fixed-length strings may have trailing spaces\n\n")

  sas_output <- fread(SAS_OUTPUT_PATH)
  migrated_output <- fread(MIGRATED_OUTPUT_PATH)

  failed <- FALSE

  for (col in CHAR_COLUMNS) {
    if (!(col %in% names(sas_output)) || !(col %in% names(migrated_output))) {
      cat("⚠ Skipping", col, ": not in both outputs\n")
      next
    }

    cat("\n---", col, "---\n")

    sas_vals <- sas_output[[col]]
    migrated_vals <- migrated_output[[col]]

    # Exact comparison
    exact_mismatches <- sum(sas_vals != migrated_vals, na.rm = TRUE)

    # Trimmed comparison (ignore trailing spaces)
    trimmed_mismatches <- sum(
      trimws(sas_vals) != trimws(migrated_vals),
      na.rm = TRUE
    )

    if (exact_mismatches == 0) {
      cat("✓ PASS: Exact match\n")
    } else if (trimmed_mismatches == 0) {
      cat(sprintf("⚠ WARNING: Matches after trim, but %d have space differences\n", exact_mismatches))
      cat("  (This may be acceptable if SAS used fixed-length)\n")
    } else {
      cat(sprintf("✗ FAIL: %d mismatches (even after trim)\n", trimmed_mismatches))

      # Show first few mismatches
      mismatch_indices <- head(which(trimws(sas_vals) != trimws(migrated_vals)), 3)

      for (idx in mismatch_indices) {
        cat(sprintf("  Row %d:\n", idx))
        cat("    SAS: '", sas_vals[idx], "'\n", sep = "")
        cat("    Migrated: '", migrated_vals[idx], "'\n", sep = "")
      }

      failed <- TRUE
    }
  }

  # Summary
  cat("\n", rep("=", 60), "\n", sep = "")
  if (failed) {
    cat("RESULT: FAILED\n")
    quit(status = 1)
  } else {
    cat("RESULT: PASSED\n")
    quit(status = 0)
  }
}

main()
```

---

## Full Reconciliation Report

**File:** `generate_reconciliation_report.R`

```r
#!/usr/bin/env Rscript
# Generate comprehensive reconciliation report across all validation layers

library(data.table)
library(jsonlite)

# Configuration
SAS_OUTPUT_PATH <- "tests/fixtures/sas_outputs/expected_output.csv"
MIGRATED_OUTPUT_PATH <- "output/migrated_output.csv"
REPORT_OUTPUT_PATH <- "reconciliation_report.json"
TOLERANCE <- 1e-8

main <- function() {
  cat(rep("=", 60), "\n", sep = "")
  cat("Reconciliation Report Generator\n")
  cat(rep("=", 60), "\n", sep = "")

  report <- list(
    timestamp = format(Sys.time(), "%Y-%m-%dT%H:%M:%S"),
    sas_output = SAS_OUTPUT_PATH,
    migrated_output = MIGRATED_OUTPUT_PATH,
    validation_passed = TRUE,
    layers = list()
  )

  # Load data
  cat("\nLoading outputs...\n")
  sas_output <- fread(SAS_OUTPUT_PATH)
  migrated_output <- fread(MIGRATED_OUTPUT_PATH)

  # Layer 1: Schema
  cat("Checking schema...\n")
  schema_passed <- identical(names(sas_output), names(migrated_output))
  report$layers$schema <- list(
    passed = schema_passed,
    sas_columns = length(names(sas_output)),
    migrated_columns = length(names(migrated_output))
  )
  report$validation_passed <- report$validation_passed && schema_passed

  # Layer 2: Row counts
  cat("Checking row counts...\n")
  row_count_passed <- nrow(sas_output) == nrow(migrated_output)
  report$layers$row_counts <- list(
    passed = row_count_passed,
    sas_rows = nrow(sas_output),
    migrated_rows = nrow(migrated_output)
  )
  report$validation_passed <- report$validation_passed && row_count_passed

  # Layer 4: Missing values
  cat("Checking missing values...\n")
  null_checks <- list()
  for (col in names(sas_output)) {
    if (col %in% names(migrated_output)) {
      sas_nulls <- sum(is.na(sas_output[[col]]))
      migrated_nulls <- sum(is.na(migrated_output[[col]]))
      null_checks[[length(null_checks) + 1]] <- list(
        column = col,
        passed = sas_nulls == migrated_nulls,
        sas_nulls = sas_nulls,
        migrated_nulls = migrated_nulls
      )
    }
  }

  report$layers$missing_values <- list(
    passed = all(sapply(null_checks, function(x) x$passed)),
    checks = null_checks
  )
  report$validation_passed <- report$validation_passed &&
                              all(sapply(null_checks, function(x) x$passed))

  # Layer 5: Aggregates
  cat("Checking aggregates...\n")
  agg_checks <- list()
  for (col in names(sas_output)) {
    if (col %in% names(migrated_output) && is.numeric(sas_output[[col]])) {
      sas_sum <- sum(sas_output[[col]], na.rm = TRUE)
      migrated_sum <- sum(migrated_output[[col]], na.rm = TRUE)
      diff <- abs(sas_sum - migrated_sum)

      agg_checks[[length(agg_checks) + 1]] <- list(
        column = col,
        metric = "sum",
        passed = diff < TOLERANCE,
        sas_value = sas_sum,
        migrated_value = migrated_sum,
        difference = diff
      )
    }
  }

  report$layers$aggregates <- list(
    passed = all(sapply(agg_checks, function(x) x$passed)),
    checks = agg_checks
  )
  report$validation_passed <- report$validation_passed &&
                              all(sapply(agg_checks, function(x) x$passed))

  # Write report
  cat("\nWriting report to:", REPORT_OUTPUT_PATH, "\n")
  write_json(report, REPORT_OUTPUT_PATH, pretty = TRUE, auto_unbox = TRUE)

  # Print summary
  cat("\n", rep("=", 60), "\n", sep = "")
  cat("RECONCILIATION SUMMARY\n")
  cat(rep("=", 60), "\n", sep = "")
  cat("Overall validation:", if (report$validation_passed) "PASSED" else "FAILED", "\n")
  cat("Schema:", if (report$layers$schema$passed) "PASS" else "FAIL", "\n")
  cat("Row counts:", if (report$layers$row_counts$passed) "PASS" else "FAIL", "\n")
  cat("Missing values:", if (report$layers$missing_values$passed) "PASS" else "FAIL", "\n")
  cat("Aggregates:", if (report$layers$aggregates$passed) "PASS" else "FAIL", "\n")
  cat("\nFull report:", REPORT_OUTPUT_PATH, "\n")

  quit(status = if (report$validation_passed) 0 else 1)
}

main()
```

---

## Running All Validations

**File:** `run_all_validations.sh`

```bash
#!/bin/bash
# Run all validation layers in sequence

set -e  # Exit on first failure

echo "Running SAS Migration Validation Suite (R)"
echo "========================================"

FAILED=0

# Run each layer
for script in validate_layer*.R; do
    if [ -f "$script" ]; then
        echo ""
        Rscript "$script" || FAILED=1
    fi
done

# Generate reconciliation report
echo ""
Rscript generate_reconciliation_report.R || FAILED=1

# Summary
echo ""
echo "========================================"
if [ $FAILED -eq 0 ]; then
    echo "ALL VALIDATIONS PASSED"
    exit 0
else
    echo "SOME VALIDATIONS FAILED"
    exit 1
fi
```

Make executable:
```bash
chmod +x run_all_validations.sh
```

---

## Summary

All validation scripts:
- Load data directly
- Perform specific layer checks
- Print clear PASS/FAIL with details
- Exit with code 0 (success) or 1 (failure)
- Can be run independently or in sequence
- No test framework required - just R scripts

Adjust configuration variables in each script to match your data paths and column names.
