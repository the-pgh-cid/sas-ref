---
name: migration-validate
description: Generate comprehensive validation tests for migrated SAS code to ensure behavioral equivalence
---

# Migration Validation

Generate validation tests and reconciliation reports to verify migrated code produces identical results to SAS.

## When to Use

- Migration conversion is complete and needs validation
- Need to create automated test suite
- User asks to "validate", "test", "verify", or "reconcile" migrated code
- Preparing for production deployment

## Required Reading

**Reference materials:**
- [references/validation-layers.md](references/validation-layers.md) - 10 validation layers (what to check)
- [references/test-templates_r.md](references/test-templates_r.md) - R validation scripts

## Workflow

### 1. Understand Migration Context
- Review original SAS program
- Identify complexity patterns (from sas-analyze if available)
- Review target language (R)
- Note semantic traps requiring validation

### 2. Determine Validation Layers Needed
**Select from `validation-layers.md`:**
1. Schema validation
2. Row count validation
3. Key/distinct value validation
4. Null/missing value validation
5. Numeric aggregate validation
6. Row-level (cell-wise) validation
7. Date function edge cases
8. BY-group processing validation
9. LAG/DIF semantics validation
10. Character variable validation

### 3. Generate Validation Scripts
**Create runnable validation scripts using templates:**
- Each layer as standalone .py or .R script
- Load data directly (no fixtures/test functions)
- Print PASS/FAIL with clear details
- Exit with code 0 (pass) or 1 (fail)
- Configure paths at top of each script

### 4. Add Reconciliation Report Generator
**Generate script to:**
- Compare SAS vs. migrated outputs
- Create detailed diff reports
- Flag discrepancies with context
- Export results for review

### 5. Document Validation Requirements
**Include:**
- Test execution instructions
- Expected outputs
- Edge cases covered
- Known limitations

## Rules

### Validate Appropriately
- **Schema → Counts → Aggregates → Cell-wise** (increasing specificity)
- Use appropriate tolerances (floating-point requires tolerance)
- Validate with representative data when possible
- Don't skip edge cases identified in analysis

### Script Configuration
- Put configuration at top (file paths, tolerances, column names)
- Make paths easily adjustable per environment
- Comment what each configuration variable controls
- Provide example values in comments

### Generate Runnable Scripts
- Each script is standalone and executable
- Print clear PASS/FAIL for each check
- Exit with proper status code (0=pass, 1=fail)
- Provide execution instructions at top of file

## Output Structure

### For R
```
validation/
├── validate_layer1_schema.R
├── validate_layer2_row_counts.R
├── validate_layer3_keys.R
├── validate_layer4_missing_values.R
├── validate_layer5_aggregates.R
├── validate_layer6_cell_wise.R
├── validate_layer7_date_edges.R
├── validate_layer8_by_groups.R
├── validate_layer9_lag_dif.R
├── validate_layer10_char_vars.R
├── generate_reconciliation_report.R
├── run_all_validations.sh
└── fixtures/
    └── sas_outputs/
        └── expected_output.csv
```

## Validation Script Guidelines

### Approach
Generate **runnable validation scripts**, not test functions. Each script:
- Loads SAS and migrated outputs directly
- Performs comparisons
- Prints PASS/FAIL with details
- Exits with code 0 (pass) or 1 (fail)

### 1. Schema Validation (Always Include)
```r
# validate_layer1_schema.R
library(arrow)
library(dplyr)

# Open datasets (lazy - no data loaded yet)
sas_output <- open_dataset("sas_output.csv", format = "csv")
migrated_output <- open_dataset("migrated_output.parquet")

# Compare columns (still lazy)
if (identical(names(sas_output), names(migrated_output))) {
    cat("✓ PASS: Schema matches\n")
} else {
    cat("✗ FAIL: Schema mismatch\n")
    quit(status = 1)
}
```

### 2. Row Count Validation (Always Include)
```r
# validate_layer2_row_counts.R
library(arrow)
library(dplyr)

# Open datasets (lazy)
sas_output <- open_dataset("sas_output.csv", format = "csv")
migrated_output <- open_dataset("migrated_output.parquet")

# Count rows (lazy aggregation, only materialized on collect)
sas_count <- sas_output %>% count() %>% collect() %>% pull(n)
migrated_count <- migrated_output %>% count() %>% collect() %>% pull(n)

# Compare row counts
if (sas_count == migrated_count) {
    cat(sprintf("✓ PASS: Row counts match (%d rows)\n", sas_count))
} else {
    cat(sprintf("✗ FAIL: Row count mismatch\n"))
    quit(status = 1)
}
```

### 3. Aggregate Validation (Always Include)
```r
# validate_layer5_aggregates.R
library(arrow)
library(dplyr)

# Open datasets (lazy)
sas_output <- open_dataset("sas_output.csv", format = "csv")
migrated_output <- open_dataset("migrated_output.parquet")

tolerance <- 1e-6
numeric_columns <- c("col1", "col2", "col3")

for (col in numeric_columns) {
    # Lazy aggregation - only computed on collect()
    sas_sum <- sas_output %>%
        summarise(sum = sum(!!sym(col), na.rm = TRUE)) %>%
        collect() %>%
        pull(sum)

    migrated_sum <- migrated_output %>%
        summarise(sum = sum(!!sym(col), na.rm = TRUE)) %>%
        collect() %>%
        pull(sum)

    if (abs(sas_sum - migrated_sum) < tolerance) {
        cat(sprintf("✓ %s sum matches\n", col))
    } else {
        cat(sprintf("✗ %s sum mismatch\n", col))
    }
}
```

### 4. Edge Case Tests (Based on Complexity)
```r
# validate_layer7_date_edges.R
library(arrow)
library(dplyr)

# Open datasets (lazy) and filter to edge cases
sas_output <- open_dataset("sas_output.csv", format = "csv")
migrated_output <- open_dataset("migrated_output.parquet")

# Compare date columns on edge cases (lazy until collect)
edge_dates <- as.Date(c("2024-01-31", "2024-02-29", "2024-12-31"))
sas_edges <- sas_output %>%
    filter(date_col %in% edge_dates) %>%
    collect()

migrated_edges <- migrated_output %>%
    filter(date_col %in% edge_dates) %>%
    collect()

# Compare results
if (identical(sas_edges, migrated_edges)) {
    cat("✓ Date edge cases handled correctly\n")
} else {
    cat("✗ Date edge case mismatch\n")
}
```

### 5. Reconciliation Report
```r
# generate_reconciliation_report.R
library(jsonlite)

report <- list(
    timestamp = format(Sys.time(), "%Y-%m-%dT%H:%M:%S"),
    validation_passed = TRUE,
    layers = list()
)
# Write to JSON
write_json(report, "reconciliation_report.json", pretty = TRUE)
```

## Key References

- **Validation layers:** What to validate → [references/validation-layers.md](references/validation-layers.md)
- **R validation scripts:** Runnable validation code → [references/test-templates_r.md](references/test-templates_r.md)
