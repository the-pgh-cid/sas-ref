---
name: sas_to_r
description: Convert SAS programs to R using DuckDB, data.table, dplyr, or specialized packages based on workload characteristics
---

# SAS to R Conversion

Convert SAS code to semantically equivalent R code that preserves business logic and data contracts.

## When to Use

- User requests SAS to R conversion
- Target language is R (not Python)
- User says "convert to R", "migrate to data.table", "translate to dplyr"

## Required Reading

**Always read before converting:**
- [Project migration guide](../../../sas_convert_doc/sas_to_r.md)
- [references/gotchas.md](references/gotchas.md) - SAS semantic traps
- [references/proc-map.md](references/proc-map.md) - Procedure mappings
- [references/conventions.md](references/conventions.md) - R coding patterns

## Workflow

### 1. Inventory
**Understand the SAS program:**
- Read the SAS file(s)
- Identify all PROCs used
- Note DATA step patterns (RETAIN, LAG, BY-groups, etc.)
- List input/output datasets
- Catalog macro usage

### 2. Plan
**Choose target approach:**

**Library selection:**
- **DuckDB:** PROC SQL heavy, relational work, large files
- **data.table:** Performance, BY-group processing, stateful operations
- **dplyr/tidyverse:** Readable transformations, team preference
- **base R:** Simple operations, minimal dependencies
- **Specialized packages:** stats, lme4, survival, fable, etc.

**Architecture decision:**
```
SQL-heavy → DuckDB + dbplyr
Stateful DATA steps → data.table
Statistical procedures → Specialized R packages
Mixed workload → Layered approach (DuckDB + R)
```

### 3. Follow
**Execute conversion using patterns:**

**Setup environment:**
```r
library(DBI)
library(duckdb)
library(data.table)  # or library(dplyr)
```

**Convert components:**
1. Data loading (PROC IMPORT, LIBNAME) → See `proc-map.md`
2. DATA steps → See `conventions.md` for patterns
3. PROCs → See `proc-map.md` for mappings
4. Macros → R functions
5. Date/string functions → See `gotchas.md` for edge cases

**Handle complexity:**
- Review `gotchas.md` for each pattern identified
- Test stateful logic (RETAIN, LAG/DIF, FIRST./LAST.)
- Validate date functions (INTCK, INTNX, YRDIF)
- Check missing value handling
- Verify BY-group processing semantics

### 4. Validate
**Add validation checkpoints:**
```r
# TODO: Validate row counts match SAS
stopifnot(nrow(dt) == expected_row_count)

# TODO: Test BY-group ordering
# TODO: Validate date edge cases
# TODO: Check missing value handling
```

Generate test suite (see `/migration-validate` skill)

### 5. Document
**Annotate the conversion:**
- Add header with migration notes
- Comment semantic differences
- Reference SAS line numbers
- Document validation requirements
- List known edge cases to test

## Rules

### Semantic Preservation
- **Preserve behavior, not syntax** - Focus on what the SAS code does
- **Test semantic traps** - Missing values, dates, BY-groups, LAG/DIF
- **Explicit sorting** - Don't assume row order is preserved
- **Validate edge cases** - Month-end dates, leap years, special missing

### Code Quality
- Use type hints in function signatures (follow project code-style.md)
- Follow Google-style docstrings
- Generate clean, idiomatic R code
- Prefer vectorized operations over loops where possible
- Use appropriate library for the workload

### Safety
- Add validation checkpoints throughout
- Flag uncertainty with TODO comments
- Test against SAS output before declaring complete
- Document where behavior differs from SAS

## Output Structure

```r
#!/usr/bin/env Rscript
#
# SAS to R Migration
# Original: [sas_file.sas]
# Converted: [date]
#
# Migration notes:
# - Library choice: [data.table/dplyr/DuckDB]
# - Complexity patterns: [list patterns]
# - Validation requirements: [list tests needed]
# - Known semantic differences: [list any]

library(data.table)  # or appropriate libraries

# Configuration
INPUT_PATH <- "data/input.csv"
OUTPUT_PATH <- "data/output.csv"

main <- function() {
  # Load data
  dt <- fread(INPUT_PATH)

  # Transformations
  # Original SAS: [reference line numbers]
  dt[, new_var := old_var * 2]
  dt <- dt[age > 18]

  # Validation checkpoint
  stopifnot(nrow(dt) > 0)
  message(sprintf("Processed %d rows", nrow(dt)))

  # Write output
  fwrite(dt, OUTPUT_PATH)

  return(dt)
}

if (sys.nframe() == 0) {
  result <- main()
}
```

## Key References

- **Gotchas:** Missing values, LAG/DIF, dates, BY-groups → [references/gotchas.md](references/gotchas.md)
- **Procedure mapping:** PROC SQL, MEANS, FREQ, REG, etc. → [references/proc-map.md](references/proc-map.md)
- **Coding patterns:** DATA step patterns, joins, aggregations → [references/conventions.md](references/conventions.md)
- **Project guide:** Architecture and strategy → [../../../sas_convert_doc/sas_to_r.md](../../../sas_convert_doc/sas_to_r.md)
