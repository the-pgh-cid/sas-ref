# R Coding Conventions for SAS Migration

Common SAS patterns and their idiomatic R equivalents.

## DATA Step Patterns

### Basic Transformation

**SAS:**
```sas
DATA output;
    SET input;
    new_var = old_var * 2;
    IF age > 18;
RUN;
```

**R (data.table):**
```r
dt <- fread("input.csv")
dt <- dt[age > 18][, new_var := old_var * 2]
# Or chained:
dt[age > 18, new_var := old_var * 2]
```

**R (dplyr):**
```r
df <- read_csv("input.csv") %>%
  filter(age > 18) %>%
  mutate(new_var = old_var * 2)
```

**R (DuckDB):**
```r
result <- dbGetQuery(con, "
  SELECT *, old_var * 2 AS new_var
  FROM 'input.csv'
  WHERE age > 18
")
```

---

### Multiple Conditions (IF-THEN-ELSE)

**SAS:**
```sas
DATA output;
    SET input;
    IF age < 18 THEN category = 'Minor';
    ELSE IF age < 65 THEN category = 'Adult';
    ELSE category = 'Senior';
RUN;
```

**R (data.table):**
```r
dt[, category := fcase(
  age < 18, "Minor",
  age < 65, "Adult",
  default = "Senior"
)]
```

**R (dplyr):**
```r
df <- df %>%
  mutate(category = case_when(
    age < 18 ~ "Minor",
    age < 65 ~ "Adult",
    TRUE ~ "Senior"
  ))
```

**R (DuckDB):**
```r
df <- dbGetQuery("""
    SELECT *,
        CASE
        WHEN age < 18 THEN 'Minor'
        WHEN age < 65 THEN 'Adult'
        ELSE 'Senior'
        END AS category
    FROM df
""")
```

---

### SELECT-WHEN

**SAS:**
```sas
DATA output;
    SET input;
    SELECT (region);
        WHEN ('North') rate = 0.05;
        WHEN ('South') rate = 0.06;
        WHEN ('East', 'West') rate = 0.055;
        OTHERWISE rate = 0.05;
    END;
RUN;
```

**R (data.table):**
```r
dt[, rate := fcase(
  region == "North", 0.05,
  region == "South", 0.06,
  region %in% c("East", "West"), 0.055,
  default = 0.05
)]
```

**R (dplyr):**
```r
df <- df %>%
  mutate(rate = case_when(
    region == "North" ~ 0.05,
    region == "South" ~ 0.06,
    region %in% c("East", "West") ~ 0.055,
    TRUE ~ 0.05
  ))
```

**R (DuckDB):**
```r
result <- dbGetQuery(con, "
  SELECT *,
    CASE
      WHEN region = 'North' THEN 0.05
      WHEN region = 'South' THEN 0.06
      WHEN region IN ('East', 'West') THEN 0.055
      ELSE 0.05
    END AS rate
  FROM df
")
```

---

### RETAIN (Cumulative Operations)

**SAS:**
```sas
DATA output;
    RETAIN total 0;
    SET input;
    total = total + amount;
RUN;
```

**R (data.table):**
```r
dt[, total := cumsum(amount)]
```

**R (dplyr):**
```r
df <- df %>%
  mutate(total = cumsum(amount))
```

**R (DuckDB):**
```r
result <- dbGetQuery(con, "
  SELECT *,
    SUM(amount) OVER (ORDER BY rowid) AS total
  FROM df
")
```

**With BY groups:**
```r
# data.table:
dt[, total := cumsum(amount), by = customer_id]

# dplyr:
df %>%
  group_by(customer_id) %>%
  mutate(total = cumsum(amount)) %>%
  ungroup()

# DuckDB:
result <- dbGetQuery(con, "
  SELECT *,
    SUM(amount) OVER (PARTITION BY customer_id ORDER BY rowid) AS total
  FROM df
")
```

---

### LAG and DIF

**SAS (simple case):**
```sas
DATA output;
    SET input;
    prev_value = LAG(value);
    diff = DIF(value);
RUN;
```

**R (data.table):**
```r
dt[, `:=`(
  prev_value = shift(value, 1),
  diff = value - shift(value, 1)
)]
```

**R (dplyr):**
```r
df <- df %>%
  mutate(
    prev_value = lag(value),
    diff = value - lag(value)
  )
```

**R (DuckDB):**
```r
result <- dbGetQuery(con, "
  SELECT *,
    LAG(value) OVER (ORDER BY rowid) AS prev_value,
    value - LAG(value) OVER (ORDER BY rowid) AS diff
  FROM df
")
```

**⚠️ WARNING:** SAS LAG uses queue semantics. For conditional LAG, see gotchas.md.

---

### FIRST. and LAST. Variables

**SAS:**
```sas
PROC SORT DATA=input; BY customer_id date; RUN;
DATA output;
    SET input;
    BY customer_id;
    IF FIRST.customer_id THEN total = 0;
    total + amount;
    IF LAST.customer_id THEN OUTPUT;
RUN;
```

**R (data.table):**
```r
setorder(dt, customer_id, date)
dt[, total := cumsum(amount), by = customer_id]
dt <- dt[, .SD[.N], by = customer_id]  # Keep last per group
```

**R (dplyr):**
```r
df <- df %>%
  arrange(customer_id, date) %>%
  group_by(customer_id) %>%
  mutate(total = cumsum(amount)) %>%
  slice_tail(n = 1) %>%  # Keep last per group
  ungroup()
```

**For FIRST./LAST. indicators:**
```r
# data.table:
dt[, `:=`(
  first_customer = .I == .I[1],
  last_customer = .I == .I[.N]
), by = customer_id]

# dplyr:
df <- df %>%
  group_by(customer_id) %>%
  mutate(
    first_customer = row_number() == 1,
    last_customer = row_number() == n()
  ) %>%
  ungroup()

# DuckDB:
result <- dbGetQuery(con, "
  SELECT *,
    ROW_NUMBER() OVER (PARTITION BY customer_id ORDER BY date) = 1 AS first_customer,
    ROW_NUMBER() OVER (PARTITION BY customer_id ORDER BY date DESC) = 1 AS last_customer
  FROM df
")
```

---

### Arrays

**SAS:**
```sas
DATA output;
    SET input;
    ARRAY vars{3} var1 var2 var3;
    DO i = 1 TO 3;
        vars{i} = vars{i} * 2;
    END;
RUN;
```

**R (data.table):**
```r
cols <- c("var1", "var2", "var3")
dt[, (cols) := lapply(.SD, function(x) x * 2), .SDcols = cols]
```

**R (dplyr):**
```r
df <- df %>%
  mutate(across(c(var1, var2, var3), ~ . * 2))
```

---

### Multiple OUTPUT Statements

**SAS:**
```sas
DATA adults minors;
    SET input;
    IF age >= 18 THEN OUTPUT adults;
    ELSE OUTPUT minors;
RUN;
```

**R (data.table):**
```r
adults <- dt[age >= 18]
minors <- dt[age < 18]
```

**R (dplyr):**
```r
adults <- df %>% filter(age >= 18)
minors <- df %>% filter(age < 18)
```

---

## PROC SQL Patterns

### Simple Query

**SAS:**
```sas
PROC SQL;
    CREATE TABLE output AS
    SELECT customer_id, SUM(amount) AS total
    FROM input
    WHERE date > '2024-01-01'd
    GROUP BY customer_id
    HAVING total > 1000;
QUIT;
```

**R (DuckDB):**
```r
output <- dbGetQuery(con, "
  SELECT customer_id, SUM(amount) AS total
  FROM input
  WHERE date > '2024-01-01'
  GROUP BY customer_id
  HAVING total > 1000
")
```

**R (data.table):**
```r
output <- dt[date > as.Date("2024-01-01"),
             .(total = sum(amount)),
             by = customer_id
             ][total > 1000]
```

**R (dplyr):**
```r
output <- df %>%
  filter(date > as.Date("2024-01-01")) %>%
  group_by(customer_id) %>%
  summarise(total = sum(amount)) %>%
  filter(total > 1000)
```

---

### Joins

**SAS:**
```sas
PROC SQL;
    CREATE TABLE output AS
    SELECT a.*, b.category
    FROM customers AS a
    LEFT JOIN categories AS b
        ON a.category_id = b.id;
QUIT;
```

**R (DuckDB):**
```r
output <- dbGetQuery(con, "
  SELECT a.*, b.category
  FROM customers a
  LEFT JOIN categories b
    ON a.category_id = b.id
")
```

**R (data.table):**
```r
# Right join syntax (preserves structure of right table):
output <- categories[customers, on = .(id = category_id)]

# Or explicit merge:
output <- merge(customers, categories,
                by.x = "category_id", by.y = "id",
                all.x = TRUE)
```

**R (dplyr):**
```r
output <- customers %>%
  left_join(categories, by = c("category_id" = "id"))
```

---

### UNION ALL

**SAS:**
```sas
PROC SQL;
    CREATE TABLE combined AS
    SELECT * FROM data2023
    UNION ALL
    SELECT * FROM data2024;
QUIT;
```

**R (DuckDB):**
```r
combined <- dbGetQuery(con, "
  SELECT * FROM data2023
  UNION ALL
  SELECT * FROM data2024
")
```

**R (data.table):**
```r
combined <- rbindlist(list(data2023, data2024))
```

**R (dplyr):**
```r
combined <- bind_rows(data2023, data2024)
```


---

## Aggregation Patterns

### PROC MEANS

**SAS:**
```sas
PROC MEANS DATA=input MEAN STD MIN MAX;
    VAR sales;
    CLASS region;
    OUTPUT OUT=output MEAN=avg_sales STD=std_sales;
RUN;
```

**R (data.table):**
```r
output <- dt[, .(
  avg_sales = mean(sales, na.rm = TRUE),
  std_sales = sd(sales, na.rm = TRUE),
  min_sales = min(sales, na.rm = TRUE),
  max_sales = max(sales, na.rm = TRUE)
), by = region]
```

**R (dplyr):**
```r
output <- df %>%
  group_by(region) %>%
  summarise(
    avg_sales = mean(sales, na.rm = TRUE),
    std_sales = sd(sales, na.rm = TRUE),
    min_sales = min(sales, na.rm = TRUE),
    max_sales = max(sales, na.rm = TRUE)
  )
```

**R (DuckDB):**
```r
output <- dbGetQuery(con, "
  SELECT region,
    AVG(sales) AS avg_sales,
    STDDEV(sales) AS std_sales,
    MIN(sales) AS min_sales,
    MAX(sales) AS max_sales
  FROM df
  GROUP BY region
")
```

---

### PROC FREQ

**SAS:**
```sas
PROC FREQ DATA=input;
    TABLES category / OUT=freq_table;
RUN;
```

**R (base):**
```r
freq_table <- as.data.frame(table(df$category))
```

**R (data.table):**
```r
freq_table <- dt[, .N, by = category][order(-N)]
```

**R (dplyr):**
```r
freq_table <- df %>%
  count(category, sort = TRUE)
```

**R (DuckDB):**
```r
freq_table <- dbGetQuery(con, "
  SELECT category, COUNT(*) AS n
  FROM df
  GROUP BY category
  ORDER BY n DESC
")
```

---

### PROC TRANSPOSE

**SAS (wide to long):**
```sas
PROC TRANSPOSE DATA=wide OUT=long;
    BY id;
    VAR var1 var2 var3;
RUN;
```

**R (data.table):**
```r
long <- melt(wide, id.vars = "id",
             measure.vars = c("var1", "var2", "var3"),
             variable.name = "variable",
             value.name = "value")
```

**R (tidyr):**
```r
long <- wide %>%
  pivot_longer(cols = c(var1, var2, var3),
               names_to = "variable",
               values_to = "value")
```

**R (DuckDB):**
```r
long <- dbGetQuery(con, "
  UNPIVOT wide
  ON var1, var2, var3
  INTO NAME variable VALUE value
")
```

**SAS (long to wide):**
```sas
PROC TRANSPOSE DATA=long OUT=wide;
    BY id;
    ID variable;
    VAR value;
RUN;
```

**R (data.table):**
```r
wide <- dcast(long, id ~ variable, value.var = "value")
```

**R (tidyr):**
```r
wide <- long %>%
  pivot_wider(names_from = variable,
              values_from = value)
```

**R (DuckDB):**
```r
wide <- dbGetQuery(con, "
  PIVOT long
  ON variable
  USING SUM(value)
  GROUP BY id
")
```

---

## Date and Time Patterns

### Date Construction

**SAS:**
```sas
date = MDY(month, day, year);
date = TODAY();
date = '01JAN2024'd;
```

**R:**
```r
library(lubridate)
date <- make_date(year, month, day)
date <- today()
date <- as.Date("2024-01-01")
```

**R (DuckDB):**
```r
result <- dbGetQuery(con, "
  SELECT
    MAKE_DATE(year, month, day) AS date,
    CURRENT_DATE AS today,
    DATE '2024-01-01' AS specific_date
  FROM df
")
```

---

### Date Arithmetic

**SAS:**
```sas
next_month = INTNX('MONTH', date, 1, 'BEGINNING');
months_diff = INTCK('MONTH', start_date, end_date);
```

**R:**
```r
library(lubridate)
next_month <- floor_date(date %m+% months(1), "month")
months_diff <- interval(start_date, end_date) %/% months(1)

# ⚠️ Test edge cases (see gotchas.md)
```

**R (DuckDB):**
```r
result <- dbGetQuery(con, "
  SELECT
    date,
    DATE_TRUNC('month', date + INTERVAL 1 MONTH) AS next_month,
    DATE_DIFF('month', start_date, end_date) AS months_diff
  FROM df
")

-- ⚠️ Test edge cases (see gotchas.md)
```

---

### Date Extraction

**SAS:**
```sas
year_val = YEAR(date);
month_val = MONTH(date);
day_val = DAY(date);
weekday = WEEKDAY(date);
```

**R:**
```r
library(lubridate)
year_val <- year(date)
month_val <- month(date)
day_val <- day(date)
weekday <- wday(date)  # Sunday = 1
```

**R (DuckDB):**
```r
result <- dbGetQuery(con, "
  SELECT
    date,
    YEAR(date) AS year_val,
    MONTH(date) AS month_val,
    DAY(date) AS day_val,
    DAYOFWEEK(date) AS weekday
  FROM df
")
```

---

## String Patterns

### String Manipulation

**SAS:**
```sas
DATA output;
    SET input;
    upper_name = UPCASE(name);
    lower_name = LOWCASE(name);
    proper_name = PROPCASE(name);
    clean_name = TRIM(LEFT(name));
    sub_name = SUBSTR(name, 1, 10);
    concat_name = CATX(' ', first, last);
RUN;
```

**R (base):**
```r
dt[, `:=`(
  upper_name = toupper(name),
  lower_name = tolower(name),
  proper_name = tools::toTitleCase(name),
  clean_name = trimws(name),
  sub_name = substr(name, 1, 10),
  concat_name = paste(first, last, sep = " ")
)]
```

**R (stringr):**
```r
library(stringr)
df <- df %>%
  mutate(
    upper_name = str_to_upper(name),
    lower_name = str_to_lower(name),
    proper_name = str_to_title(name),
    clean_name = str_trim(name),
    sub_name = str_sub(name, 1, 10),
    concat_name = str_c(first, last, sep = " ")
  )
```

**R (DuckDB):**
```r
result <- dbGetQuery(con, "
  SELECT
    UPPER(name) AS upper_name,
    LOWER(name) AS lower_name,
    INITCAP(name) AS proper_name,
    TRIM(name) AS clean_name,
    SUBSTR(name, 1, 10) AS sub_name,
    CONCAT(first, ' ', last) AS concat_name
  FROM df
")
```

---

### Pattern Matching

**SAS:**
```sas
DATA output;
    SET input;
    IF PRXMATCH('/\d{3}-\d{2}-\d{4}/', ssn) THEN valid_ssn = 1;
    ELSE valid_ssn = 0;
    clean_text = PRXCHANGE('s/[^A-Za-z]//g', -1, text);
RUN;
```

**R (base):**
```r
dt[, `:=`(
  valid_ssn = grepl("\\d{3}-\\d{2}-\\d{4}", ssn),
  clean_text = gsub("[^A-Za-z]", "", text)
)]
```

**R (stringr):**
```r
df <- df %>%
  mutate(
    valid_ssn = str_detect(ssn, "\\d{3}-\\d{2}-\\d{4}"),
    clean_text = str_remove_all(text, "[^A-Za-z]")
  )
```

**R (DuckDB):**
```r
result <- dbGetQuery(con, "
  SELECT
    REGEXP_MATCHES(ssn, '\\d{3}-\\d{2}-\\d{4}') AS valid_ssn,
    REGEXP_REPLACE(text, '[^A-Za-z]', '', 'g') AS clean_text
  FROM df
")
```

---

## Macro Patterns

### Simple Macro Function

**SAS:**
```sas
%MACRO filter_data(dataset=, age_threshold=, output=);
    DATA &output;
        SET &dataset;
        IF age > &age_threshold;
    RUN;
%MEND filter_data;

%filter_data(dataset=input, age_threshold=18, output=adults);
```

**R:**
```r
filter_data <- function(dataset, age_threshold, output_path = NULL) {
  result <- dataset[age > age_threshold]

  if (!is.null(output_path)) {
    fwrite(result, output_path)
  }

  return(result)
}

adults <- filter_data(input, age_threshold = 18)
```

---

### Macro Loop

**SAS:**
```sas
%MACRO process_years;
    %DO year = 2020 %TO 2024;
        PROC MEANS DATA=data&year;
            VAR sales;
        RUN;
    %END;
%MEND process_years;

%process_years;
```

**R:**
```r
process_years <- function(years = 2020:2024) {
  results <- list()

  for (year in years) {
    data <- fread(paste0("data", year, ".csv"))
    summary <- data[, .(avg_sales = mean(sales, na.rm = TRUE))]
    results[[as.character(year)]] <- summary
  }

  return(rbindlist(results, idcol = "year"))
}

results <- process_years()
```

---

## Best Practices

### Choose the Right Library

```r
# DuckDB for:
# - Large files (>RAM)
# - SQL-heavy transformations
# - Direct file queries
con <- dbConnect(duckdb::duckdb())
result <- dbGetQuery(con, "FROM 'large_file.parquet'")

# data.table for:
# - Performance-critical operations
# - BY-group processing
# - In-place modifications
dt[, new_col := old_col * 2]
dt[, total := sum(amount), by = group]

# dplyr for:
# - Readable code
# - Team collaboration
# - Integration with tidyverse
df %>%
  filter(age > 18) %>%
  group_by(region) %>%
  summarise(total = sum(amount))

# base R for:
# - Simple operations
# - Minimal dependencies
# - Procedural logic
```

---

### Vectorization

Prefer vectorized operations over loops:

**Avoid:**
```r
for (i in 1:nrow(dt)) {
  dt$new_col[i] <- dt$old_col[i] * 2
}
```

**Prefer:**
```r
dt[, new_col := old_col * 2]
```

---

### Memory Efficiency

**data.table in-place modification:**
```r
# Creates copy (memory inefficient):
dt <- dt[age > 18]

# In-place (memory efficient):
dt <- dt[age > 18, ]  # Still creates copy for subsetting

# Most efficient for filtering:
dt_filtered <- dt[age > 18]  # Accept new object
```

**For large files:**
```r
# Don't load entire file:
dt <- fread("huge.csv")

# Query with DuckDB instead:
result <- dbGetQuery(con, "
  SELECT * FROM 'huge.csv'
  WHERE age > 18
")
```

---

### Type Safety

Always specify types explicitly:

```r
# Function signatures
process_data <- function(input_path, threshold = 100) {
  # Document types in docstring
  # input_path: character path to CSV file
  # threshold: numeric minimum value

  dt <- fread(input_path)
  dt[value > threshold]
}
```

---

### Error Handling

Add validation and error handling:

```r
process_data <- function(input_path, threshold = 100) {
  # Validate inputs
  stopifnot(file.exists(input_path))
  stopifnot(is.numeric(threshold))

  # Load and process
  dt <- fread(input_path)
  result <- dt[value > threshold]

  # Validate output
  stopifnot(nrow(result) > 0)

  return(result)
}
```
