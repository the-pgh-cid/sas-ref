# SAS to R Semantic Gotchas

Critical semantic differences and edge cases that require explicit testing.

## Missing Values

### SAS Special Missing Values
**Issue:** SAS has numeric missing (`.`) and special missing (`._`, `.A`-`.Z`) with different semantics and sort order. R only has `NA` and `NaN`.

**Impact:**
- SAS sorts missing values differently than R
- Special missing values carry meaning in some domains (._  = not applicable, .A = refused to answer, etc.)
- Arithmetic and comparisons behave differently

**Solution:**
```r
# Option 1: Encode as factor with explicit levels
dt[, value_category := fcase(
  is.na(value), "missing",
  value == special_code_1, "refused",
  value == special_code_2, "not_applicable",
  default = "valid"
)]

# Option 2: Separate indicator columns
dt[, `:=`(
  value_is_missing = is.na(value),
  value_missing_type = ...  # encode special missing type
)]
```

**Test cases:**
- All-missing column
- Partially-missing column
- Special missing values in BY-group processing
- Missing values in sorts
- Missing values in joins

---

## DATA Step Mechanics

### RETAIN Statement
**Issue:** SAS RETAIN creates persistent variables across DATA step iterations. Not automatically preserved in R.

**SAS behavior:**
```sas
DATA output;
    RETAIN total 0;
    SET input;
    total = total + amount;
RUN;
```

**R equivalents:**
```r
# For cumulative operations:
dt[, total := cumsum(amount)]

# For BY-group cumulative:
dt[, total := cumsum(amount), by = customer_id]

# For complex state, explicit loop may be needed
```

**Test cases:**
- Simple cumulative sum
- RETAIN with conditional reset
- RETAIN across BY groups
- Multiple RETAIN variables with interdependencies

---

### LAG and DIF Functions
**Issue:** SAS LAG/DIF use **queue semantics** that track across conditional execution. R's `shift()` / `lag()` are simple previous-row operations.

**SAS behavior:**
```sas
DATA output;
    SET input;
    IF condition THEN DO;
        prev = LAG(value);  /* Queue behavior */
    END;
RUN;
```

**Critical difference:**
- SAS LAG maintains a queue that's populated **every time LAG is executed**
- R shift/lag simply accesses previous row
- Conditional LAG calls in SAS don't map to conditional shift in R

**R approach:**
```r
# Simple previous-row (often correct):
dt[, prev_value := shift(value, 1)]

# For SAS queue semantics, need explicit state tracking:
# Requires reproducing exact SAS execution logic
```

**Test cases:**
- Unconditional LAG (shift works)
- Conditional LAG (queue semantics)
- Multiple LAG calls (LAG2, LAG3)
- LAG in DO loops
- DIF with conditional execution

---

### FIRST. and LAST. Variables
**Issue:** SAS FIRST./LAST. depend on DATA sorted by BY variables. R grouping doesn't automatically imply order.

**SAS requirement:**
```sas
PROC SORT DATA=input; BY customer_id date; RUN;
DATA output;
    SET input;
    BY customer_id;
    IF FIRST.customer_id THEN total = 0;
    /* ... */
RUN;
```

**R approach:**
```r
# Must explicitly sort first
setorder(dt, customer_id, date)

# Then identify boundaries
dt[, first_customer := .I == .I[1], by = customer_id]
dt[, last_customer := .I == .I[.N], by = customer_id]

# Or use in grouped operations:
dt[, .SD[1], by = customer_id]  # First row per group
dt[, .SD[.N], by = customer_id]  # Last row per group
```

**Test cases:**
- Single BY variable
- Multiple BY variables
- Verify sort order preserved
- FIRST./LAST. with conditional OUTPUT
- Nested BY groups

---

### BY-Group Processing Order
**Issue:** SAS processes BY groups sequentially in sorted order. R operations don't guarantee order unless explicit.

**Critical:**
- Always sort explicitly before BY-group operations
- Verify sort order matches SAS BY statement
- Test that row order within groups is preserved

```r
# Explicit sort matching SAS BY statement
setorder(dt, customer_id, date)

# Then grouped operations
dt[, operation, by = customer_id]
```

---

## MERGE vs. Joins

### Duplicate Keys in MERGE
**Issue:** SAS MERGE with duplicate keys in both datasets behaves differently than SQL JOIN.

**SAS MERGE behavior with duplicates:**
- Cartesian product within BY group
- One-to-many: SAS retains last value from "one" side
- Specific replication rules

**R joins:**
```r
# data.table join (closest to SAS):
dt1[dt2, on = "key"]  # Right join (dt2 structure preserved)

# For SAS-style merge, may need explicit cartesian:
merge(dt1, dt2, by = "key", all = TRUE)  # Full outer
```

**Test cases:**
- One-to-one merge
- One-to-many merge
- Many-to-many merge (verify behavior matches)
- Non-matching keys (all.x, all.y)
- Multiple BY variables

---

## Date Functions

### INTCK (Interval Counting)
**Issue:** SAS INTCK has specific boundary rules that don't match simple date arithmetic.

**SAS semantics:**
```sas
months = INTCK('MONTH', '01JAN2024'd, '28FEB2024'd);  /* = 1 */
months = INTCK('MONTH', '31JAN2024'd, '01FEB2024'd);  /* = 1 */
```

**R approach:**
```r
library(lubridate)

# Approximate month difference:
months <- interval(start_date, end_date) %/% months(1)

# WARNING: Boundary rules may differ! Test edge cases.
```

**Test cases:**
- Month boundaries (31st to 1st)
- Leap years (Feb 29)
- Year boundaries
- Week intervals with different starting days
- Business day calculations

---

### INTNX (Interval Advancement)
**Issue:** SAS INTNX has alignment options ('BEGINNING', 'MIDDLE', 'END', 'SAME') that affect month-end dates.

**SAS behavior:**
```sas
/* Jan 31 + 1 month, 'SAME' alignment */
next_month = INTNX('MONTH', '31JAN2024'd, 1, 'SAME');
/* Result depends on SAME-day rule */
```

**R approach:**
```r
# Month advancement:
next_month <- date %m+% months(1)

# With alignment to month start:
next_month <- floor_date(date %m+% months(1), "month")

# With month-end handling:
next_month <- ceiling_date(date %m+% months(1), "month") - days(1)
```

**Test cases:**
- Month-end dates (Jan 31, Feb 28/29, Dec 31)
- Alignment options
- Negative intervals
- Year/quarter boundaries

---

### YRDIF (Year Fractions)
**Issue:** SAS YRDIF supports multiple basis conventions ('ACT/ACT', 'ACT/360', '30/360', etc.). R has no direct equivalent.

**R approach:**
```r
# Simple time-based:
years <- time_length(interval(start_date, end_date), "years")

# For specific conventions, implement explicitly:
# ACT/ACT: actual days / actual days in year
# 30/360: assume 30-day months
# Must match SAS convention exactly
```

**Test cases:**
- Leap years
- Different conventions
- Partial years
- Negative periods

---

## Numeric Precision and Rounding

### Floating-Point Precision
**Issue:** Both SAS and R use IEEE 754 double-precision, but accumulation errors can differ.

**Test cases:**
- Currency calculations (use explicit rounding)
- Cumulative sums of floating-point values
- Equality comparisons of calculated values
- Extremely large/small numbers

**Best practice:**
```r
# For currency, round at each step or use integers (cents)
dt[, amount_cents := round(amount * 100)]
dt[, total_cents := sum(amount_cents)]
dt[, total_dollars := total_cents / 100]

# For comparisons with tolerance:
all.equal(result, expected, tolerance = 1e-8)
```

---

### ROUND Function
**Issue:** SAS ROUND and R round() can differ for .5 values (banker's rounding vs. round-half-up).

**R default:**
```r
round(2.5)  # = 2 (banker's rounding, rounds to even)
round(3.5)  # = 4
```

**For SAS-style round-half-up:**
```r
round_half_up <- function(x, digits = 0) {
  floor(x * 10^digits + 0.5) / 10^digits
}
```

**Test cases:**
- 0.5, 1.5, 2.5, etc.
- Negative values
- Different decimal places

---

## String Handling

### Fixed-Length Character Variables
**Issue:** SAS character variables have declared length and can be padded. R character vectors are variable-length.

**SAS behavior:**
```sas
LENGTH name $10;
name = "John";  /* Stored as "John      " with padding */
```

**R approach:**
```r
# Usually don't need fixed-length
# But test for:
# - Unexpected whitespace in comparisons
# - Truncation in original SAS code
```

**Test cases:**
- Trailing spaces in keys (affects joins)
- String comparisons with padding
- Substring operations expecting padding

---

### COMPRESS Function
**Issue:** SAS COMPRESS removes specific characters. R gsub/str_remove_all work differently.

**SAS:**
```sas
clean = COMPRESS(text, , 'kd');  /* Keep digits only */
```

**R:**
```r
# Remove non-digits:
clean <- gsub("[^0-9]", "", text)

# Keep only alphanumeric:
clean <- gsub("[^A-Za-z0-9]", "", text)
```

---

## Sorting and Duplicate Handling

### PROC SORT with NODUPKEY
**Issue:** NODUPKEY keeps first occurrence. R unique/distinct may differ.

**SAS:**
```sas
PROC SORT DATA=input OUT=output NODUPKEY;
    BY key1 key2;
RUN;
/* Keeps first occurrence of each key1+key2 combination */
```

**R:**
```r
# data.table (keeps first):
dt_unique <- unique(dt, by = c("key1", "key2"))

# dplyr (keeps first):
df_unique <- df %>% distinct(key1, key2, .keep_all = TRUE)
```

**Test with:**
- Verify first record kept (not last or arbitrary)
- Multiple sort keys
- Tiebreaker when all keys equal

---

## Statistical Procedure Defaults

### PROC MEANS
**Issue:** Default statistics and missing value handling differ between SAS and R.

**SAS defaults:**
- Statistics: N, MEAN, STD, MIN, MAX
- Missing values: Generally excluded from calculations
- Handles special missing values

**R approach:**
```r
# Explicit na.rm:
dt[, .(
  n = .N,
  mean = mean(value, na.rm = TRUE),
  sd = sd(value, na.rm = TRUE),
  min = min(value, na.rm = TRUE),
  max = max(value, na.rm = TRUE)
), by = group]
```

**Test:**
- All-missing groups
- Partially-missing values
- Compare N (non-missing count)

---

### PROC FREQ
**Issue:** Missing value treatment in frequency tables.

**SAS:** Has specific options for missing value inclusion.

**R:**
```r
# Include NAs explicitly:
table(df$category, useNA = "always")

# data.table:
dt[, .N, by = .(category, is.na(category))]
```

---

### Statistical Models (REG, LOGISTIC, etc.)
**Issue:** Default reference levels, missing value handling, and parameterization differ.

**Test:**
- Factor reference levels (contrasts in R)
- Missing value deletion (listwise vs. pairwise)
- Parameter estimates and standard errors
- Confidence intervals and p-values
- Model fit statistics

**R approach:**
```r
# Explicit contrast setting:
contrasts(df$category) <- contr.treatment(levels(df$category), base = 1)

# Explicit missing value handling:
model <- lm(y ~ x1 + x2, data = df, na.action = na.omit)
```

---

## Format vs. Data

### PROC FORMAT
**Issue:** SAS FORMAT is presentation-only but can affect PROC output. R factors are data-level.

**Critical:**
- Don't confuse SAS FORMAT with data transformation
- SAS formatted values are still stored as original values
- R factors change the underlying data type

**Test:**
- Verify formatted output matches SAS
- Ensure calculations use unformatted values
- Check sort order (formatted vs. unformatted)

---

## Summary: High-Priority Test Cases

For every migration, test:

1. ✅ **Row counts** - Overall and by-group
2. ✅ **Sort order** - Explicit sorting where order matters
3. ✅ **Missing values** - Nulls, special missing, counts
4. ✅ **Date edge cases** - Month-end, leap years, intervals
5. ✅ **BY-group boundaries** - FIRST./LAST. semantics
6. ✅ **LAG/DIF** - Queue semantics vs. simple shift
7. ✅ **Numeric precision** - Currency, rounding, floating-point
8. ✅ **String handling** - Padding, truncation, comparisons
9. ✅ **Joins/merges** - Duplicate keys, one-to-many
10. ✅ **Statistical defaults** - Reference levels, missing handling
