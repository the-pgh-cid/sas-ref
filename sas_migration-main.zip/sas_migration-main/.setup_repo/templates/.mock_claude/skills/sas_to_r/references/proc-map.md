# SAS PROC to R Function Mapping

Comprehensive mapping of SAS procedures to R equivalents.

## Data Input/Output

| SAS | R Function | Library | Notes |
|-----|-----------|---------|-------|
| `PROC IMPORT` (CSV) | `fread()` | data.table | Fastest for large files |
| | `read_csv()` | readr | Tidyverse, good type detection |
| | `read.csv()` | base | Simple cases |
| | `read_csv_auto()` | DuckDB | Direct SQL query |
| `PROC IMPORT` (Excel) | `read_excel()` | readxl | Both .xls and .xlsx |
| | `read.xlsx()` | openxlsx | More Excel features |
| `PROC IMPORT` (Parquet) | `read_parquet()` | arrow | In-memory load |
| | `SELECT * FROM 'file.parquet'` | DuckDB | Query without loading |
| `PROC IMPORT` (SAS dataset) | `read_sas()` | haven | Reads .sas7bdat files |
| `PROC EXPORT` | `fwrite()` | data.table | Fast CSV writing |
| | `write_csv()` | readr | Tidyverse |
| | `write_parquet()` | arrow | Columnar format |
| | `COPY ... TO` | DuckDB | SQL-based export |
| `LIBNAME` | `dbConnect()` | DBI | Database connections |
| | File paths | base | Direct file access |
| `FILENAME` | File paths | base | URLs, paths |

---

## Data Manipulation

| SAS | R Function | Library | Notes |
|-----|-----------|---------|-------|
| `DATA` step | `[i, j, by]` syntax | data.table | Closest to DATA step |
| | `mutate()`, `filter()` | dplyr | Readable |
| | `SELECT`, `CREATE TABLE AS` | DuckDB | For SQL-heavy work |
| `SET` | Read existing object | base | N/A |
| `MERGE ... BY` | `merge()` | data.table | SAS-style merge |
| | `left_join()`, `inner_join()` | dplyr | SQL-style joins |
| | `JOIN` | DuckDB | SQL joins |
| `PROC SORT` | `setorder()` | data.table | In-place sorting |
| | `arrange()` | dplyr | Returns sorted copy |
| | `ORDER BY` | DuckDB | SQL sorting |
| `PROC SORT NODUPKEY` | `unique(..., by = )` | data.table | Keeps first occurrence |
| | `distinct(..., .keep_all = TRUE)` | dplyr | Keeps first occurrence |
| `PROC APPEND` | `rbindlist()` | data.table | Fast row binding |
| | `bind_rows()` | dplyr | Flexible row binding |
| | `INSERT INTO ... SELECT` | DuckDB | SQL append |
| `PROC TRANSPOSE` | `dcast()` / `melt()` | data.table | Wide ↔ long |
| | `pivot_wider()` / `pivot_longer()` | tidyr | Tidyverse reshaping |
| | `PIVOT` / `UNPIVOT` | DuckDB | SQL pivot |
| `PROC DATASETS` | `rm()`, `file.remove()` | base | Object/file management |
| | `DROP TABLE`, `ALTER TABLE` | DuckDB | SQL metadata |

---

## Aggregation and Summary

| SAS | R Function | Library | Notes |
|-----|-----------|---------|-------|
| `PROC MEANS` | `[, .(mean(), sd()), by = ]` | data.table | Grouped aggregation |
| | `group_by() %>% summarise()` | dplyr | Readable aggregation |
| | `SELECT AVG(), STDDEV() ... GROUP BY` | DuckDB | SQL aggregation |
| `PROC SUMMARY` | Same as PROC MEANS | | |
| `PROC FREQ` | `table()` | base | Simple frequency tables |
| | `[, .N, by = ]` | data.table | Grouped counts |
| | `count()` | dplyr | Frequency counts |
| | `SELECT COUNT(*) ... GROUP BY` | DuckDB | SQL frequency |
| `PROC TABULATE` | `xtabs()` | base | Cross-tabulation |
| | `dcast()` | data.table | Pivot aggregation |
| | `pivot_wider()` | tidyr | Reshape with aggregation |
| `PROC UNIVARIATE` | `summary()` | base | Basic summary stats |
| | `describe()` | psych | Detailed descriptives |
| | `skim()` | skimr | Modern summary |
| `PROC RANK` | `frank()` | data.table | Fast ranking |
| | `rank()`, `percent_rank()` | dplyr | Various ranking methods |
| | `NTILE()`, `RANK()` | DuckDB | SQL window functions |
| `PROC REPORT` | Aggregate data + `gt` / `flextable` | gt, flextable | Report formatting |

---

## SQL and Data Queries

| SAS | R Function | Library | Notes |
|-----|-----------|---------|-------|
| `PROC SQL` | `dbGetQuery()` | DBI + DuckDB | Full SQL support |
| | `[i, j, by]` | data.table | For simple queries |
| | `filter()`, `select()`, `group_by()` | dplyr | Verb-based queries |
| `PROC SQL CREATE TABLE` | `CREATE TABLE AS` | DuckDB | SQL table creation |
| | `<- result` | base | R assignment |
| `PROC SQL JOIN` | `JOIN` | DuckDB | SQL joins |
| | `dt1[dt2, on = ]` | data.table | data.table join |
| | `left_join()`, etc. | dplyr | dplyr joins |
| `PROC SQL UNION` | `UNION ALL` | DuckDB | SQL set operations |
| | `rbindlist()` | data.table | Row binding |
| | `bind_rows()` | dplyr | Row binding |
| `PROC SQL INTO :macro` | Scalar assignment | base | Extract to variable |

---

## Statistical Procedures

### Regression and GLM

| SAS | R Function | Library | Notes |
|-----|-----------|---------|-------|
| `PROC REG` | `lm()` | stats | Linear regression |
| `PROC GLM` | `lm()`, `aov()` | stats | ANOVA and linear models |
| `PROC LOGISTIC` | `glm(family = binomial)` | stats | Logistic regression |
| `PROC GENMOD` | `glm()` | stats | Generalized linear models |
| | `gam()` | mgcv | Generalized additive models |
| `PROC PROBIT` | `glm(family = binomial(link="probit"))` | stats | Probit regression |

### Mixed Models

| SAS | R Function | Library | Notes |
|-----|-----------|---------|-------|
| `PROC MIXED` | `lmer()` | lme4 | Linear mixed-effects models |
| | `lme()` | nlme | Alternative mixed models |
| `PROC GLIMMIX` | `glmer()` | lme4 | Generalized linear mixed models |
| `PROC NLMIXED` | `nlmer()` | lme4 | Nonlinear mixed models |

### Survival Analysis

| SAS | R Function | Library | Notes |
|-----|-----------|---------|-------|
| `PROC LIFETEST` | `survfit()` | survival | Kaplan-Meier curves |
| `PROC PHREG` | `coxph()` | survival | Cox proportional hazards |
| `PROC LIFEREG` | `survreg()` | survival | Parametric survival models |

### Time Series

| SAS | R Function | Library | Notes |
|-----|-----------|---------|-------|
| `PROC ARIMA` | `ARIMA()` | fable | Modern tidy time series |
| | `arima()` | stats | Base time series |
| `PROC FORECAST` | `ETS()`, `forecast()` | fable | Exponential smoothing |
| | `ets()`, `forecast()` | forecast | Legacy (still works) |
| `PROC ESM` | `ETS()` | fable | Exponential smoothing models |
| `PROC TIMESERIES` | `tsibble` data + `fable` | fable | Time series framework |
| `PROC UCM` | `StructTS()` | stats | Unobserved components |

### Survey Methods

| SAS | R Function | Library | Notes |
|-----|-----------|---------|-------|
| `PROC SURVEYSELECT` | `sample()` | base | Simple random sampling |
| | Survey design functions | survey | Complex sampling |
| `PROC SURVEYMEANS` | `svymean()`, `svytotal()` | survey | Survey-weighted means |
| `PROC SURVEYREG` | `svyglm()` | survey | Survey-weighted regression |
| `PROC SURVEYFREQ` | `svytable()` | survey | Survey-weighted frequencies |
| `PROC SURVEYLOGISTIC` | `svyglm(family = binomial)` | survey | Survey-weighted logistic |

### Multivariate

| SAS | R Function | Library | Notes |
|-----|-----------|---------|-------|
| `PROC FACTOR` | `factanal()` | stats | Factor analysis |
| | `fa()` | psych | Extended factor analysis |
| `PROC PRINCOMP` | `prcomp()`, `princomp()` | stats | Principal components |
| `PROC CANDISC` | `candisc()` | candisc | Canonical discriminant |
| `PROC DISCRIM` | `lda()`, `qda()` | MASS | Discriminant analysis |
| `PROC CLUSTER` | `hclust()` | stats | Hierarchical clustering |
| | `kmeans()` | stats | K-means clustering |

### Nonparametric

| SAS | R Function | Library | Notes |
|-----|-----------|---------|-------|
| `PROC NPAR1WAY` | `wilcox.test()`, `kruskal.test()` | stats | Nonparametric tests |
| `PROC CORR` | `cor()`, `cor.test()` | stats | Correlation |
| | Spearman, Kendall options | | Available in cor() |

---

## Machine Learning / Data Mining

| SAS | R Function | Library | Notes |
|-----|-----------|---------|-------|
| `PROC HPFOREST` | `ranger()` | ranger | Fast random forests |
| | `randomForest()` | randomForest | Classic implementation |
| `PROC HPLOGISTIC` | `glm()`, `glmnet()` | stats, glmnet | Regularized logistic |
| `PROC HPNEURAL` | `nnet()` | nnet | Neural networks |
| | `keras` / `torch` | keras, torch | Deep learning |
| `PROC HPSVM` | `svm()` | e1071 | Support vector machines |
| `PROC TREEBOOST` | `xgboost()` | xgboost | Gradient boosting |
| | `lightgbm()` | lightgbm | LightGBM |

---

## Data Quality and Validation

| SAS | R Function | Library | Notes |
|-----|-----------|---------|-------|
| `PROC COMPARE` | `all.equal()` | base | Comparison with tolerance |
| | `compare()` | waldo | Detailed differences |
| | `expect_equal()` | testthat | Testing framework |
| | Anti-joins, set operations | dplyr | Structural comparison |
| `PROC CONTENTS` | `str()` | base | Structure inspection |
| | `glimpse()` | dplyr | Tidyverse structure |
| | `skim()` | skimr | Comprehensive summary |
| `PROC PRINT` | `print()`, `head()` | base | Display data |
| | `View()` | utils | Interactive view |

---

## Reporting and Output

| SAS | R Function | Library | Notes |
|-----|-----------|---------|-------|
| `ODS PDF` | Quarto / R Markdown → PDF | quarto, rmarkdown | Reproducible reports |
| `ODS RTF` | `officer` | officer | Word/RTF output |
| `ODS EXCEL` | `write_xlsx()` | openxlsx | Excel workbooks |
| | `writexl::write_xlsx()` | writexl | Simple Excel export |
| `ODS HTML` | Quarto / R Markdown → HTML | quarto, rmarkdown | HTML reports |
| `PROC REPORT` | `gt`, `flextable` | gt, flextable | Formatted tables |
| `PROC TABULATE` | `gt`, `flextable` | gt, flextable | Cross-tabulation display |

---

## Utility Procedures

| SAS | R Function | Library | Notes |
|-----|-----------|---------|-------|
| `PROC FORMAT` | Lookup table + `left_join()` | dplyr | Code mapping via join |
| | `factor()` with levels/labels | base | Factor encoding |
| | `recode()`, `case_when()` | dplyr | Value recoding |
| `PROC FCMP` | User-defined functions | base | R function definition |
| | Vectorized expressions | | Native R expressions |
| `PROC CATALOG` | `ls()`, `objects()` | base | Object inspection |
| | Metadata queries | DuckDB | Database metadata |
| `PROC COPY` | `file.copy()` | base | File operations |
| `PROC DELETE` | `file.remove()`, `unlink()` | base | File deletion |
| `PROC OPTIONS` | `options()`, `getOption()` | base | R options |
| `PROC PRINTTO` | `sink()` | base | Redirect output |

---

## Macro Facilities

| SAS | R Approach | Notes |
|-----|-----------|-------|
| `%MACRO` / `%MEND` | R functions | Define reusable functions |
| `%LET` | Variable assignment | Regular R variables |
| `%IF %THEN %ELSE` | `if/else` | R control flow |
| `%DO %TO` | `for` loop | R iteration |
| `%DO %WHILE` | `while` loop | R loop |
| `CALL SYMPUT` | Variable assignment | Extract scalar from data |
| `&macrovar` | Variable reference | Regular R variable |
| `%STR` / `%NRSTR` | String literals | R strings |
| `%INCLUDE` | `source()` | Load external R code |
| Autocall macros | R packages/functions | Shared code libraries |

---

## Special Cases

### Custom Functions (PROC FCMP)
**SAS:**
```sas
PROC FCMP OUTLIB=work.funcs.test;
    FUNCTION myfunc(x);
        RETURN(x * 2 + 1);
    ENDSUB;
QUIT;
```

**R:**
```r
myfunc <- function(x) {
  x * 2 + 1
}

# Vectorized by default in most cases
```

---

### HASH Objects
**SAS HASH** is a procedural lookup structure.

**R equivalents:**
```r
# For simple lookups:
lookup_table <- setNames(values, keys)
result <- lookup_table[key]

# For relational joins:
left_join(dt1, dt2, by = "key")

# For keyed data.table:
setkey(dt, key)
dt[lookup_key]  # Fast binary search
```

---

## Quick Reference: Common Operations

### Load CSV
```r
dt <- fread("file.csv")                    # data.table
df <- read_csv("file.csv")                 # tidyverse
df <- dbGetQuery(con, "FROM 'file.csv'")   # DuckDB
```

### Filter Rows
```r
dt[age > 18]                              # data.table
df %>% filter(age > 18)                   # dplyr
dbGetQuery(con, "FROM df WHERE age > 18") # DuckDB
```

### Create Column
```r
dt[, new_col := old_col * 2]              # data.table
df <- df %>% mutate(new_col = old_col * 2) # dplyr
```

### Aggregate by Group
```r
dt[, .(total = sum(amount)), by = category]              # data.table
df %>% group_by(category) %>% summarise(total = sum(amount)) # dplyr
dbGetQuery(con, "SELECT category, SUM(amount) FROM df GROUP BY category") # DuckDB
```

### Join
```r
dt1[dt2, on = "key"]                      # data.table
left_join(df1, df2, by = "key")           # dplyr
dbGetQuery(con, "FROM df1 LEFT JOIN df2 ON df1.key = df2.key") # DuckDB
```

### Sort
```r
setorder(dt, -amount)                     # data.table (in-place)
df %>% arrange(desc(amount))              # dplyr
dbGetQuery(con, "FROM df ORDER BY amount DESC") # DuckDB
```

---

## Notes

- **Performance:** data.table generally fastest for in-memory; DuckDB for large files
- **Readability:** dplyr often most readable; use for team code
- **SQL users:** DuckDB most natural for SQL-heavy workflows
- **Statistical work:** Use specialized packages (lme4, survival, fable, etc.)
- **Mixed approach:** Combine libraries as appropriate (DuckDB for SQL → data.table for processing)
