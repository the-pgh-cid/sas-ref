# SAS Complexity Patterns

Patterns to identify during SAS program analysis that indicate migration complexity.

## Stateful DATA Step Logic

### RETAIN Statements
**Pattern:** `RETAIN variable_name <initial_value>;`

**Complexity:** Medium to High

**Why it matters:**
- Creates persistent state across DATA step iterations
- Not automatically preserved in Python/R
- May require cumulative functions or explicit state tracking

**What to note:**
- Number of RETAIN statements
- Conditional RETAIN resets
- RETAIN across BY groups
- Interdependencies between retained variables

**Example:**
```sas
DATA output;
    RETAIN total 0 count 0;
    SET input;
    BY customer_id;
    IF FIRST.customer_id THEN DO;
        total = 0;
        count = 0;
    END;
    total = total + amount;
    count + 1;
RUN;
```

---

### LAG and DIF Functions
**Pattern:** `LAG(variable)`, `LAG2(variable)`, `DIF(variable)`

**Complexity:** High

**Why it matters:**
- SAS LAG uses queue semantics, not simple previous-row access
- Conditional LAG calls create complex state dependencies
- Queue behavior doesn't map directly to shift()/lag() in Python/R

**What to note:**
- Unconditional LAG (simple) vs. conditional LAG (complex)
- LAG within IF/DO blocks
- Multiple LAG calls (LAG, LAG2, LAG3...)
- DIF with conditional execution

**Red flags:**
```sas
/* Conditional LAG - queue semantics! */
IF condition THEN prev = LAG(value);

/* Multiple LAG in loop */
DO i = 1 TO 3;
    lag_val = LAG(value);
END;
```

---

### FIRST. and LAST. Variables
**Pattern:** `BY variable; IF FIRST.variable THEN ...; IF LAST.variable THEN ...;`

**Complexity:** Medium

**Why it matters:**
- Requires data to be sorted by BY variables
- Boundary detection depends on sort order
- Target language grouping doesn't imply sort order

**What to note:**
- Number of BY variables
- Nested BY groups
- FIRST./LAST. with OUTPUT statements
- FIRST./LAST. controlling RETAIN resets

**Example:**
```sas
PROC SORT DATA=input; BY customer_id date; RUN;
DATA output;
    SET input;
    BY customer_id;
    IF FIRST.customer_id THEN total = 0;
    total + amount;
    IF LAST.customer_id THEN OUTPUT;
RUN;
```

---

### BY-Group Processing
**Pattern:** `BY variable_list; ... processing ...`

**Complexity:** Medium

**Why it matters:**
- Requires explicit sorting before processing
- Row order within groups must be preserved
- BY-group boundaries affect FIRST./LAST. and RETAIN

**What to note:**
- Single vs. multiple BY variables
- Nested BY groups
- Processing that depends on BY-group order

---

### Multiple OUTPUT Statements
**Pattern:** Multiple `OUTPUT dataset_name;` in DATA step

**Complexity:** Low to Medium

**Why it matters:**
- Rows are routed to different datasets based on conditions
- Must recreate routing explicitly with filters

**What to note:**
- Number of output datasets
- Routing conditions
- Whether same row can go to multiple outputs

**Example:**
```sas
DATA adults minors seniors;
    SET input;
    IF age >= 65 THEN OUTPUT seniors;
    ELSE IF age >= 18 THEN OUTPUT adults;
    ELSE OUTPUT minors;
RUN;
```

---

### Arrays
**Pattern:** `ARRAY array_name{n} variable_list; DO i = 1 TO n; ... END;`

**Complexity:** Medium

**Why it matters:**
- Iterative processing over variables
- May map to vectorized operations or explicit loops

**What to note:**
- Array size
- Operations performed on array elements
- Multidimensional arrays
- Temporary vs. variable-based arrays

---

### SAS Automatic Variables
**Pattern:** `_N_`, `_ERROR_`, `_IORC_`

**Complexity:** Low to Medium

**Why it matters:**
- Automatic variables control flow or track state
- Must be recreated explicitly

**What to note:**
- `_N_`: iteration counter
- `_ERROR_`: error flag
- `_IORC_`: I/O return code

---

## Date and Time Functions

### INTCK (Interval Counting)
**Pattern:** `INTCK('interval', start_date, end_date)`

**Complexity:** High

**Why it matters:**
- SAS has specific boundary rules that differ from simple arithmetic
- Month boundaries, leap years, week start days all affect results

**What to note:**
- Interval types used ('MONTH', 'YEAR', 'WEEK', 'QTR', 'DAY')
- Whether 'C' (continuous) or 'D' (discrete) modifier used
- Alignment parameter if present

**Test cases needed:**
- Month-end dates (Jan 31 → Feb 1)
- Leap years
- Year boundaries
- Week intervals with different start days

---

### INTNX (Interval Advancement)
**Pattern:** `INTNX('interval', date, increment, 'alignment')`

**Complexity:** High

**Why it matters:**
- Alignment options ('BEGINNING', 'MIDDLE', 'END', 'SAME') affect month-end dates
- SAME alignment has special month-end rules

**What to note:**
- Interval types
- Alignment parameter (critical for month-end)
- Negative increments
- Multiple INTNX calls (chained date arithmetic)

**Test cases needed:**
- Jan 31 + 1 month with each alignment
- Leap year dates
- Quarter/year boundaries

---

### YRDIF (Year Fractions)
**Pattern:** `YRDIF(start_date, end_date, 'basis')`

**Complexity:** High

**Why it matters:**
- Multiple basis conventions ('ACT/ACT', 'ACT/360', '30/360', etc.)
- Each convention has different calculation rules
- No direct equivalent in Python/R

**What to note:**
- Basis convention used
- Whether partial years matter for calculations

---

### Other Date Functions
**Pattern:** `MDY()`, `TODAY()`, `DATDIF()`, `DATEPART()`, `TIMEPART()`

**Complexity:** Low to Medium

**What to note:**
- Date literals ('01JAN2024'd)
- Datetime vs. date vs. time variables
- Format/informat specifications

---

## Missing Value Handling

### Special Missing Values
**Pattern:** `.` (standard missing), `._`, `.A` through `.Z` (special missing)

**Complexity:** High

**Why it matters:**
- Python/R don't have equivalent special missing categories
- Special missing values carry meaning (refused, not applicable, etc.)
- Sort order differs from standard missing

**What to note:**
- Use of special missing values in data
- Missing value comparisons in logic
- Missing values in BY-group processing
- Formats that display missing values differently

**Example:**
```sas
IF value = ._ THEN status = 'Refused';
ELSE IF value = .A THEN status = 'Not Applicable';
ELSE IF value = . THEN status = 'Missing';
```

---

### Missing Value Comparisons
**Pattern:** Comparisons involving missing values

**Complexity:** Medium

**Why it matters:**
- SAS has specific rules for missing value comparisons
- Missing values sort low in SAS
- Target language may handle differently

**What to note:**
- `IF variable = .`
- `IF variable IN (., ._, .A)`
- Missing values in WHERE vs. IF

---

## Character Variable Handling

### Fixed-Length Character Variables
**Pattern:** `LENGTH variable $n;`

**Complexity:** Medium

**Why it matters:**
- SAS character variables have declared length
- Can be padded or truncated silently
- Python/R strings are variable-length

**What to note:**
- Length specifications
- Whether padding affects joins or comparisons
- Truncation in assignments

---

### Character Functions
**Pattern:** `SUBSTR()`, `SCAN()`, `COMPRESS()`, `TRIM()`, `LEFT()`, `CAT*()`

**Complexity:** Low to Medium

**What to note:**
- Fixed-position substring extraction
- COMPRESS modifiers ('kd', 'ka', etc.)
- String concatenation with padding

---

## PROC SQL Patterns

### Complex Queries
**Complexity:** Low to Medium (usually straightforward translation)

**What to note:**
- Subqueries
- Multiple joins
- Window functions (if using SAS 9.4+)
- CALCULATED keyword
- Remerging summary statistics

---

### Non-Standard SQL
**Pattern:** SAS-specific SQL extensions

**Complexity:** Medium

**What to note:**
- `PROC SQL INTO :macrovar` (macro variable assignment)
- Implicit type conversions
- Missing value handling in SQL

---

## MERGE Patterns

### MERGE with Duplicate Keys
**Pattern:** `MERGE dataset1 dataset2; BY key;` with duplicates on both sides

**Complexity:** High

**Why it matters:**
- SAS MERGE has specific behavior with duplicate keys
- Different from SQL JOIN
- One-to-many vs. many-to-many behavior

**What to note:**
- Whether duplicate keys exist in either dataset
- IN= dataset options
- Whether behavior is relational join or sequential merge

---

## Advanced Features

### HASH Objects
**Pattern:** `DECLARE HASH h(...); h.DEFINEKEY(...); h.DEFINEDATA(...);`

**Complexity:** High

**Why it matters:**
- Procedural lookup structure, not simple table join
- May be used for performance or specific algorithms
- No direct equivalent

**What to note:**
- Hash table purpose (lookup, duplicate elimination, ordering)
- Key and data definitions
- Methods used (FIND, ADD, CHECK, etc.)

---

### PROC FCMP (Custom Functions)
**Pattern:** `PROC FCMP; FUNCTION name(...); ... ENDSUB;`

**Complexity:** Medium to High

**Why it matters:**
- Custom functions may encapsulate complex logic
- Need to understand function behavior for conversion

**What to note:**
- Function signatures
- Function logic
- Where functions are used

---

### PROC FORMAT (Value Mappings)
**Pattern:** `PROC FORMAT; VALUE format_name low-high='label';`

**Complexity:** Low to Medium

**Why it matters:**
- Formats are presentation but can affect PROC output
- May need to be converted to lookup tables or mappings

**What to note:**
- Custom format definitions
- Where formats are applied
- Whether formats affect calculations (shouldn't, but check)

---

### Complex Macro Logic
**Pattern:** Macros with conditional generation, loops, or text manipulation

**Complexity:** Medium to High

**Why it matters:**
- Text-generating macros don't map to simple functions
- May require expression building or metaprogramming

**What to note:**
- Macro complexity (simple parameter substitution vs. code generation)
- Use of macro conditionals (%IF)
- Use of macro loops (%DO)
- String manipulation (%STR, %QUOTE, etc.)

---

## Statistical Procedures

### Complex Procedures
**Complexity:** Varies by procedure

**What to note:**
- PROC REG / GLM / LOGISTIC: Model specifications
- PROC MIXED: Random effects, covariance structures
- PROC ARIMA: Time series model orders
- PROC SURVEYSELECT: Sampling design
- PROC LIFETEST / PHREG: Survival models

**Check for:**
- Custom parameterizations
- Specific options that affect output
- BY-group processing in procedures
- OUTPUT datasets with specific statistics

---

## Performance and Scale

### Large Data Indicators
**Complexity:** Affects library choice

**What to note:**
- File sizes mentioned
- BY-group sizes
- Whether code mentions performance tuning
- Use of indexes
- MEMSIZE/SORTSIZE options

---

## Dependency Complexity

### External Dependencies
**Complexity:** Varies

**What to note:**
- External databases (LIBNAME ODBC, ORACLE, etc.)
- Shared macro libraries (SASAUTOS=)
- External files (FILENAME)
- Include files (%INCLUDE)
- Format catalogs

---

## Scoring Guide

**Low Complexity:**
- Standard PROC SQL, MEANS, FREQ
- Simple DATA steps (no RETAIN, LAG, BY-groups)
- No special missing values
- No date edge cases

**Medium Complexity:**
- RETAIN with BY-groups
- FIRST./LAST. processing
- Standard date functions (no edge cases)
- Simple macros
- Character padding considerations

**High Complexity:**
- Conditional LAG/DIF
- Special missing values
- INTCK/INTNX with edge cases
- HASH objects
- Complex macros generating code
- MERGE with duplicate keys

**Very High Complexity:**
- Multiple high-complexity patterns combined
- Custom PROC FCMP functions with complex logic
- Intricate state dependencies
- Undocumented business logic
