# SAS Program Analysis Report Template

Use this template structure for all SAS program analysis reports.

---

# SAS Program Analysis: [Filename]

**Analysis Date:** [Date]
**Analyst:** Claude (sas-analyze skill)
**Original File:** [Path to SAS file]

---

## Executive Summary

[2-3 sentence summary of program purpose, complexity level, and recommended approach]

**Complexity:** [Low / Medium / High / Very High]
**Recommended Target:** [Python (Polars/DuckDB) / R (data.table/DuckDB) / Both]
**Estimated Effort:** [Hours/Days]

---

## Overview

- **Lines of Code:** [count]
- **DATA Steps:** [count]
- **PROC Statements:** [count]
- **Macro Definitions:** [count]
- **External Dependencies:** [count]

---

## Procedures Used

List all procedures with counts and brief description of usage:

### [PROC NAME] - [count] occurrences
- **Purpose:** [What it does in this program]
- **Complexity:** [Low / Medium / High]
- **Target Equivalent:** [Polars/DuckDB/pandas function or R package]
- **Line References:** [Line numbers]

**Example:**
### PROC SQL - 3 occurrences
- **Purpose:** Join customer and transaction data, aggregate sales by region
- **Complexity:** Low (standard SQL joins and GROUP BY)
- **Target Equivalent:** DuckDB SQL or Polars .join() + .group_by()
- **Line References:** 45, 123, 201

---

## DATA Step Patterns

### Standard Transformations
- **Count:** [count]
- **Complexity:** Low
- **Details:** [Brief description]

### Complex Patterns

#### RETAIN Statements
- **Present:** [Yes / No]
- **Count:** [count if present]
- **Complexity:** [Low / Medium / High]
- **Details:** [Description of RETAIN usage]
- **Line References:** [Lines]

#### LAG/DIF Functions
- **Present:** [Yes / No]
- **Type:** [Unconditional / Conditional]
- **Complexity:** [Low / Medium / High]
- **Queue Semantics Risk:** [Low / High]
- **Details:** [Description]
- **Line References:** [Lines]

#### FIRST. / LAST. Variables
- **Present:** [Yes / No]
- **BY Variables:** [List]
- **Complexity:** [Low / Medium / High]
- **Details:** [Description]
- **Line References:** [Lines]

#### BY-Group Processing
- **Present:** [Yes / No]
- **BY Variables:** [List]
- **Complexity:** [Low / Medium / High]
- **Sort Requirements:** [Description]
- **Line References:** [Lines]

#### Multiple OUTPUT Statements
- **Present:** [Yes / No]
- **Output Datasets:** [count]
- **Routing Logic:** [Description]
- **Line References:** [Lines]

#### Arrays
- **Present:** [Yes / No]
- **Count:** [count]
- **Complexity:** [Low / Medium / High]
- **Details:** [Description]
- **Line References:** [Lines]

---

## Date/Time Functions

### INTCK
- **Present:** [Yes / No]
- **Intervals Used:** [MONTH, YEAR, etc.]
- **Edge Cases:** [Month-end, leap year, etc.]
- **Complexity:** [Low / Medium / High]
- **Line References:** [Lines]

### INTNX
- **Present:** [Yes / No]
- **Alignments Used:** [BEGINNING, END, SAME, etc.]
- **Complexity:** [Low / Medium / High]
- **Line References:** [Lines]

### YRDIF
- **Present:** [Yes / No]
- **Basis:** [ACT/ACT, 30/360, etc.]
- **Complexity:** [High]
- **Line References:** [Lines]

### Other Date Functions
- **Functions:** [MDY, TODAY, etc.]
- **Complexity:** [Low / Medium]

---

## Missing Value Handling

### Special Missing Values
- **Present:** [Yes / No]
- **Types Used:** [._, .A-.Z]
- **Semantic Meaning:** [Description of what each represents]
- **Impact:** [High if present]
- **Line References:** [Lines]

### Missing Value Comparisons
- **Present:** [Yes / No]
- **Complexity:** [Low / Medium]
- **Details:** [Description]

---

## Character Variables

### Fixed-Length Variables
- **Present:** [Yes / No]
- **Padding/Truncation Risk:** [Low / Medium / High]
- **Impact on Joins:** [Description]

### String Functions
- **Functions Used:** [SUBSTR, COMPRESS, etc.]
- **Complexity:** [Low / Medium]

---


## Macros

### Macro Definitions
- **Count:** [count]
- **Names:** [List]

### Macro Complexity Assessment

#### [Macro Name]
- **Type:** [Simple parameter substitution / Code generation / Complex logic]
- **Complexity:** [Low / Medium / High]
- **Usage Count:** [count]
- **Details:** [Description]
- **Line References:** [Definition: line X, Calls: lines Y, Z]

---

## Dependencies

### Input Data Sources
- [Dataset/file 1] - [Format, location]
- [Dataset/file 2] - [Format, location]

### Output Data
- [Dataset/file 1] - [Format, purpose]
- [Dataset/file 2] - [Format, purpose]

### External Dependencies
- Databases: [List with connection types]
- Shared macros: [List with sources]
- Format catalogs: [List]
- Include files: [List]

---

## Migration Complexity Assessment

### Overall Complexity: [Low / Medium / High / Very High]

### Complexity Factors

#### High-Complexity Patterns
1. **[Pattern Name]** - [Brief explanation of why it's complex]
   - Impact: [Description]
   - Line References: [Lines]

2. **[Pattern Name]** - [Brief explanation]
   - Impact: [Description]
   - Line References: [Lines]

#### Medium-Complexity Patterns
1. **[Pattern Name]** - [Brief explanation]
2. **[Pattern Name]** - [Brief explanation]

#### Low-Complexity Patterns
- [List standard patterns that are straightforward]

---

## Semantic Traps to Test

**Critical validation points based on complexity patterns found:**

- [ ] **Row order preservation** - [Reason / line references]
- [ ] **BY-group processing semantics** - [Details]
- [ ] **LAG/DIF queue behavior** - [Test cases needed]
- [ ] **Missing value handling** - [Special missing encoding]
- [ ] **Date function edge cases** - [INTCK/INTNX alignment, month-end, leap years]
- [ ] **Character variable padding/truncation** - [Details]
- [ ] **Numeric precision** - [Currency, rounding]
- [ ] **MERGE vs. JOIN behavior** - [Duplicate key handling]
- [ ] **[Custom item based on analysis]** - [Details]


### Conversion Sequence

```
1. Data loading (PROC IMPORT) → [Target approach]
2. Standard DATA steps → [Target approach]
3. PROC SQL → [Target approach]
4. Complex DATA steps (RETAIN, LAG) → [Approach with extra care]
5. PROCs (MEANS, FREQ) → [Target functions]
6. Statistical procedures → [Target packages]
7. Macros → [Target functions/logic]
```

## Validation Requirements

### Row-Level Validation
- [ ] Row count comparison (overall)
- [ ] Row counts by [key groups]
- [ ] Sort order verification

### Aggregate Validation
- [ ] Sum of [key columns]
- [ ] Mean of [key columns]
- [ ] Count of [groups]
- [ ] [Custom aggregates]

### Edge Case Testing
- [ ] [Specific edge case from analysis]
- [ ] [Specific edge case from analysis]

### Reconciliation Checklist
- [ ] Schema match (columns, types)
- [ ] Distinct key values match
- [ ] Null counts match
- [ ] Date function results (test with edge cases)
- [ ] [Custom check based on complexity]


---

## Next Steps

1. **Immediate:** [First action item]
2. **Before Conversion:** [Preparation needed]
3. **During Conversion:** [Key focus areas]
4. **Validation:** [Critical tests]
5. **Production:** [Deployment considerations]


### Reference Documentation

- Project migration guide (Python): `sas_convert_doc/sas_to_polars.md`, `sas_to_duckdb.md`
- Project migration guide (R): `sas_convert_doc/sas_to_r.md`
- Gotchas: `sas_to_python/references/gotchas.md` or `sas_to_r/references/gotchas.md`
- Proc mapping: `sas_to_python/references/proc-map.md` or `sas_to_r/references/proc-map.md`

---

**End of Analysis Report**
