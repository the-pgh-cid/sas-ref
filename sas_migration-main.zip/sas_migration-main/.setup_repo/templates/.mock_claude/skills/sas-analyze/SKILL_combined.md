---
name: sas-analyze
description: Deep analysis of SAS code structure to understand migration requirements and complexity
---

# SAS Program Analysis

Inventory and analyze SAS programs to assess migration complexity and recommend conversion approach.

## When to Use

- Starting analysis of a new SAS program or project
- Planning migration strategy
- Building project inventory across multiple programs
- User asks to "analyze", "inventory", "assess", or "understand" SAS code

## Required Reading

**Reference materials:**
- [references/complexity-patterns.md](references/complexity-patterns.md) - Patterns to identify
- [references/report-template.md](references/report-template.md) - Analysis report structure

## Workflow

### 1. Read SAS Program
- Read the SAS file(s)
- Parse high-level structure (DATA steps, PROCs, macros)

### 2. Catalog Components
- List all PROC statements used
- Count DATA steps
- Identify macro definitions
- Note input/output operations

### 3. Identify Complexity Patterns
**Scan for patterns in `complexity-patterns.md`:**
- Stateful DATA step logic (RETAIN, LAG/DIF, FIRST./LAST.)
- Date/time functions (INTCK, INTNX, YRDIF)
- Missing value handling (special missing)
- Character variables (fixed-length specifics)
- Advanced features (HASH, PROC FCMP, formats, complex macros)

### 4. Map Dependencies
- Input datasets/files
- Output datasets/files
- Intermediate datasets
- External dependencies

### 5. Recommend Target Approach
**For Python:**
- DuckDB: PROC SQL heavy, relational, large files, lazy
- Polars: DataFrame transformations, lazy evaluation
- Pandas + libraries: Mixed workload with statistical procedures

**For R:**
- DuckDB + R: SQL heavy with statistical procedures
- data.table: High-performance, stateful BY-group processing
- tidyverse/dplyr: Readable transformations
- Specialized packages: Statistical procedures

### 6. Generate Analysis Report
**Use structure from `report-template.md`:**
- Overview (LOC, counts)
- Procedures used
- DATA step patterns
- Complexity assessment
- Migration approach recommendation
- Validation requirements
- Estimated effort

## Rules

### Be Thorough
- Don't skip complexity patterns even if they seem small
- Flag uncertainty when code behavior is ambiguous
- Reference line numbers and actual SAS code snippets
- Consider data volumes and performance implications

### Prioritize Correctness
- Emphasize semantic traps that could cause silent failures
- Note where SAS and target language differ
- List specific test cases needed

### Provide Actionable Recommendations
- Recommend specific libraries/approaches
- Provide effort estimates
- Suggest migration sequence
- Reference appropriate migration guides

## Output Format

Generate structured markdown report using template from `references/report-template.md`.

Include:
- ✅ Overview statistics
- ✅ Component catalog
- ✅ Complexity assessment with severity
- ✅ Semantic traps checklist
- ✅ Recommended approach with rationale
- ✅ Validation requirements
- ✅ Effort estimate

## Key References

- **Complexity patterns:** What to look for → [references/complexity-patterns.md](references/complexity-patterns.md)
- **Report template:** Structure and format → [references/report-template.md](references/report-template.md)
