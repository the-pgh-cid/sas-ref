# SAS to Python Semantic Gotchas

Critical semantic differences and edge cases that require explicit testing.

## Missing Values

### Character Missing: Empty String vs NULL
**Issue:** **SAS character missing values are empty strings (`''`), not NULL.** SQL/DuckDB use NULL for missing. This is a critical semantic difference.

**SAS behavior:**
```sas
DATA test;
    LENGTH name $20;
    name = "";      /* Missing character = empty string */
    IF name = "" THEN flag = 1;  /* TRUE */
    IF MISSING(name) THEN flag2 = 1;  /* TRUE */
RUN;
```

**Python/DuckDB difference:**
```python
# DuckDB - NULL is NOT empty string:
duckdb.sql("""
    SELECT
        name,
        name = '' AS is_empty_string,     -- FALSE if NULL
        name IS NULL AS is_null,          -- TRUE if NULL
        COALESCE(name, '') = '' AS is_missing  -- SAS-like check
    FROM df
""")

# Polars - similar distinction:
df.with_columns([
    (pl.col("name") == "").alias("is_empty_string"),      # False if null
    pl.col("name").is_null().alias("is_null"),            # True if null
    ((pl.col("name").is_null()) | (pl.col("name") == "")).alias("is_missing")  # SAS-like
])
```

**Migration strategy:**
```python
# Option 1: Convert empty strings to NULL on load (SQL-standard)
df = df.with_columns(
    pl.when(pl.col("name") == "").then(None).otherwise(pl.col("name")).alias("name")
)

# Option 2: Keep empty strings, adjust logic
# Replace SAS: IF name = ""
# With: (name IS NULL OR name = '')

# DuckDB:
duckdb.sql("SELECT * FROM df WHERE name IS NULL OR name = ''")

# Polars:
df.filter((pl.col("name").is_null()) | (pl.col("name") == ""))
```

**Test cases:**
- Empty string vs NULL in filters
- Empty string in joins (may not match NULL)
- Empty string in sorts (NULL sorts differently)
- COALESCE behavior
- Concatenation with empty vs NULL

---

### Numeric Missing Values
**Issue:** SAS has numeric missing (`.`) and special missing (`._`, `.A`-`.Z`) with different semantics. Python/SQL only have NULL (or NaN in pandas).

**Impact:**
- SAS sorts missing values differently than Python
- Special missing values carry meaning (._  = not applicable, .A = refused, etc.)
- Arithmetic and comparisons behave differently

**Solutions:**

**Polars:**
```python
# Option 1: Encode as categorical
df = df.with_columns(
    pl.when(pl.col("value").is_null())
      .then(pl.lit("missing"))
      .when(pl.col("value") == special_code)
      .then(pl.lit("refused"))
      .otherwise(pl.lit("valid"))
      .alias("value_category")
)

# Option 2: Separate indicator column
df = df.with_columns([
    pl.col("value").is_null().alias("value_is_missing"),
    # encode special missing type
])
```

**DuckDB:**
```sql
-- Option 1: CASE expression for special missing
SELECT
    value,
    CASE
        WHEN value IS NULL THEN 'missing'
        WHEN value = special_code THEN 'refused'
        ELSE 'valid'
    END AS value_category
FROM df

-- Option 2: Separate indicator column
SELECT
    value,
    value IS NULL AS value_is_missing
FROM df
```

**Test cases:**
- All-missing column
- Partially-missing column
- Special missing in BY-group processing
- Missing values in sorts
- Missing values in joins
- Empty string vs NULL for character variables ⚠️

---

## DATA Step Mechanics

### RETAIN Statement
**Issue:** SAS RETAIN creates persistent variables across DATA step iterations. Not automatic in Python.

**SAS behavior:**
```sas
DATA output;
    RETAIN total 0;
    SET input;
    total = total + amount;
RUN;
```

**Python equivalents:**

**Polars:**
```python
# Cumulative operations:
df = df.with_columns(
    total = pl.col("amount").cum_sum()
)

# By-group cumulative:
df = df.with_columns(
    pl.col("amount").cum_sum().over("customer_id").alias("total")
)
```

**DuckDB:**
```sql
-- Overall cumulative sum:
SELECT *, SUM(amount) OVER (ORDER BY row_num) AS total
FROM df

-- By-group cumulative:
SELECT *,
    SUM(amount) OVER (PARTITION BY customer_id ORDER BY row_num) AS total
FROM df
```

**Test cases:**
- Simple cumulative sum
- RETAIN with conditional reset
- RETAIN across BY groups
- Multiple RETAIN variables with interdependencies

---

### LAG and DIF Functions
**Issue:** SAS LAG/DIF use **queue semantics** that track across conditional execution. Python's `shift()` is simple previous-row.

**SAS behavior:**
```sas
DATA output;
    SET input;
    IF condition THEN DO;
        prev = LAG(value);  /* Queue behavior */
    END;
RUN;
```

**Critical difference:**
- SAS LAG maintains a queue populated **every time LAG is executed**
- Python shift/lag simply accesses previous row
- Conditional LAG calls in SAS don't map to conditional shift

**Python approach:**

**Polars - Simple previous-row (often correct):**
```python
# Unconditional LAG (simple shift):
df = df.with_columns(
    prev_value = pl.col("value").shift(1)
)

# By-group LAG:
df = df.with_columns(
    prev_value = pl.col("value").shift(1).over("customer_id")
)

# For SAS queue semantics with conditional LAG, need explicit state tracking
```

**DuckDB - Window functions:**
```sql
-- Unconditional LAG:
SELECT *, LAG(value) OVER (ORDER BY id) AS prev_value
FROM df

-- By-group LAG:
SELECT *, LAG(value) OVER (PARTITION BY customer_id ORDER BY id) AS prev_value
FROM df

-- Multiple lags:
SELECT *,
    LAG(value, 1) OVER (ORDER BY id) AS lag1_value,
    LAG(value, 2) OVER (ORDER BY id) AS lag2_value
FROM df
```

**⚠️ Critical:** For conditional LAG in SAS (LAG inside IF), simple shift/window LAG is **incorrect**. Need explicit queue implementation.

**Test cases:**
- Unconditional LAG (shift works)
- Conditional LAG (queue semantics)
- Multiple LAG calls (LAG2, LAG3)
- LAG in DO loops
- DIF with conditional execution

---

### FIRST. and LAST. Variables
**Issue:** SAS FIRST./LAST. depend on DATA sorted by BY variables. Python grouping doesn't automatically imply order.

**SAS requirement:**
```sas
PROC SORT DATA=input; BY customer_id date; RUN;
DATA output;
    SET input;
    BY customer_id;
    IF FIRST.customer_id THEN total = 0;
RUN;
```

**Python approach:**

**Polars:**
```python
# Must explicitly sort first:
df = df.sort("customer_id", "date")

# Identify boundaries:
df = df.with_columns([
    pl.col("customer_id").is_first_distinct().alias("first_customer"),
    pl.col("customer_id").is_last_distinct().alias("last_customer")
])

# Or use groupby operations:
df.group_by("customer_id").first()  # First row per group
df.group_by("customer_id").last()   # Last row per group
```

**DuckDB:**
```sql
-- Identify first/last using ROW_NUMBER:
SELECT *,
    ROW_NUMBER() OVER (PARTITION BY customer_id ORDER BY date) = 1 AS first_customer,
    ROW_NUMBER() OVER (PARTITION BY customer_id ORDER BY date DESC) = 1 AS last_customer
FROM df
ORDER BY customer_id, date

-- Or get first/last rows per group:
SELECT DISTINCT ON (customer_id) *
FROM df
ORDER BY customer_id, date  -- First row

SELECT DISTINCT ON (customer_id) *
FROM df
ORDER BY customer_id, date DESC  -- Last row
```

**Test cases:**
- Single BY variable
- Multiple BY variables
- Verify sort order preserved
- FIRST./LAST. with conditional OUTPUT
- Nested BY groups

---

### BY-Group Processing Order
**Issue:** SAS processes BY groups sequentially in sorted order. Python operations don't guarantee order unless explicit.

**Critical:**
- Always sort explicitly before BY-group operations
- Verify sort order matches SAS BY statement
- Test that row order within groups is preserved

```python
# Polars - explicit sort:
df = df.sort("customer_id", "date")

# Then grouped operations:
df = df.with_columns(
    pl.col("amount").sum().over("customer_id").alias("total")
)
```

---

## Joins vs. MERGE

### Duplicate Keys in MERGE
**Issue:** SAS MERGE with duplicate keys behaves differently than SQL JOIN.

**SAS MERGE behavior with duplicates:**
- Cartesian product within BY group
- One-to-many: SAS retains last value from "one" side
- Specific replication rules

**Python joins:**

**Polars (SQL-style Cartesian product with duplicates):**
```python
# Left join:
result = df1.join(df2, on="key", how="left")

# Inner join:
result = df1.join(df2, on="key", how="inner")

# Full outer join:
result = df1.join(df2, on="key", how="full")

# Multiple keys:
result = df1.join(df2, on=["key1", "key2"], how="left")
```

**DuckDB (SQL-style):**
```sql
-- Left join:
SELECT a.*, b.category
FROM df1 a
LEFT JOIN df2 b ON a.key = b.key

-- Multiple keys:
SELECT a.*, b.*
FROM df1 a
LEFT JOIN df2 b ON a.key1 = b.key1 AND a.key2 = b.key2

-- Handle duplicate keys (many-to-many):
-- Both produce Cartesian product within key group
SELECT a.*, b.*
FROM df1 a
INNER JOIN df2 b ON a.key = b.key
```

**⚠️ Critical:** SQL joins (Polars/DuckDB) produce Cartesian product with duplicate keys. SAS MERGE has **different** duplicate key semantics - test thoroughly!

**Test cases:**
- One-to-one merge
- One-to-many merge
- Many-to-many merge (verify behavior matches)
- Non-matching keys
- Multiple BY variables

---

## Date Functions

### INTCK (Interval Counting)
**Issue:** SAS INTCK has specific boundary rules that don't match simple date arithmetic.

**SAS semantics:**
```sas
months = INTCK('MONTH', '01JAN2024'd, '28FEB2024'd);  /* = 1 */
months = INTCK('MONTH', '31JAN2024'd, '01FEB2024'd);  /* = 1 */
```

**Python approach:**

**Polars:**
```python
# Approximate month difference:
df = df.with_columns(
    months = (
        pl.col("end_date").dt.year() - pl.col("start_date").dt.year()
    ) * 12 + (
        pl.col("end_date").dt.month() - pl.col("start_date").dt.month()
    )
)
# ⚠️ WARNING: Boundary rules may differ from SAS! Test edge cases.
```

**DuckDB:**
```sql
-- Month difference (approximation):
SELECT
    (EXTRACT(YEAR FROM end_date) - EXTRACT(YEAR FROM start_date)) * 12 +
    (EXTRACT(MONTH FROM end_date) - EXTRACT(MONTH FROM start_date)) AS months
FROM df

-- Or use date_diff (available in DuckDB):
SELECT date_diff('month', start_date, end_date) AS months
FROM df

-- Week difference:
SELECT date_diff('week', start_date, end_date) AS weeks
FROM df
```

**⚠️ Critical:** Boundary crossing rules differ! SAS `INTCK('MONTH', '31JAN2024'd, '01FEB2024'd) = 1` may not match SQL month_diff. Test edge cases!

**Test cases:**
- Month boundaries (31st to 1st)
- Leap years (Feb 29)
- Year boundaries
- Week intervals
- Business day calculations

---

### INTNX (Interval Advancement)
**Issue:** SAS INTNX has alignment options ('BEGINNING', 'MIDDLE', 'END', 'SAME') that affect month-end dates.

**SAS behavior:**
```sas
/* Jan 31 + 1 month, 'SAME' alignment */
next_month = INTNX('MONTH', '31JAN2024'd, 1, 'SAME');
```

**Python approach:**

**Polars:**
```python
# Month advancement (INTNX 'SAME' alignment):
df = df.with_columns(
    next_month = pl.col("date").dt.offset_by("1mo")
)

# Month start alignment (INTNX 'BEGINNING'):
df = df.with_columns(
    next_month = pl.col("date").dt.offset_by("1mo").dt.month_start()
)

# Month end alignment (INTNX 'END'):
df = df.with_columns(
    next_month = pl.col("date").dt.offset_by("1mo").dt.month_end()
)
```

**DuckDB:**
```sql
-- Month advancement (add interval):
SELECT date + INTERVAL 1 MONTH AS next_month
FROM df

-- Month start alignment:
SELECT DATE_TRUNC('month', date + INTERVAL 1 MONTH) AS next_month_start
FROM df

-- Month end alignment:
SELECT (DATE_TRUNC('month', date + INTERVAL 1 MONTH) + INTERVAL 1 MONTH - INTERVAL 1 DAY) AS next_month_end
FROM df

-- Quarter advancement:
SELECT date + INTERVAL 1 QUARTER AS next_quarter
FROM df

-- Year advancement:
SELECT date + INTERVAL 1 YEAR AS next_year
FROM df
```

**⚠️ Edge case:** Jan 31 + 1 month = ? (SAS 'SAME' tries to preserve day, may result in Feb 28/29)

**Test cases:**
- Month-end dates (Jan 31, Feb 28/29, Dec 31)
- Alignment options
- Negative intervals
- Year/quarter boundaries

---

### YRDIF (Year Fractions)
**Issue:** SAS YRDIF supports multiple basis conventions ('ACT/ACT', 'ACT/360', '30/360', etc.). Python has no direct equivalent.

**Python approach:**

**Polars:**
```python
# Simple time-based (ACT/365.25 approximation):
df = df.with_columns(
    years = (pl.col("end_date") - pl.col("start_date")).dt.total_days() / 365.25
)

# ACT/ACT basis (actual days / actual days in year):
df = df.with_columns(
    years = (pl.col("end_date") - pl.col("start_date")).dt.total_days() /
            pl.col("end_date").dt.year().is_leap_year().cast(pl.Int32).mul(366).add(
                (~pl.col("end_date").dt.year().is_leap_year()).cast(pl.Int32).mul(365)
            )
)
```

**DuckDB:**
```sql
-- Simple time-based (ACT/365.25 approximation):
SELECT
    CAST(date_diff('day', start_date, end_date) AS DOUBLE) / 365.25 AS years
FROM df

-- ACT/360 basis (common in finance):
SELECT
    CAST(date_diff('day', start_date, end_date) AS DOUBLE) / 360.0 AS years
FROM df

-- For 30/360 and other conventions, implement custom logic
```

**⚠️ Critical:** YRDIF conventions (ACT/ACT, ACT/360, 30/360) affect age calculations, interest rates, and financial computations. Must match SAS basis exactly!

**Test cases:**
- Leap years
- Different conventions
- Partial years
- Negative periods

---

## Numeric Precision and Rounding

### Floating-Point Precision
**Issue:** Both SAS and Python use IEEE 754 double-precision, but accumulation errors can differ.

**Test cases:**
- Currency calculations (use explicit rounding)
- Cumulative sums of floating-point values
- Equality comparisons of calculated values
- Extremely large/small numbers

**Best practice:**
```python
# Polars - for currency, work in cents:
df = df.with_columns(
    amount_cents = (pl.col("amount") * 100).round(0).cast(pl.Int64)
)

# For comparisons with tolerance:
import numpy as np
np.isclose(result, expected, atol=1e-8)
```

---

### ROUND Function
**Issue:** SAS ROUND and Python round() can differ for .5 values.

**Python default:**
```python
round(2.5)  # = 2 (banker's rounding, rounds to even)
round(3.5)  # = 4
```

**For SAS-style round-half-up:**
```python
import math
def round_half_up(x: float, decimals: int = 0) -> float:
    multiplier = 10 ** decimals
    return math.floor(x * multiplier + 0.5) / multiplier

# Polars:
df = df.with_columns(
    rounded = (pl.col("value") * 10**decimals + 0.5).floor() / 10**decimals
)
```

**Test cases:**
- 0.5, 1.5, 2.5, etc.
- Negative values
- Different decimal places

---

## String Handling

### Fixed-Length Character Variables
**Issue:** SAS character variables have declared length and can be padded. Python strings are variable-length.

**SAS behavior:**
```sas
LENGTH name $10;
name = "John";  /* Stored with padding */
```

**Python approach:**
```python
# Usually don't need fixed-length
# But test for:
# - Unexpected whitespace in comparisons
# - Truncation in original SAS code
```

**Test cases:**
- Trailing spaces in keys (affects joins)
- String comparisons with padding
- Substring operations expecting padding

---

### COMPRESS Function
**Issue:** SAS COMPRESS removes specific characters. Python works differently.

**SAS:**
```sas
clean = COMPRESS(text, , 'kd');  /* Keep digits only */
```

**Python:**

**Polars:**
```python
# Remove non-digits (SAS: COMPRESS(text, , 'kd')):
df = df.with_columns(
    clean = pl.col("text").str.replace_all(r"[^0-9]", "")
)

# Keep only alphanumeric (SAS: COMPRESS(text, , 'ka')):
df = df.with_columns(
    clean = pl.col("text").str.replace_all(r"[^A-Za-z0-9]", "")
)

# Remove specific characters:
df = df.with_columns(
    clean = pl.col("text").str.replace_all(r"[-().]", "")
)
```

**DuckDB:**
```sql
-- Remove non-digits (keep digits only):
SELECT regexp_replace(text, '[^0-9]', '', 'g') AS clean
FROM df

-- Keep only alphanumeric:
SELECT regexp_replace(text, '[^A-Za-z0-9]', '', 'g') AS clean
FROM df

-- Remove specific characters:
SELECT regexp_replace(text, '[-().]', '', 'g') AS clean
FROM df

-- Remove all whitespace:
SELECT regexp_replace(text, '\s+', '', 'g') AS clean
FROM df
```

---

## Sorting and Duplicate Handling

### PROC SORT with NODUPKEY
**Issue:** NODUPKEY keeps first occurrence. Python unique/distinct may differ.

**SAS:**
```sas
PROC SORT DATA=input OUT=output NODUPKEY;
    BY key1 key2;
RUN;
/* Keeps first occurrence of each key1+key2 combination */
```

**Python:**

**Polars (keeps first occurrence):**
```python
# Sort then unique:
df_unique = df.sort("key1", "key2").unique(subset=["key1", "key2"], keep="first")

# Or unique without sort (may not preserve order):
df_unique = df.unique(subset=["key1", "key2"], keep="first")

# Keep last instead:
df_unique = df.unique(subset=["key1", "key2"], keep="last")
```

**DuckDB (keeps first occurrence):**
```sql
-- DISTINCT ON keeps first row per group:
SELECT DISTINCT ON (key1, key2) *
FROM df
ORDER BY key1, key2

-- With additional tiebreaker:
SELECT DISTINCT ON (key1, key2) *
FROM df
ORDER BY key1, key2, date DESC

-- Or using ROW_NUMBER:
SELECT * FROM (
    SELECT *, ROW_NUMBER() OVER (PARTITION BY key1, key2 ORDER BY date) AS rn
    FROM df
) WHERE rn = 1
```

**Test with:**
- Verify first record kept (not last or arbitrary)
- Multiple sort keys
- Tiebreaker when all keys equal

---

## Statistical Procedure Defaults

### PROC MEANS
**Issue:** Default statistics and missing value handling differ.

**SAS defaults:**
- Statistics: N, MEAN, STD, MIN, MAX
- Missing values: Generally excluded
- Handles special missing values

**Python approach:**

**Polars (nulls excluded by default):**
```python
# Overall statistics:
df.select([
    pl.len().alias("n"),
    pl.col("value").count().alias("n_non_missing"),  # Non-null count
    pl.col("value").mean().alias("mean"),
    pl.col("value").std().alias("std"),
    pl.col("value").min().alias("min"),
    pl.col("value").max().alias("max")
])

# By-group statistics:
df.group_by("group").agg([
    pl.len().alias("n"),
    pl.col("value").count().alias("n_non_missing"),
    pl.col("value").mean().alias("mean"),
    pl.col("value").std().alias("std"),
    pl.col("value").min().alias("min"),
    pl.col("value").max().alias("max")
])
```

**DuckDB (nulls excluded by default):**
```sql
-- Overall statistics:
SELECT
    COUNT(*) AS n,
    COUNT(value) AS n_non_missing,
    AVG(value) AS mean,
    STDDEV(value) AS std,
    MIN(value) AS min,
    MAX(value) AS max
FROM df

-- By-group statistics (equivalent to PROC MEANS with CLASS):
SELECT
    group,
    COUNT(*) AS n,
    COUNT(value) AS n_non_missing,
    AVG(value) AS mean,
    STDDEV(value) AS std,
    MIN(value) AS min,
    MAX(value) AS max
FROM df
GROUP BY group
ORDER BY group
```

**Test:**
- All-missing groups
- Partially-missing values
- Compare N (non-missing count)

---

### Statistical Models (REG, LOGISTIC, etc.)
**Issue:** Default reference levels, missing value handling, and parameterization differ.

**Test:**
- Categorical reference levels
- Missing value deletion (listwise vs. pairwise)
- Parameter estimates and standard errors
- Confidence intervals and p-values
- Model fit statistics

**Python approach:**
```python
import statsmodels.api as sm

# Prepare data in Polars:
model_data = df.select([...]).to_pandas()

# Explicit handling:
X = model_data[["x1", "x2"]]
y = model_data["target"]
model = sm.OLS(y, sm.add_constant(X), missing='drop').fit()
```

---

## Row Order

### No Guaranteed Order
**Issue:** Python DataFrames and SQL results don't guarantee row order unless explicitly sorted. Each PROC SORT is retained in say and impacts deduplication results.

**Critical:**
- Always sort explicitly when order matters
- Don't assume BY-group operations preserve insertion order
- Test with representative data that would expose ordering issues

**Polars:**
```python
# Explicit sort:
df = df.sort("customer_id", "date")

# Descending order:
df = df.sort("customer_id", "date", descending=[False, True])
```

**DuckDB:**
```sql
-- Explicit sort:
SELECT * FROM df ORDER BY customer_id, date

-- Descending order:
SELECT * FROM df ORDER BY customer_id, date DESC

-- Multiple sort keys with mixed order:
SELECT * FROM df ORDER BY customer_id ASC, date DESC
```

---

## Lazy vs. Eager Evaluation

### Polars Lazy Evaluation
**Issue:** Polars `scan_*` methods don't execute until `collect()`.

**Implications:**
- Errors may not appear until collect()
- Can't inspect intermediate results without collect()
- Query optimization happens at collect time

**Best practice:**
```python
# Build lazy query:
df = (
    pl.scan_parquet("input.parquet")
    .filter(pl.col("age") > 18)
    .with_columns(new_col = pl.col("old_col") * 2)
)

# Inspect query plan:
print(df.explain())

# Execute:
result = df.collect()
```

---

## DuckDB Connection Management

### Connection Context
**Issue:** DuckDB connections need proper lifecycle management.

**Best practice:**
```python
import duckdb

# Context manager:
with duckdb.connect() as con:
    result = con.execute("SELECT * FROM 'file.parquet'").pl()

# Or explicit close:
con = duckdb.connect()
try:
    result = con.execute("SELECT * FROM 'file.parquet'").pl()
finally:
    con.close()
```