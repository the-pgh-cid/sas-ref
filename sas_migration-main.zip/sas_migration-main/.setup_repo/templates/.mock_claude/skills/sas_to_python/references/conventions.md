# Python Coding Conventions for SAS Migration

Common SAS patterns and their idiomatic Python equivalents using Polars, DuckDB, and Pandas.

## DATA Step Patterns

### Basic Transformation

**SAS:**
```sas
DATA output;
    SET input;
    new_var = old_var * 2;
    IF age > 18;
RUN;
```

**Python (Polars):**
```python
df = (
    pl.scan_parquet("input.parquet")
    .filter(pl.col("age") > 18)
    .with_columns(new_var = pl.col("old_var") * 2)
    .collect()
)
```

**Python (DuckDB):**
```python
df = duckdb.sql("""
    SELECT *, old_var * 2 AS new_var
    FROM 'input.parquet'
    WHERE age > 18
""").pl()
```

**Python (Pandas):**
```python
df = pd.read_parquet("input.parquet")
df = df[df["age"] > 18].assign(new_var = lambda x: x["old_var"] * 2)
```

---

### IF-THEN-ELSE

**SAS:**
```sas
DATA output;
    SET input;
    IF age < 18 THEN category = 'Minor';
    ELSE IF age < 65 THEN category = 'Adult';
    ELSE category = 'Senior';
RUN;
```

**Python (Polars):**
```python
df = df.with_columns(
    pl.when(pl.col("age") < 18)
      .then(pl.lit("Minor"))
      .when(pl.col("age") < 65)
      .then(pl.lit("Adult"))
      .otherwise(pl.lit("Senior"))
      .alias("category")
)
```

**Python (DuckDB):**
```python
df = duckdb.sql("""
    SELECT *,
        CASE
        WHEN age < 18 THEN 'Minor'
        WHEN age < 65 THEN 'Adult'
        ELSE 'Senior'
        END AS category
    FROM df
""").pl()
```

**Python (Pandas):**
```python
df["category"] = np.select(
    [df["age"] < 18, df["age"] < 65],
    ["Minor", "Adult"],
    default="Senior"
)
```

---

### RETAIN (Cumulative Operations)

**SAS:**
```sas
DATA output;
    RETAIN total 0;
    SET input;
    total = total + amount;
RUN;
```

**Python (Polars):**
```python
df = df.with_columns(
    total = pl.col("amount").cum_sum()
)

# By-group cumulative:
df = df.with_columns(
    total = pl.col("amount").cum_sum().over("customer_id")
)
```

**Python (DuckDB):**
```python
# Simple cumulative:
duckdb.sql("""
    SELECT *,
           SUM(amount) OVER (ORDER BY row_id) AS total
    FROM df
""")

# By-group cumulative:
duckdb.sql("""
    SELECT *,
           SUM(amount) OVER (PARTITION BY customer_id ORDER BY row_id) AS total
    FROM df
""")
```

---

### LAG and DIF

**SAS (simple case):**
```sas
DATA output;
    SET input;
    prev_value = LAG(value);
    diff = DIF(value);
RUN;
```

**Python (Polars):**
```python
df = df.with_columns([
    pl.col("value").shift(1).alias("prev_value"),
    pl.col("value").diff().alias("diff")
])
```

**Python (DuckDB):**
Note: For duckdb need an order by clause.
```python
duckdb.sql("""
SELECT *,
    LAG(value, 1) OVER (PARTITION BY customer_id ORDER BY date) AS prev_value,
    value - LAG(value, 1) OVER (PARTITION BY customer_id ORDER BY date) AS diff
FROM df
""")
```

**⚠️ WARNING:** SAS LAG uses queue semantics. See gotchas.md for conditional LAG.

---

### FIRST. and LAST. Variables

**SAS:**
```sas
PROC SORT DATA=input; BY customer_id date; RUN;
DATA output;
    SET input;
    BY customer_id;
    IF FIRST.customer_id THEN total = 0;
    total + amount;
    IF LAST.customer_id THEN OUTPUT;
RUN;
```

**Python (Polars):**
```python
df = (
    df.sort("customer_id", "date")
    .with_columns(
        total = pl.col("amount").cum_sum().over("customer_id")
    )
    .group_by("customer_id")
    .last()
)
```

**Python (DuckDB):**
Note: For duckdb need an order by clause.
```python
duckdb.sql("""
    SELECT *,
        SUM(amount) OVER (PARTITION BY customer_id ORDER BY date) AS total
    FROM df
    QUALIFY ROW_NUMBER() OVER (PARTITION BY customer_id ORDER BY date DESC) = 1 # change desc/asc to get first or last

""")
```

**For FIRST./LAST. indicators:**
```python
# Polars:
df = df.with_columns([
    pl.col("customer_id").is_first_distinct().alias("first_customer"),
    pl.col("customer_id").is_last_distinct().alias("last_customer")
])

# DuckDB:
duckdb.sql("""
    SELECT *,
        ROW_NUMBER() OVER (PARTITION BY customer_id ORDER BY date) = 1 AS first_customer,
        ROW_NUMBER() OVER (PARTITION BY customer_id ORDER BY date DESC) = 1 AS last_customer
    FROM df
""")
```

---

### Arrays

**SAS:**
```sas
DATA output;
    SET input;
    ARRAY vars{3} var1 var2 var3;
    DO i = 1 TO 3;
        vars{i} = vars{i} * 2;
    END;
RUN;
```

**Python (Polars):**
```python
df = df.with_columns(
    pl.col("var1", "var2", "var3") * 2
)

# Or with list comprehension:
cols = ["var1", "var2", "var3"]
df = df.with_columns([
    (pl.col(col) * 2).alias(col) for col in cols
])
```

---

### Multiple OUTPUT Statements

**SAS:**
```sas
DATA adults minors;
    SET input;
    IF age >= 18 THEN OUTPUT adults;
    ELSE OUTPUT minors;
RUN;
```

**Python (Polars):**
```python
adults = df.filter(pl.col("age") >= 18)
minors = df.filter(pl.col("age") < 18)
```

---

## PROC SQL Patterns

### Simple Query

**SAS:**
```sas
PROC SQL;
    CREATE TABLE output AS
    SELECT customer_id, SUM(amount) AS total
    FROM input
    WHERE date > '2024-01-01'd
    GROUP BY customer_id
    HAVING total > 1000;
QUIT;
```

**Python (Polars):**
```python
output = (
    df.filter(pl.col("date") > date(2024, 1, 1))
    .group_by("customer_id")
    .agg(pl.col("amount").sum().alias("total"))
    .filter(pl.col("total") > 1000)
)
```

**Python (DuckDB):**
```python
output = duckdb.sql("""
    SELECT customer_id, SUM(amount) AS total
    FROM df
    WHERE date > '2024-01-01'
    GROUP BY customer_id
    HAVING total > 1000
""").pl()
```

---

### Joins

**SAS:**
```sas
PROC SQL;
    CREATE TABLE output AS
    SELECT a.*, b.category
    FROM customers AS a
    LEFT JOIN categories AS b
        ON a.category_id = b.id;
QUIT;
```

**Python (Polars):**
```python
output = customers.join(
    categories,
    left_on="category_id",
    right_on="id",
    how="left"
)
```

**Python (DuckDB):**
```python
output = duckdb.sql("""
    SELECT a.*, b.category
    FROM customers a
    LEFT JOIN categories b
      ON a.category_id = b.id
""").pl()
```

---

### UNION ALL

**SAS:**
```sas
PROC SQL;
    CREATE TABLE combined AS
    SELECT * FROM data2023
    UNION ALL
    SELECT * FROM data2024;
QUIT;
```

**Python (Polars):**
```python
combined = pl.concat([data2023, data2024])
```

**Python (DuckDB):**
```python
combined = duckdb.sql("""
    SELECT * FROM data2023
    UNION ALL
    SELECT * FROM data2024
""").pl()
```

---

## Aggregation Patterns

### PROC MEANS

**SAS:**
```sas
PROC MEANS DATA=input MEAN STD MIN MAX;
    VAR sales;
    CLASS region;
    OUTPUT OUT=output MEAN=avg_sales STD=std_sales;
RUN;
```

**Python (Polars):**
```python
output = df.group_by("region").agg([
    pl.col("sales").mean().alias("avg_sales"),
    pl.col("sales").std().alias("std_sales"),
    pl.col("sales").min().alias("min_sales"),
    pl.col("sales").max().alias("max_sales")
])
```

**Python (DuckDB):**
```python
output = duckdb.sql("""
  SELECT
    region,
    AVG(sales) AS avg_sales,
    STDDEV(sales) AS std_sales,
    MIN(sales) AS min_sales,
    MAX(sales) AS max_sales
  FROM df
  GROUP BY region
""").pl()
```

---

### PROC FREQ

**SAS:**
```sas
PROC FREQ DATA=input;
    TABLES category / OUT=freq_table;
RUN;
```

**Python (Polars):**
```python
freq_table = df["category"].value_counts().sort("count", descending=True)
```

**Python (DuckDB):**
```python
freq_table = duckdb.sql("""
    SELECT
        category,
        COUNT(*) AS count
    FROM df
    GROUP BY category
    ORDER BY count DESC
""").pl()
```
---

### PROC TRANSPOSE

**SAS (wide to long):**
```sas
PROC TRANSPOSE DATA=wide OUT=long;
    BY id;
    VAR var1 var2 var3;
RUN;
```

**Python (Polars):**
```python
long = wide.unpivot(
    index="id",
    on=["var1", "var2", "var3"],
    variable_name="variable",
    value_name="value"
)
```

**Python (DuckDB):**
```python
long = duckdb.sql("""
    UNPIVOT wide
    ON var1, var2, var3
    INTO NAME variable VALUE value
""").pl()
```

**SAS (long to wide):**
```sas
PROC TRANSPOSE DATA=long OUT=wide;
    BY id;
    ID variable;
    VAR value;
RUN;
```

**Python (Polars):**
```python
wide = long.pivot(
    index="id",
    columns="variable",
    values="value"
)
```

**Python (DuckDB):**
```python
wide = duckdb.sql("""
    PIVOT long
    ON variable
    USING SUM(value)
    GROUP BY id
""").pl()
```

---

## Date and Time Patterns

### Date Construction

**SAS:**
```sas
date = MDY(month, day, year);
date = TODAY();
```

**Python (Polars):**
```python
from datetime import date

df = df.with_columns(
    date = pl.date(pl.col("year"), pl.col("month"), pl.col("day"))
)

df = df.with_columns(
    today = pl.lit(date.today())
)
```

**Python (DuckDB):**
```python
df = duckdb.sql("""
    SELECT
        MAKE_DATE(year, month, day) AS date,
        CURRENT_DATE AS today
    FROM df
""").pl()
```

---

### Date Arithmetic

**SAS:**
```sas
next_month = INTNX('MONTH', date, 1, 'BEGINNING');
months_diff = INTCK('MONTH', start_date, end_date);
```

**Python (Polars):**
```python
df = df.with_columns(
    next_month = pl.col("date").dt.offset_by("1mo").dt.month_start()
)

df = df.with_columns(
    months_diff = (
        (pl.col("end_date").dt.year() - pl.col("start_date").dt.year()) * 12 +
        (pl.col("end_date").dt.month() - pl.col("start_date").dt.month())
    )
)
# ⚠️ Test edge cases (see gotchas.md)
```


**Python (DuckDB):**
```python
# INTNX equivalent
df = con.execute("""
  SELECT *,
    DATE_TRUNC('month', date + INTERVAL '1 month') AS next_month
  FROM df
""").pl()

# INTCK equivalent
df = con.execute("""
  SELECT *,
    DATEDIFF('month', start_date, end_date) AS months_diff
  FROM df
""").pl()
```

---

### Date Extraction

**SAS:**
```sas
year_val = YEAR(date);
month_val = MONTH(date);
day_val = DAY(date);
```

**Python (Polars):**
```python
df = df.with_columns([
    pl.col("date").dt.year().alias("year_val"),
    pl.col("date").dt.month().alias("month_val"),
    pl.col("date").dt.day().alias("day_val")
])
```

**Python (DuckDB):**
```python
df = duckdb.sql("""
    SELECT
        date,
        YEAR(date) AS year_val,
        MONTH(date) AS month_val,
        DAY(date) AS day_val
    FROM df
""").pl()
```

---

## String Patterns

### String Manipulation

**SAS:**
```sas
DATA output;
    SET input;
    upper_name = UPCASE(name);
    clean_name = TRIM(LEFT(name));
    sub_name = SUBSTR(name, 1, 10);
    concat_name = CATX(' ', first, last);
RUN;
```

**Python (Polars):**
```python
df = df.with_columns([
    pl.col("name").str.to_uppercase().alias("upper_name"),
    pl.col("name").str.strip_chars().alias("clean_name"),
    pl.col("name").str.slice(0, 10).alias("sub_name"),
    pl.concat_str([pl.col("first"), pl.col("last")], separator=" ").alias("concat_name")
])
```

**Python (DuckDB):**
```python
df = duckdb.sql("""
    SELECT
        UPPER(name) AS upper_name,
        TRIM(name) AS clean_name,
        SUBSTR(name, 1, 10) AS sub_name,
        CONCAT(first, ' ', last) AS concat_name
    FROM df
""").pl()
```

---

### Pattern Matching

**SAS:**
```sas
DATA output;
    SET input;
    IF PRXMATCH('/\d{3}-\d{2}-\d{4}/', ssn) THEN valid_ssn = 1;
    clean_text = PRXCHANGE('s/[^A-Za-z]//g', -1, text);
RUN;
```

**Python (Polars):**
```python
df = df.with_columns([
    pl.col("ssn").str.contains(r"\d{3}-\d{2}-\d{4}").alias("valid_ssn"),
    pl.col("text").str.replace_all(r"[^A-Za-z]", "").alias("clean_text")
])
```

**Python (DuckDB):**
```python
df = duckdb.sql("""
    SELECT
        REGEXP_MATCHES(ssn, '\\d{3}-\\d{2}-\\d{4}') AS valid_ssn,
        REGEXP_REPLACE(text, '[^A-Za-z]', '', 'g') AS clean_text
    FROM df
""").pl()
```

---

## Macro Patterns

### Simple Macro Function

**SAS:**
```sas
%MACRO filter_data(dataset=, age_threshold=, output=);
    DATA &output;
        SET &dataset;
        IF age > &age_threshold;
    RUN;
%MEND filter_data;
```

**Python:**
```python
def filter_data(
    dataset: pl.DataFrame,
    age_threshold: int,
    output_path: Path | None = None
) -> pl.DataFrame:
    """Filter dataset by age threshold.

    Args:
        dataset: Input DataFrame
        age_threshold: Minimum age
        output_path: Optional output file path

    Returns:
        Filtered DataFrame
    """
    result = dataset.filter(pl.col("age") > age_threshold)

    if output_path is not None:
        result.write_parquet(output_path)

    return result

# Usage:
adults = filter_data(input_df, age_threshold=18)
```

---

### Macro Loop

**SAS:**
```sas
%MACRO process_years;
    %DO year = 2020 %TO 2024;
        PROC MEANS DATA=data&year;
            VAR sales;
        RUN;
    %END;
%MEND process_years;
```

**Python:**
```python
def process_years(years: list[int] = list(range(2020, 2025))) -> pl.DataFrame:
    """Process multiple years of data.

    Args:
        years: List of years to process

    Returns:
        Combined summary DataFrame
    """
    results = []

    for year in years:
        df = pl.read_parquet(f"data{year}.parquet")
        summary = df.select(
            pl.lit(year).alias("year"),
            pl.col("sales").mean().alias("avg_sales")
        )
        results.append(summary)

    return pl.concat(results)

# Usage:
results = process_years()
```

---

## Best Practices

### Choose the Right Library

```python
# Polars for:
# - DataFrame operations
# - Type safety
# - Performance
# - Lazy evaluation
df = pl.scan_parquet("large.parquet").filter(...).collect()

# DuckDB for:
# - SQL-heavy transformations
# - Large files (>RAM)
# - Direct file queries
result = duckdb.sql("FROM 'huge.parquet' WHERE ...").pl()

# Pandas for:
# - Statistical modeling (statsmodels)
# - Existing Pandas code
# - Team familiarity
df_pd = df.to_pandas()
model = sm.OLS(y, X).fit()
```

---

### Lazy Evaluation (Polars)

**Use lazy evaluation for large datasets:**
```python
# Lazy query building:
df = (
    pl.scan_parquet("large.parquet")
    .filter(pl.col("date") > date(2024, 1, 1))
    .with_columns(amount_usd = pl.col("amount") * pl.col("rate"))
    .group_by("customer")
    .agg(pl.col("amount_usd").sum())
)

# Inspect query plan:
print(df.explain())

# Execute:
result = df.collect()
```

---

### Type Safety

**Always use type hints:**
```python
from pathlib import Path
import polars as pl

def process_data(
    input_path: Path,
    threshold: float = 100.0
) -> pl.DataFrame:
    """Process input data with threshold filter.

    Args:
        input_path: Path to input Parquet file
        threshold: Minimum value threshold

    Returns:
        Filtered and processed DataFrame
    """
    return (
        pl.scan_parquet(input_path)
        .filter(pl.col("value") > threshold)
        .collect()
    )
```

---

### Error Handling

**Add validation:**
```python
from pathlib import Path
import polars as pl

def process_data(input_path: Path, threshold: float) -> pl.DataFrame:
    # Validate inputs
    if not input_path.exists():
        raise FileNotFoundError(f"Input file not found: {input_path}")

    if not isinstance(threshold, (int, float)):
        raise TypeError(f"threshold must be numeric, got {type(threshold)}")

    # Load and process
    df = pl.read_parquet(input_path)
    result = df.filter(pl.col("value") > threshold)

    # Validate output
    if len(result) == 0:
        raise ValueError("No rows match filter criteria")

    return result
```

---

### Memory Efficiency

**For large files, use lazy evaluation or DuckDB:**
```python
# Don't load entire file:
df = pl.read_parquet("huge.parquet")  # Loads into memory

# Use lazy evaluation:
df = pl.scan_parquet("huge.parquet").filter(...).collect()

# Or query with DuckDB:
result = duckdb.sql("""
    SELECT * FROM 'huge.parquet'
    WHERE condition
""").pl()
```

---

### Chaining Operations

**Prefer method chaining for readability:**
```python
# Good - clear data flow:
result = (
    df
    .filter(pl.col("age") > 18)
    .with_columns(amount_usd = pl.col("amount") * pl.col("rate"))
    .group_by("customer")
    .agg(pl.col("amount_usd").sum())
    .sort("amount_usd", descending=True)
)

# Avoid - harder to follow:
df = df.filter(pl.col("age") > 18)
df = df.with_columns(amount_usd = pl.col("amount") * pl.col("rate"))
df = df.group_by("customer").agg(pl.col("amount_usd").sum())
result = df.sort("amount_usd", descending=True)
```
