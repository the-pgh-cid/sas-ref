# SAS PROC to Python Function Mapping

Comprehensive mapping of SAS procedures to Python equivalents using Polars, DuckDB, Pandas, and specialized libraries.

## Data Input/Output

| SAS | Python Function | Library | Notes |
|-----|-----------------|---------|-------|
| `PROC IMPORT` (CSV) | `pl.read_csv()`, `pl.scan_csv()` | polars | Eager / lazy |
| | `pd.read_csv()` | pandas | Traditional |
| | `SELECT * FROM 'file.csv'` | duckdb | SQL query |
| `PROC IMPORT` (Parquet) | `pl.read_parquet()`, `pl.scan_parquet()` | polars | Eager / lazy |
| | `pd.read_parquet()` | pandas | Eager only |
| | `SELECT * FROM 'file.parquet'` | duckdb | Direct query |
| `PROC IMPORT` (Excel) | `pl.read_excel()` | polars | Basic Excel |
| | `pd.read_excel()` | pandas | Full Excel support |
| `PROC IMPORT` (SAS dataset) | `read_sas()` | pyreadstat | Reads .sas7bdat |
| `PROC EXPORT` | `.write_csv()`, `.write_parquet()` | polars | Polars output |
| | `.to_csv()`, `.to_parquet()` | pandas | Pandas output |
| | `COPY ... TO 'file.csv'` | duckdb | SQL export |
| `LIBNAME` | `duckdb.connect()` | duckdb | Database connections |
| | Direct file paths | pathlib | File access |

---

## Data Manipulation

| SAS | Python Function | Library | Notes |
|-----|-----------------|---------|-------|
| `DATA` step | `.with_columns()`, `.filter()` | polars | DataFrame operations |
| | `.assign()`, `.query()` | pandas | DataFrame operations |
| | `CREATE TABLE AS SELECT` | duckdb | SQL approach |
| `SET` | Read existing DataFrame | - | N/A |
| `MERGE ... BY` | `.join()` | polars | SQL-style joins |
| | `.merge()` | pandas | SQL-style joins |
| | `JOIN` | duckdb | SQL joins |
| `PROC SORT` | `.sort()` | polars | Sorting |
| | `.sort_values()` | pandas | Sorting |
| | `ORDER BY` | duckdb | SQL sorting |
| `PROC SORT NODUPKEY` | `.unique(subset=[...])` | polars | Keep first |
| | `.drop_duplicates()` | pandas | Keep first |
| | `DISTINCT ON` | duckdb | SQL distinct |
| `PROC APPEND` | `pl.concat()` | polars | Row binding |
| | `pd.concat()` | pandas | Row binding |
| | `INSERT INTO ... SELECT` | duckdb | SQL append |
| `PROC TRANSPOSE` | `.pivot()`, `.unpivot()` | polars | Reshaping |
| | `.pivot()`, `.melt()` | pandas | Reshaping |
| | `PIVOT`, `UNPIVOT` | duckdb | SQL pivot |

---

## Aggregation and Summary

| SAS | Python Function | Library | Notes |
|-----|-----------------|---------|-------|
| `PROC MEANS` | `.group_by().agg()` | polars | Grouped aggregation |
| | `.groupby().agg()` | pandas | Grouped aggregation |
| | `SELECT ... GROUP BY` | duckdb | SQL aggregation |
| `PROC SUMMARY` | Same as PROC MEANS | - | |
| `PROC FREQ` | `.value_counts()` | polars | Frequency counts |
| | `.value_counts()` | pandas | Frequency counts |
| | `SELECT COUNT(*) ... GROUP BY` | duckdb | SQL frequency |
| `PROC TABULATE` | `.pivot()` with aggregation | polars | Cross-tabulation |
| | `.pivot_table()` | pandas | Cross-tabulation |
| `PROC UNIVARIATE` | `.describe()` | polars | Summary statistics |
| | `.describe()` | pandas | Summary statistics |
| | `describe()` | scipy.stats | Detailed stats |
| `PROC RANK` | `.rank()` | polars | Ranking |
| | `.rank()` | pandas | Ranking |
| | `RANK()`, `NTILE()` | duckdb | Window functions |

---

## SQL and Queries

| SAS | Python Function | Library | Notes |
|-----|-----------------|---------|-------|
| `PROC SQL` | `duckdb.sql()` | duckdb | Full SQL support |
| | `.filter()`, `.group_by()` | polars | Verb-based |
| | `.query()`, `.groupby()` | pandas | Verb-based |
| `PROC SQL CREATE TABLE` | `CREATE TABLE AS` | duckdb | SQL table creation |
| | Variable assignment | python | Python assignment |
| `PROC SQL JOIN` | `JOIN` | duckdb | SQL joins |
| | `.join()` | polars | DataFrame join |
| | `.merge()` | pandas | DataFrame join |
| `PROC SQL UNION` | `UNION ALL` | duckdb | SQL set operations |
| | `pl.concat()` | polars | Row binding |
| | `pd.concat()` | pandas | Row binding |

---

## Statistical Procedures

### Regression and GLM

| SAS | Python Function | Library | Notes |
|-----|-----------------|---------|-------|
| `PROC REG` | `OLS()` | statsmodels | Linear regression |
| | `LinearRegression()` | scikit-learn | ML approach |
| `PROC GLM` | `OLS()`, `anova_lm()` | statsmodels | ANOVA and linear models |
| `PROC LOGISTIC` | `Logit()` | statsmodels | Logistic regression |
| | `LogisticRegression()` | scikit-learn | ML approach |
| `PROC GENMOD` | `GLM()` | statsmodels | Generalized linear models |
| `PROC PROBIT` | `Probit()` | statsmodels | Probit regression |

### Mixed Models

| SAS | Python Function | Library | Notes |
|-----|-----------------|---------|-------|
| `PROC MIXED` | `MixedLM()` | statsmodels | Linear mixed-effects |
| `PROC GLIMMIX` | `BinomialBayesMixedGLM()` | statsmodels | GLMM (limited support) |
| | Use R via rpy2 | rpy2 + lme4 | More complete |

### Survival Analysis

| SAS | Python Function | Library | Notes |
|-----|-----------------|---------|-------|
| `PROC LIFETEST` | `KaplanMeierFitter()` | lifelines | Kaplan-Meier |
| `PROC PHREG` | `CoxPHFitter()` | lifelines | Cox proportional hazards |
| `PROC LIFEREG` | `WeibullAFTFitter()` | lifelines | Parametric survival |

### Time Series

| SAS | Python Function | Library | Notes |
|-----|-----------------|---------|-------|
| `PROC ARIMA` | `ARIMA()`, `SARIMAX()` | statsmodels | ARIMA models |
| | `AutoARIMA()` | pmdarima | Auto-ARIMA |
| `PROC FORECAST` | `ExponentialSmoothing()` | statsmodels | Exponential smoothing |
| | `forecast()` | sktime | Unified forecasting |
| `PROC ESM` | `ExponentialSmoothing()` | statsmodels | ESM models |
| `PROC TIMESERIES` | Time series framework | sktime | Modern TS library |
| `PROC UCM` | `UnobservedComponents()` | statsmodels | State space models |

### Survey Methods

| SAS | Python Function | Library | Notes |
|-----|-----------------|---------|-------|
| `PROC SURVEYSELECT` | `.sample()` | polars/pandas | Simple random sampling |
| | Implement survey design | - | Complex sampling needs custom implementation |
| `PROC SURVEYMEANS` | Weighted aggregation | polars/pandas | Manual weighting |
| `PROC SURVEYREG` | `WLS()` with weights | statsmodels | Weighted regression |
| `PROC SURVEYLOGISTIC` | `GLM()` with weights | statsmodels | Weighted logistic |

### Multivariate

| SAS | Python Function | Library | Notes |
|-----|-----------------|---------|-------|
| `PROC FACTOR` | `FactorAnalysis()` | scikit-learn | Factor analysis |
| | `factor_analyzer` | factor_analyzer | Dedicated library |
| `PROC PRINCOMP` | `PCA()` | scikit-learn | Principal components |
| `PROC DISCRIM` | `LinearDiscriminantAnalysis()` | scikit-learn | Discriminant analysis |
| `PROC CLUSTER` | `AgglomerativeClustering()` | scikit-learn | Hierarchical clustering |
| | `KMeans()` | scikit-learn | K-means clustering |
| | `DBSCAN()`, `HDBSCAN()` | scikit-learn | Density-based |

### Nonparametric

| SAS | Python Function | Library | Notes |
|-----|-----------------|---------|-------|
| `PROC NPAR1WAY` | `mannwhitneyu()`, `kruskal()` | scipy.stats | Nonparametric tests |
| `PROC CORR` | `corr()` | polars/pandas | Correlation |
| | `spearmanr()`, `kendalltau()` | scipy.stats | Rank correlations |

---

## Machine Learning / Data Mining

| SAS | Python Function | Library | Notes |
|-----|-----------------|---------|-------|
| `PROC HPFOREST` | `RandomForestClassifier()` | scikit-learn | Random forests |
| | `RandomForestRegressor()` | scikit-learn | RF regression |
| `PROC HPLOGISTIC` | `LogisticRegression()` | scikit-learn | Logistic regression |
| | `SGDClassifier()` | scikit-learn | Stochastic gradient descent |
| `PROC HPNEURAL` | `MLPClassifier()` | scikit-learn | Neural networks |
| | `keras`, `pytorch` | tensorflow/torch | Deep learning |
| `PROC HPSVM` | `SVC()`, `SVR()` | scikit-learn | Support vector machines |
| `PROC TREEBOOST` | `XGBClassifier()` | xgboost | Gradient boosting |
| | `LGBMClassifier()` | lightgbm | LightGBM |
| | `CatBoostClassifier()` | catboost | CatBoost |

---

## Data Quality and Validation

| SAS | Python Function | Library | Notes |
|-----|-----------------|---------|-------|
| `PROC COMPARE` | `assert_frame_equal()` | pandas.testing | Comparison with tolerance |
| | `.equals()` | polars | Exact comparison |
| | Anti-joins, set operations | polars/duckdb | Structural comparison |
| `PROC CONTENTS` | `.schema`, `.dtypes` | polars | Schema inspection |
| | `.info()`, `.dtypes` | pandas | Structure inspection |
| `PROC PRINT` | `print()`, `.head()` | builtin/polars/pandas | Display data |

---

## Reporting and Output

| SAS | Python Function | Library | Notes |
|-----|-----------------|---------|-------|
| `ODS PDF` | Jupyter → PDF | nbconvert | Notebook to PDF |
| | `matplotlib` → PDF | matplotlib | Plot export |
| `ODS EXCEL` | `.write_excel()` | polars | Excel workbooks |
| | `.to_excel()` | pandas + openpyxl | Excel with formatting |
| `ODS HTML` | Jupyter notebook | jupyter | Interactive HTML |
| `PROC REPORT` | `great_tables` | great_tables | Formatted tables |
| | `itables` | itables | Interactive tables |

---

## Utility Procedures

| SAS | Python Function | Library | Notes |
|-----|-----------------|---------|-------|
| `PROC FORMAT` | Lookup table + `.join()` | polars | Code mapping via join |
| | `.replace()`, `.map()` | polars/pandas | Value recoding |
| | `when().then().otherwise()` | polars | Conditional mapping |
| `PROC FCMP` | User-defined functions | python | Native Python functions |
| `PROC CATALOG` | `dir()`, `globals()` | builtin | Object inspection |
| `PROC COPY` | `shutil.copy()` | shutil | File operations |
| `PROC DELETE` | `Path.unlink()` | pathlib | File deletion |
| `PROC OPTIONS` | Environment variables | os | Configuration |

---

## Macro Facilities

| SAS | Python Approach | Notes |
|-----|----------------|-------|
| `%MACRO` / `%MEND` | Functions | Define reusable functions |
| `%LET` | Variable assignment | Regular Python variables |
| `%IF %THEN %ELSE` | `if/else` | Python control flow |
| `%DO %TO` | `for` loop | Python iteration |
| `%DO %WHILE` | `while` loop | Python loop |
| `CALL SYMPUT` | Variable assignment | Extract scalar from DataFrame |
| `&macrovar` | f-string or variable | `f"{var}"` or direct reference |
| `%INCLUDE` | `import` or `exec()` | Load external Python code |
| Autocall macros | Python packages | Shared code libraries |

---

## Quick Reference: Common Operations

### Load CSV
```python
df = pl.read_csv("file.csv")                          # Polars eager
df = pl.scan_csv("file.csv").collect()                # Polars lazy
df = pd.read_csv("file.csv")                          # Pandas
df = duckdb.sql("FROM 'file.csv'").pl()               # DuckDB → Polars
```

### Filter Rows
```python
df = df.filter(pl.col("age") > 18)                    # Polars
df = df[df["age"] > 18]                               # Pandas
df = duckdb.sql("FROM df WHERE age > 18").pl()        # DuckDB
```

### Create Column
```python
df = df.with_columns(new_col = pl.col("old_col") * 2)  # Polars
df = df.assign(new_col = df["old_col"] * 2)            # Pandas
```

### Aggregate by Group
```python
# Polars:
df.group_by("category").agg(pl.col("amount").sum())

# Pandas:
df.groupby("category")["amount"].sum()

# DuckDB:
duckdb.sql("SELECT category, SUM(amount) FROM df GROUP BY category").pl()
```

### Join
```python
# Polars:
df1.join(df2, on="key", how="left")

# Pandas:
df1.merge(df2, on="key", how="left")

# DuckDB:
duckdb.sql("FROM df1 LEFT JOIN df2 ON df1.key = df2.key").pl()
```

### Sort
```python
df = df.sort("amount", descending=True)               # Polars
df = df.sort_values("amount", ascending=False)        # Pandas
df = duckdb.sql("FROM df ORDER BY amount DESC").pl()  # DuckDB
```

---

## Library Selection Guide

### Use DuckDB when:
- PROC SQL heavy workload
- Large files (>RAM)
- Direct file queries without loading
- SQL is natural for the team
- Need to query multiple file formats

### Use Polars when:
- DataFrame-style transformations
- Type-safe pipelines needed
- Lazy evaluation and query optimization
- Performance is critical
- Working with structured data at scale

### Use Pandas when:
- Statistical procedures (statsmodels integration)
- Existing Pandas ecosystem code
- Team familiar with Pandas
- Need mature library ecosystem
- Simple transformations on moderate data

### Combined approach:
```python
# DuckDB for initial query:
df = duckdb.sql("""
    SELECT customer_id, date, amount
    FROM 'large_file.parquet'
    WHERE date > '2024-01-01'
""").pl()  # Convert to Polars

# Polars for transformations:
df = df.with_columns(
    amount_usd = pl.col("amount") * pl.col("exchange_rate")
).group_by("customer_id").agg(
    total = pl.col("amount_usd").sum()
)

# Convert to Pandas for statistical modeling:
model_data = df.to_pandas()

# statsmodels for regression:
import statsmodels.api as sm
X = model_data[["feature1", "feature2"]]
y = model_data["target"]
model = sm.OLS(y, sm.add_constant(X)).fit()
```

---

## Notes

- **Performance:** Polars fastest for DataFrames; DuckDB for large files/SQL
- **Type safety:** Polars has strongest type system
- **Lazy evaluation:** Polars `scan_*` and DuckDB optimize queries before execution
- **Statistical work:** Use statsmodels/scikit-learn after data prep
- **SQL users:** DuckDB most natural for SQL-heavy workflows
- **Interoperability:** Easy conversion between formats (`.to_pandas()`, `.pl()`, `.arrow()`)
