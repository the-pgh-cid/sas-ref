---
name: sas_to_python
description: Convert SAS programs to Python using Polars, DuckDB or Pandas based on workload characteristics
---

# SAS to Python Conversion

Convert SAS code to semantically equivalent Python code that preserves business logic and data contracts.

## When to Use

- User requests SAS to Python conversion
- Target language is Python (not R)
- User says "convert to Python", "migrate to Polars", "translate to DuckDB", "convert SAS script to Python", "convert SAS script to Polars", "convert SAS script to DuckDB"

## Required Reading

**Always read before converting:**

- [references/gotchas.md](references/gotchas.md) - SAS semantic traps
- [references/proc-map.md](references/proc-map.md) - Procedure mappings
- [references/conventions.md](references/conventions.md) - Python coding patterns

When need more information, read:
- [Project migration guide - Polars](../../../sas_convert_doc/sas_to_polars.md)
- [Project migration guide - DuckDB](../../../sas_convert_doc/sas_to_duckdb.md)

## Workflow

### 1. Inventory
**Understand the SAS program:**
- Read the SAS file(s)
- Identify all PROCs used
- Note DATA step patterns (RETAIN, MERGE, LAG, BY-groups, etc.)
- List input/output datasets
- Catalog macro usage

### 2. Plan
**Choose target approach:**

**Library selection:**
- **DuckDB:** PROC SQL heavy, relational work, large files, direct file queries
- **Polars:** DataFrame transformations, type-safe pipelines, lazy evaluation
- **Pandas:** Statistical procedures, existing ecosystem integration
- **Combined:** DuckDB for SQL transformations → Python for statistical work

**Architecture decision:**
```
SQL-heavy/Merges/Joins/Sorting → DuckDB
DataFrame pipelines → Polars (lazy evaluation)
Statistical procedures → Pandas + statsmodels/scikit-learn
Mixed workload → DuckDB + Polars/Pandas
```

### 3. Follow
**Execute conversion using patterns:**

**Setup environment:**
```python
import polars as pl
import duckdb
from pathlib import Path
```

**Convert components:**
1. Data loading (PROC IMPORT, LIBNAME) → See `proc-map.md`
2. DATA steps → See `conventions.md` for patterns
3. PROCs → See `proc-map.md` for mappings
4. Macros → Python functions
5. Date/string functions → See `gotchas.md` for edge cases

**Handle complexity:**
- Review `gotchas.md` for each pattern identified
- Test stateful logic (RETAIN, LAG/DIF, FIRST./LAST.)
- Validate date functions (INTCK, INTNX, YRDIF)
- Check missing value handling
- Verify BY-group processing semantics

### 4. Validate
**Add validation checkpoints:**
```python
# TODO: Validate row counts match SAS
assert len(df) == expected_row_count, "Row count mismatch"

# TODO: Test BY-group ordering
# TODO: Validate date edge cases
# TODO: Check missing value handling
```

Generate test suite (see `/migration-validate` skill)

### 5. Document
**Annotate the conversion:**
- Add header with migration notes
- Comment semantic differences
- Reference SAS line numbers
- Document validation requirements
- List known edge cases to test

## Rules

### Semantic Preservation
- **Preserve behavior, not syntax** - Focus on what the SAS code does
- **Test semantic traps** - Missing values, dates, BY-groups, LAG/DIF
- **Explicit sorting** - Don't assume row order is preserved
- **Validate edge cases** - Month-end dates, leap years, special missing

### Code Quality
- Use type hints throughout (follow project code-style.md)
- Follow Google-style docstrings
- Generate clean, idiomatic Python code
- Prefer lazy evaluation (scan_* methods) where appropriate
- Use appropriate library for the workload

### Safety
- Add validation checkpoints throughout
- Flag uncertainty with TODO comments
- Test against SAS output before declaring complete
- Document where behavior differs from SAS

## Output Structure

```python
"""
SAS to Python Migration
Original: [sas_file.sas]
Converted: [date]

Migration notes:
- Library choice: [Polars/DuckDB/Pandas]
- Complexity patterns: [list patterns]
- Validation requirements: [list tests needed]
- Known semantic differences: [list any]
"""

from pathlib import Path
from datetime import date
import polars as pl

def main() -> pl.DataFrame:
    """Main data processing pipeline."""

    # Configuration
    input_path = Path("data/input.parquet")
    output_path = Path("data/output.parquet")

    # Load data
    df = pl.scan_parquet(input_path)

    # Transformations
    # Original SAS: [reference line numbers]
    df = df.with_columns(
        new_var = pl.col("old_var") * 2
    ).filter(
        pl.col("age") > 18
    )

    # Validation checkpoint
    result = df.collect()
    assert len(result) > 0, "No rows in output"
    print(f"Processed {len(result)} rows")

    # Write output
    result.write_parquet(output_path)

    return result

if __name__ == "__main__":
    result = main()
```

## Key References

- **Gotchas:** Missing values, LAG/DIF, dates, BY-groups → [references/gotchas.md](references/gotchas.md)
- **Procedure mapping:** PROC SQL, MEANS, FREQ, REG, etc. → [references/proc-map.md](references/proc-map.md)
- **Coding patterns:** DATA step patterns, joins, aggregations → [references/conventions.md](references/conventions.md)
- **Project guides:**
  - Polars architecture → [../../../sas_convert_doc/sas_to_polars.md](../../../sas_convert_doc/sas_to_polars.md)
  - DuckDB architecture → [../../../sas_convert_doc/sas_to_duckdb.md](../../../sas_convert_doc/sas_to_duckdb.md)
