# Initialize renv for R project
# This script sets up the R environment with renv package management

cat("\n=====================================\n")
cat("R Environment Initialization\n")
cat("=====================================\n\n")

# Install renv if not available
if (!requireNamespace("renv", quietly = TRUE)) {
    cat("Installing renv package...\n")
    install.packages("renv", repos = "https://cloud.r-project.org/")
}

# Initialize renv
cat("Initializing renv...\n")
renv::init(bare = TRUE)

# Install remotes package for version-specific installations
if (!requireNamespace("remotes", quietly = TRUE)) {
    cat("Installing remotes package...\n")
    install.packages("remotes", repos = "https://cloud.r-project.org/")
}

# Load package definitions from template if available
template_file <- file.path("setup_repo/templates/r_packages.R")
if (file.exists(template_file)) {
    cat(sprintf("Loading package definitions from: %s\n", template_file))
    packages_with_versions <- source(template_file)$value
} else {
    # Fallback: Define packages inline if template not found
    cat("Template not found, using default package list\n")
    packages_with_versions <- list(
        # SAS file reading - specific versions for compatibility
        list(name = "haven", version = "2.5.4"),

        # Core tidyverse - pinned versions
        list(name = "dplyr", version = "1.1.4"),
        list(name = "tidyr", version = "1.3.1"),
        list(name = "ggplot2", version = "3.5.1"),
        list(name = "readr", version = "2.1.5"),

        # Data manipulation
        list(name = "data.table", version = "1.16.4"),

        # Statistical packages
        list(name = "MASS", version = NULL),  # Use latest

        # Testing and development
        list(name = "testthat", version = "3.2.1")

    )
}

cat("\nInstalling required packages...\n")
cat("This may take several minutes...\n\n")

# Install packages with specific versions
for (pkg_info in packages_with_versions) {
    pkg_name <- pkg_info$name
    pkg_version <- pkg_info$version

    if (!is.null(pkg_version)) {
        # Install specific version
        cat(sprintf("Installing %s version %s...\n", pkg_name, pkg_version))
        tryCatch({
            remotes::install_version(
                pkg_name,
                version = pkg_version,
                repos = "https://cloud.r-project.org/",
                upgrade = "never"
            )
            cat(sprintf("✓ %s %s installed successfully\n", pkg_name, pkg_version))
        }, error = function(e) {
            cat(sprintf("✗ Failed to install %s %s: %s\n", pkg_name, pkg_version, e$message))
        })
    } else {
        # Install latest version
        if (!requireNamespace(pkg_name, quietly = TRUE)) {
            cat(sprintf("Installing %s (latest)...\n", pkg_name))
            tryCatch({
                install.packages(pkg_name, repos = "https://cloud.r-project.org/")
                cat(sprintf("✓ %s installed successfully\n", pkg_name))
            }, error = function(e) {
                cat(sprintf("✗ Failed to install %s: %s\n", pkg_name, e$message))
            })
        } else {
            cat(sprintf("✓ %s already installed\n", pkg_name))
        }
    }
}

# Save the state
cat("\nSaving renv snapshot...\n")
renv::snapshot(prompt = FALSE)

# Print summary
cat("\n=====================================\n")
cat("R Environment Setup Complete!\n")
cat("=====================================\n")
cat("renv directory:", renv::paths$root(), "\n")
cat("R version:", R.version.string, "\n")
cat("\nTo activate renv in future R sessions:\n")
cat("  renv::activate()\n")
cat("\nTo install additional packages:\n")
cat("  install.packages('package_name')\n")
cat("  renv::snapshot()  # Save the changes\n")
cat("\n")
