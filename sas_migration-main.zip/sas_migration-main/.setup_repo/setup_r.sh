#!/bin/bash

# R Environment Setup Module
# Called by main setup script or can be run standalone

set -e

# Color codes
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
MAGENTA='\033[0;35m'
NC='\033[0m'

# Helper functions
print_success() { echo -e "${GREEN}✓ $1${NC}"; }
print_error() { echo -e "${RED}✗ $1${NC}"; }
print_warning() { echo -e "${YELLOW}⚠ $1${NC}"; }
print_info() { echo -e "${BLUE}ℹ $1${NC}"; }
print_smoke() { echo -e "${CYAN}🔍 [SMOKE] $1${NC}"; }
print_would() { echo -e "${MAGENTA}  → Would: $1${NC}"; }

# Get repo root
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"

setup_r() {
    if [ "$SMOKE_MODE" = true ]; then
        echo ""
        print_smoke "=== R Environment Setup (Preview Mode) ==="
        echo ""
    else
        print_info "Starting R environment setup..."
    fi

    # Check R installation
    if ! command -v R &> /dev/null; then
        print_error "R is not installed. Please install R first."
        print_info "Visit: https://www.r-project.org/"
        return 1
    fi

    # Get R version
    R_VERSION=$(R --version | head -n 1)
    if [ "$SMOKE_MODE" = true ]; then
        print_smoke "Found: $R_VERSION"
    else
        print_success "Found: $R_VERSION"
    fi

    # Create .renv directory
    RENV_PATH="${REPO_ROOT}/.renv"
    if [ "$SMOKE_MODE" = true ]; then
        print_smoke "Preview: .renv directory"
        print_would "Create directory: ${RENV_PATH}"
    else
        print_info "Creating R environment directory at: ${RENV_PATH}..."
        mkdir -p "${RENV_PATH}"
        print_success ".renv directory created"
    fi

    # Create renv initialization script from template
    TEMPLATE_INIT="${SCRIPT_DIR}/templates/init_renv.R"

    if [ "$SMOKE_MODE" = true ]; then
        print_smoke "Preview: init_renv.R script"
        if [ -f "${TEMPLATE_INIT}" ] && [ -s "${TEMPLATE_INIT}" ]; then
            print_would "Copy from template: ${TEMPLATE_INIT}"
            print_would "Script will load package versions from setup_repo/templates/r_packages.R"
        else
            print_would "Create init_renv.R with default package list"
        fi
        print_would "Packages include: haven, dplyr, tidyr, ggplot2, data.table, testthat"
    else
        print_info "Creating renv initialization script..."

        if [ -f "${TEMPLATE_INIT}" ] && [ -s "${TEMPLATE_INIT}" ]; then
            # Use template if available
            cp "${TEMPLATE_INIT}" "${REPO_ROOT}/init_renv.R"
            print_success "Created init_renv.R from template"
        else
            # Fallback to inline generation
            cat > "${REPO_ROOT}/init_renv.R" <<'EOF'
# Initialize renv for R project
# This script sets up the R environment with renv package management

cat("\n=====================================\n")
cat("R Environment Initialization\n")
cat("=====================================\n\n")

# Install renv if not available
if (!requireNamespace("renv", quietly = TRUE)) {
    cat("Installing renv package...\n")
    install.packages("renv", repos = "https://cloud.r-project.org/")
}

# Initialize renv
cat("Initializing renv...\n")
renv::init(bare = TRUE)

# Define packages needed for SAS migration
packages_to_install <- c(
    # Core tidyverse
    "tidyverse",
    "dplyr",
    "tidyr",
    "readr",
    "ggplot2",

    # Data manipulation
    "data.table",

    # SAS file reading
    "haven",

    # Additional data I/O
    "openxlsx",
    "readxl",

    # Database connectivity
    "DBI",
    "odbc",

    # Testing and development
    "testthat",
    "devtools",
    "usethis"
)

cat("\nInstalling required packages...\n")
cat("This may take several minutes...\n\n")

# Install packages
for (pkg in packages_to_install) {
    if (!requireNamespace(pkg, quietly = TRUE)) {
        cat(sprintf("Installing %s...\n", pkg))
        tryCatch({
            install.packages(pkg, repos = "https://cloud.r-project.org/")
            cat(sprintf("✓ %s installed successfully\n", pkg))
        }, error = function(e) {
            cat(sprintf("✗ Failed to install %s: %s\n", pkg, e$message))
        })
    } else {
        cat(sprintf("✓ %s already installed\n", pkg))
    }
}

# Save the state
cat("\nSaving renv snapshot...\n")
renv::snapshot(prompt = FALSE)

# Print summary
cat("\n=====================================\n")
cat("R Environment Setup Complete!\n")
cat("=====================================\n")
cat("renv directory:", renv::paths$root(), "\n")
cat("R version:", R.version.string, "\n")
cat("\nTo activate renv in future R sessions:\n")
cat("  renv::activate()\n")
cat("\nTo install additional packages:\n")
cat("  install.packages('package_name')\n")
cat("  renv::snapshot()  # Save the changes\n")
cat("\n")
EOF
            print_success "Created init_renv.R"
        fi
    fi

    # Create R project structure
    if [ "$SMOKE_MODE" = true ]; then
        print_smoke "Preview: R project structure"
        print_would "Create directories:"
        echo "    - ${REPO_ROOT}/R/ (R code)"
        echo "    - ${REPO_ROOT}/tests/testthat/ (tests)"
        print_would "Create ${REPO_ROOT}/R/utils.R with SAS helper functions"
        print_would "Create ${REPO_ROOT}/tests/testthat.R test runner"
    else
        print_info "Creating R project structure..."
        mkdir -p "${REPO_ROOT}/R"
        mkdir -p "${REPO_ROOT}/tests/testthat"

        # Create basic R files
        cat > "${REPO_ROOT}/R/utils.R" <<EOF
# Utility functions for SAS migration

#' @title Read SAS Dataset
#' @description Read a SAS file using haven
#' @param file_path Path to SAS file
#' @return Data frame
read_sas_data <- function(file_path) {
    if (!file.exists(file_path)) {
        stop("File not found: ", file_path)
    }
    haven::read_sas(file_path)
}

#' @title Export to CSV
#' @description Export data frame to CSV
#' @param data Data frame to export
#' @param output_path Output CSV path
export_to_csv <- function(data, output_path) {
    readr::write_csv(data, output_path)
    message("Data exported to: ", output_path)
}
EOF

        cat > "${REPO_ROOT}/tests/testthat.R" <<EOF
# Test runner
library(testthat)

test_check("sas_migration")
EOF

        print_success "R project structure created"
    fi

    # Update .gitignore
    if [ "$SMOKE_MODE" = true ]; then
        print_smoke "Preview: .gitignore updates"
        if grep -q "# R environment" "${REPO_ROOT}/.gitignore" 2>/dev/null; then
            print_would "Skip (R entries already exist in .gitignore)"
        else
            print_would "Append R-specific entries to ${REPO_ROOT}/.gitignore"
            echo "    - R environment (.Rhistory, .RData, .Rproj.user)"
            echo "    - renv cache (renv/library/, renv/staging/)"
            echo "    - R output files (*.Rout, .Rapp.history)"
        fi
    else
        print_info "Updating .gitignore..."
        if ! grep -q "# R environment" "${REPO_ROOT}/.gitignore" 2>/dev/null; then
            cat >> "${REPO_ROOT}/.gitignore" <<EOF

# R environment
.Rhistory
.RData
.Rproj.user
renv/library/
renv/local/
renv/staging/
.Rprofile

# R output
*.Rout
.Rapp.history
EOF
        fi
        print_success ".gitignore updated"
    fi

    # Ask to initialize renv
    echo ""
    if [ "$SMOKE_MODE" = true ]; then
        print_smoke "In actual run, you would be prompted to initialize renv"
        print_would "Optionally run: Rscript init_renv.R"
        print_would "This installs all R packages (5-15 minutes)"
    else
        read -p "Initialize renv now? (y/n, default: n): " INIT_RENV
        INIT_RENV=${INIT_RENV:-n}

        if [[ "$INIT_RENV" =~ ^[Yy]$ ]]; then
            print_info "Initializing renv (this may take several minutes)..."
            cd "${REPO_ROOT}"
            Rscript init_renv.R
            print_success "renv initialized successfully"
        else
            print_info "To initialize renv later, run:"
            print_info "  cd ${REPO_ROOT} && Rscript init_renv.R"
        fi
    fi

    # Summary
    echo ""
    if [ "$SMOKE_MODE" = true ]; then
        echo -e "${CYAN}================================${NC}"
        echo -e "${CYAN}R Setup Preview Complete${NC}"
        echo -e "${CYAN}================================${NC}"
        echo -e "${BLUE}Configuration Summary:${NC}"
        echo -e "  R Version: $R_VERSION"
        echo -e "  renv Directory: ${RENV_PATH}"
        echo -e "  R Code Directory: ${REPO_ROOT}/R"
        echo ""
        echo -e "${YELLOW}No files were created or modified.${NC}"
        echo -e "${BLUE}To execute the actual setup, run without --smoke flag${NC}"
    else
        echo -e "${GREEN}================================${NC}"
        echo -e "${GREEN}R Setup Complete!${NC}"
        echo -e "${GREEN}================================${NC}"
        echo -e "${BLUE}R Version:${NC} $R_VERSION"
        echo -e "${BLUE}renv Directory:${NC} ${RENV_PATH}"
        echo -e "${BLUE}R Code Directory:${NC} ${REPO_ROOT}/R"
        echo ""
        echo -e "${YELLOW}To use in R:${NC}"
        echo "  renv::activate()  # Activate environment"
        echo "  source('R/utils.R')  # Load utilities"
    fi
    echo ""

    return 0
}

# If run directly
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    setup_r "$@"
fi
