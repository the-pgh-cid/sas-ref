#!/bin/bash

# Python Environment Setup Module
# Called by main setup script or can be run standalone

set -e

# Color codes
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
MAGENTA='\033[0;35m'
NC='\033[0m'

# Helper functions
print_success() { echo -e "${GREEN}✓ $1${NC}"; }
print_error() { echo -e "${RED}✗ $1${NC}"; }
print_warning() { echo -e "${YELLOW}⚠ $1${NC}"; }
print_info() { echo -e "${BLUE}ℹ $1${NC}"; }
print_smoke() { echo -e "${CYAN}🔍 [SMOKE] $1${NC}"; }
print_would() { echo -e "${MAGENTA}  → Would: $1${NC}"; }

# Get repo root
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"

setup_python() {
    local env_type="${1:-python}"

    if [ "$SMOKE_MODE" = true ]; then
        echo ""
        print_smoke "=== Python Environment Setup (Preview Mode) ==="
        echo ""
    else
        print_info "Starting Python environment setup..."
    fi

    # Python binary selection
    PYTHON_BIN=""

    if [ "$SMOKE_MODE" = true ]; then
        # In smoke mode, use default for demonstration
        PYTHON_BIN="python3"
        print_smoke "In actual run, you would be prompted for Python binary path"
        print_smoke "Default: python3, or custom path like /usr/bin/python3.11"
    else
        # Check if default python3 exists
        if command -v python3 &> /dev/null; then
            DEFAULT_PYTHON=$(which python3)
            DEFAULT_VERSION=$(python3 --version 2>&1)
            echo ""
            print_info "Default Python: ${DEFAULT_PYTHON} (${DEFAULT_VERSION})"
        fi

        echo ""
        read -p "Enter Python binary path or press Enter for default [python3]: " PYTHON_INPUT
        PYTHON_INPUT=${PYTHON_INPUT:-python3}

        # Validate the input
        if [ "$PYTHON_INPUT" == "python3" ]; then
            # User wants default
            if ! command -v python3 &> /dev/null; then
                print_error "Default python3 not found in PATH. Please provide a full path."
                read -p "Enter full path to Python binary (e.g., /usr/bin/python3.12): " PYTHON_INPUT
                if [ -z "$PYTHON_INPUT" ]; then
                    print_error "No Python binary provided. Cannot continue."
                    return 1
                fi
            else
                PYTHON_BIN="python3"
            fi
        fi

        # If not using default python3, validate the path
        if [ -z "$PYTHON_BIN" ]; then
            if [ ! -f "$PYTHON_INPUT" ]; then
                print_error "Python binary not found at: ${PYTHON_INPUT}"
                return 1
            elif [ ! -x "$PYTHON_INPUT" ]; then
                print_error "File is not executable: ${PYTHON_INPUT}"
                return 1
            else
                PYTHON_BIN="$PYTHON_INPUT"
                print_success "Using Python: ${PYTHON_BIN}"
            fi
        fi
    fi

    # Get Python version
    PYTHON_VERSION=$("${PYTHON_BIN}" --version 2>&1)
    if [ "$SMOKE_MODE" = true ]; then
        print_smoke "Found: $PYTHON_VERSION"
    else
        print_success "Found: $PYTHON_VERSION"
    fi

    # Check Python version compatibility (3.11, 3.12, 3.13)
    PYTHON_VERSION_NUM=$("${PYTHON_BIN}" -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')
    if [[ ! "$PYTHON_VERSION_NUM" =~ ^3\.(11|12|13)$ ]]; then
        print_warning "Python ${PYTHON_VERSION_NUM} detected. This project requires Python 3.11, 3.12, or 3.13."
        print_warning "Some dependencies may not work correctly."
        if [ "$SMOKE_MODE" = true ]; then
            print_smoke "In actual run, you would be prompted to continue or cancel"
        else
            read -p "Continue anyway? (y/n): " CONTINUE_ANYWAY
            if [[ ! "$CONTINUE_ANYWAY" =~ ^[Yy]$ ]]; then
                print_error "Setup cancelled. Please install Python 3.11, 3.12, or 3.13."
                return 1
            fi
        fi
    else
        if [ "$SMOKE_MODE" = true ]; then
            print_smoke "Python version ${PYTHON_VERSION_NUM} is compatible"
        else
            print_success "Python version ${PYTHON_VERSION_NUM} is compatible"
        fi
    fi

    # Display selected Python path
    if [ "$SMOKE_MODE" = true ]; then
        print_smoke "Using Python at: ${PYTHON_BIN}"
    else
        print_info "Using Python at: ${PYTHON_BIN}"
    fi

    # Project configuration
    echo ""
    print_info "Project Configuration"
    read -p "Enter project name (default: sas-migration): " PROJECT_NAME
    PROJECT_NAME=${PROJECT_NAME:-sas-migration}

    read -p "Enter project version (default: 0.1.0): " PROJECT_VERSION
    PROJECT_VERSION=${PROJECT_VERSION:-0.1.0}

    read -p "Enter project description (default: SAS to Python/R migration project): " PROJECT_DESC
    PROJECT_DESC=${PROJECT_DESC:-"SAS to Python/R migration project"}

    read -p "Enter author name (default: $(git config user.name 2>/dev/null || echo 'User')): " AUTHOR_NAME
    AUTHOR_NAME=${AUTHOR_NAME:-$(git config user.name 2>/dev/null || echo 'User')}

    read -p "Enter author email (default: $(git config user.email 2>/dev/null || echo 'user@example.com')): " AUTHOR_EMAIL
    AUTHOR_EMAIL=${AUTHOR_EMAIL:-$(git config user.email 2>/dev/null || echo 'user@example.com')}

    # Create pyproject.toml from template
    TEMPLATE_PYPROJECT="${SCRIPT_DIR}/templates/pyproject.toml"

    echo ""
    if [ "$SMOKE_MODE" = true ]; then
        print_smoke "Preview: pyproject.toml configuration"
        if [ -f "${TEMPLATE_PYPROJECT}" ] && [ -s "${TEMPLATE_PYPROJECT}" ]; then
            print_would "Copy from template: ${TEMPLATE_PYPROJECT}"
            print_would "Substitute variables: PROJECT_NAME, VERSION, AUTHOR, etc."
        else
            print_would "Create pyproject.toml with default configuration"
        fi
        echo "    - Project: ${PROJECT_NAME} v${PROJECT_VERSION}"
        echo "    - Author: ${AUTHOR_NAME} <${AUTHOR_EMAIL}>"
        echo "    - Python: >=3.11,<3.14"
        echo "    - Dependencies: numpy, pandas, polars, duckdb, pyreadstat, etc."
    else
        print_info "Creating pyproject.toml..."
        if [ -f "${TEMPLATE_PYPROJECT}" ] && [ -s "${TEMPLATE_PYPROJECT}" ]; then
            # Use template with variable substitution
            sed -e "s|{{PROJECT_NAME}}|${PROJECT_NAME}|g" \
                -e "s|{{PROJECT_VERSION}}|${PROJECT_VERSION}|g" \
                -e "s|{{PROJECT_DESC}}|${PROJECT_DESC}|g" \
                -e "s|{{AUTHOR_NAME}}|${AUTHOR_NAME}|g" \
                -e "s|{{AUTHOR_EMAIL}}|${AUTHOR_EMAIL}|g" \
                "${TEMPLATE_PYPROJECT}" > "${REPO_ROOT}/pyproject.toml"
            print_success "Created pyproject.toml from template"
        else
            # Fallback to inline generation
            cat > "${REPO_ROOT}/pyproject.toml" <<EOF
[build-system]
requires = ["setuptools>=61.0", "wheel"]
build-backend = "setuptools.build_meta"

[project]
name = "${PROJECT_NAME}"
version = "${PROJECT_VERSION}"
description = "${PROJECT_DESC}"
authors = [
    {name = "${AUTHOR_NAME}", email = "${AUTHOR_EMAIL}"}
]
readme = "README.md"
requires-python = ">=3.11,<3.14"
classifiers = [
    "Development Status :: 3 - Alpha",
    "Intended Audience :: Developers",
    "Programming Language :: Python :: 3",
    "Programming Language :: Python :: 3.11",
    "Programming Language :: Python :: 3.12",
    "Programming Language :: Python :: 3.13",
]

dependencies = [
    "numpy==2.4.5",
    "pandas==3.0.1",
    "pyreadstat==1.3.5",
    "polars_readstat==0.23.1",
    "polars==1.31.0",
    "duckdb==1.5.2",
    "ipykernel==7.3.0",
    "matplotlib==3.11.2",
    "seaborn>=0.13.0",
    "pyarrow==25.0.1",
    "pyyaml>=6.0.0",
    "jinja2==3.1.6",
]

[project.optional-dependencies]
dev = [
    "pytest>=7.0.0",
    "pytest-cov>=4.0.0",
    "faker>=28.0.0",
    "pre-commit>=3.5.0",
    "black>=24.8.0",
    "ruff>=0.6.0",
]

[tool.setuptools.packages.find]
where = ["src"]

[tool.black]
line-length = 88
target-version = ['py311', 'py312', 'py313']

[tool.ruff]
line-length = 88
target-version = "py311"

[tool.pytest.ini_options]
testpaths = ["tests"]
python_files = "test_*.py"
python_classes = "Test*"
python_functions = "test_*"
addopts = "--verbose --cov=src --cov-report=html --cov-report=term-missing"
EOF
            print_success "Created pyproject.toml"
        fi
    fi

    # Create requirements.txt
    TEMPLATE_REQ="${SCRIPT_DIR}/templates/requirements.txt"

    if [ "$SMOKE_MODE" = true ]; then
        print_smoke "Preview: requirements.txt"
        if [ -f "${TEMPLATE_REQ}" ] && [ -s "${TEMPLATE_REQ}" ]; then
            print_would "Copy from template: ${TEMPLATE_REQ}"
            print_would "Packages include: numpy, pandas, polars, duckdb, pyreadstat, pytest, black, ruff"
        else
            print_would "Create default requirements.txt with SAS migration dependencies"
        fi
    else
        print_info "Creating requirements.txt..."
        if [ -f "${TEMPLATE_REQ}" ] && [ -s "${TEMPLATE_REQ}" ]; then
            # Use template if it exists and is not empty
            cp "${TEMPLATE_REQ}" "${REPO_ROOT}/requirements.txt"
            print_success "Created requirements.txt from template"
        else
            # Create default requirements.txt
            cat > "${REPO_ROOT}/requirements.txt" <<EOF
# Core dependencies for SAS migration
numpy==2.4.5
pandas==3.0.1
pyreadstat==1.3.5
polars_readstat==0.23.1
polars==1.31.0
duckdb==1.5.2
ipykernel==7.3.0
matplotlib==3.11.2
seaborn>=0.13.0
pyarrow==25.0.1
pyyaml>=6.0.0
jinja2==3.1.6

# Testing dependencies
pytest>=7.0.0
pytest-cov>=4.0.0
faker>=28.0.0

# Development dependencies
pre-commit>=3.5.0
black>=24.8.0
ruff>=0.6.0
EOF
            print_success "Created requirements.txt"
        fi
    fi

    # Virtual environment setup
    echo ""
    read -p "Enter virtual environment name (default: .venv): " VENV_NAME
    VENV_NAME=${VENV_NAME:-.venv}
    VENV_PATH="${REPO_ROOT}/${VENV_NAME}"

    if [ "$SMOKE_MODE" = true ]; then
        print_smoke "Preview: Virtual environment"
        print_would "Create virtual environment at: ${VENV_PATH}"
        print_would "Using Python: ${PYTHON_BIN}"
        print_would "Upgrade pip, setuptools, wheel"
        print_would "Install all packages from requirements.txt"
        print_would "This would take ~2-5 minutes depending on network speed"
    else
        print_info "Creating virtual environment at ${VENV_PATH}..."
        "${PYTHON_BIN}" -m venv "${VENV_PATH}"
        print_success "Virtual environment created"

        # Activate and install
        print_info "Installing requirements..."
        source "${VENV_PATH}/bin/activate"
        pip install --upgrade pip setuptools wheel
        pip install -r "${REPO_ROOT}/requirements.txt"
        print_success "Requirements installed successfully"
    fi

    # Source directory setup
    echo ""
    read -p "Enter src folder name (default: sas_migration_${env_type}): " SRC_NAME
    SRC_NAME=${SRC_NAME:-sas_migration_${env_type}}
    SRC_PATH="${REPO_ROOT}/src/${SRC_NAME}"

    if [ "$SMOKE_MODE" = true ]; then
        print_smoke "Preview: Source directory structure"
        print_would "Create directory: ${SRC_PATH}/"
        print_would "Create __init__.py with project metadata"
        print_would "Create subdirectories:"
        echo "    - ${SRC_PATH}/utils/"
        echo "    - ${SRC_PATH}/converters/"
        echo "    - ${SRC_PATH}/validators/"
        print_would "Create ${REPO_ROOT}/tests/ directory"
    else
        print_info "Creating source directory: ${SRC_PATH}..."
        mkdir -p "${SRC_PATH}"

        # Create __init__.py
        cat > "${SRC_PATH}/__init__.py" <<EOF
"""
${PROJECT_NAME}
${PROJECT_DESC}
"""

__version__ = "${PROJECT_VERSION}"
__author__ = "${AUTHOR_NAME}"
__email__ = "${AUTHOR_EMAIL}"
EOF

        # Create module structure
        mkdir -p "${SRC_PATH}/utils"
        mkdir -p "${SRC_PATH}/converters"
        mkdir -p "${SRC_PATH}/validators"
        touch "${SRC_PATH}/utils/__init__.py"
        touch "${SRC_PATH}/converters/__init__.py"
        touch "${SRC_PATH}/validators/__init__.py"
        print_success "Source directory structure created"

        # Tests directory
        mkdir -p "${REPO_ROOT}/tests"
        cat > "${REPO_ROOT}/tests/__init__.py" <<EOF
"""Test suite for ${PROJECT_NAME}"""
EOF
    fi

    # Update .gitignore
    if [ "$SMOKE_MODE" = true ]; then
        print_smoke "Preview: .gitignore updates"
        if grep -q "# Python virtual environments" "${REPO_ROOT}/.gitignore" 2>/dev/null; then
            print_would "Skip (Python entries already exist in .gitignore)"
        else
            print_would "Append Python-specific entries to ${REPO_ROOT}/.gitignore"
            echo "    - Virtual environments (${VENV_NAME}/, .venv/, etc.)"
            echo "    - Python cache (__pycache__/, *.pyc, etc.)"
            echo "    - Distribution files (build/, dist/, *.egg-info/)"
            echo "    - Testing artifacts (.pytest_cache/, .coverage)"
            echo "    - IDE and OS files"
        fi
    else
        print_info "Updating .gitignore..."
        if ! grep -q "# Python virtual environments" "${REPO_ROOT}/.gitignore" 2>/dev/null; then
            cat >> "${REPO_ROOT}/.gitignore" <<EOF

# Python virtual environments
${VENV_NAME}/
.venv/
venv/
ENV/
env/

# Python cache
__pycache__/
*.py[cod]
*$py.class
*.so
.Python

# Distribution / packaging
build/
dist/
*.egg-info/
.eggs/

# Testing
.pytest_cache/
.coverage
htmlcov/
.tox/

# IDE
.vscode/
.idea/
*.swp
*.swo
*~

# OS
.DS_Store
Thumbs.db
EOF
        fi
        print_success ".gitignore updated"
    fi

    # Summary
    echo ""
    if [ "$SMOKE_MODE" = true ]; then
        echo -e "${CYAN}================================${NC}"
        echo -e "${CYAN}Python Setup Preview Complete${NC}"
        echo -e "${CYAN}================================${NC}"
        echo -e "${BLUE}Configuration Summary:${NC}"
        echo -e "  Python Version: ${PYTHON_VERSION}"
        echo -e "  Project: ${PROJECT_NAME} v${PROJECT_VERSION}"
        echo -e "  Virtual Environment: ${VENV_PATH}"
        echo -e "  Source Directory: ${SRC_PATH}"
        echo -e "  Author: ${AUTHOR_NAME} <${AUTHOR_EMAIL}>"
        echo ""
        echo -e "${YELLOW}No files were created or modified.${NC}"
        echo -e "${BLUE}To execute the actual setup, run without --smoke flag${NC}"
    else
        echo -e "${GREEN}================================${NC}"
        echo -e "${GREEN}Python Setup Complete!${NC}"
        echo -e "${GREEN}================================${NC}"
        echo -e "${BLUE}Python Version:${NC} ${PYTHON_VERSION}"
        echo -e "${BLUE}Virtual Environment:${NC} ${VENV_PATH}"
        echo -e "${BLUE}Source Directory:${NC} ${SRC_PATH}"
        echo -e "${BLUE}To activate:${NC} source ${VENV_NAME}/bin/activate"
    fi
    echo ""

    return 0
}

# If run directly
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    setup_python "$@"
fi
