#!/bin/bash

# Claude Configuration Setup Module
# Called by main setup script or can be run standalone

set -e

# Color codes
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
MAGENTA='\033[0;35m'
NC='\033[0m'

# Helper functions
print_success() { echo -e "${GREEN}✓ $1${NC}"; }
print_error() { echo -e "${RED}✗ $1${NC}"; }
print_warning() { echo -e "${YELLOW}⚠ $1${NC}"; }
print_info() { echo -e "${BLUE}ℹ $1${NC}"; }
print_smoke() { echo -e "${CYAN}🔍 [SMOKE] $1${NC}"; }
print_would() { echo -e "${MAGENTA}  → Would: $1${NC}"; }

# Get repo root
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# Strip duplicate path output (workaround for environment issue)
SCRIPT_DIR="${SCRIPT_DIR%%$'\n'*}"
REPO_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"
REPO_ROOT="${REPO_ROOT%%$'\n'*}"

setup_claude() {
    local env_type="$1"
    local mock_claude_dir="${SCRIPT_DIR}/templates/.mock_claude"
    local claude_dir="${REPO_ROOT}/.claude"

    if [ "$SMOKE_MODE" = true ]; then
        echo ""
        print_smoke "=== Claude Configuration Setup (Preview Mode) ==="
        print_would "Create .claude/ directory structure"
        print_would "Copy environment-specific configuration files"
        echo ""
    else
        echo ""
        print_info "Setting up Claude configuration..."
    fi

    # Determine which suffix to use
    local suffix=""
    case "$env_type" in
        python)
            suffix="_python"
            ;;
        r)
            suffix="_r"
            ;;
        python_r)
            suffix="_combined"
            ;;
        *)
            print_error "Invalid environment type: $env_type"
            return 1
            ;;
    esac

    if [ "$SMOKE_MODE" = true ]; then
        print_smoke "Using suffix: ${suffix}.md"
    fi

    # Create directory structure
    if [ "$SMOKE_MODE" = false ]; then
        mkdir -p "${claude_dir}/rules"
        mkdir -p "${claude_dir}/commands"
        mkdir -p "${claude_dir}/hooks"
        mkdir -p "${claude_dir}/skills"
    fi

    # Copy rules files with suffix removal
    if [ -d "${mock_claude_dir}/rules" ]; then
        for file in "${mock_claude_dir}/rules"/*${suffix}.md; do
            if [ -f "$file" ]; then
                local basename=$(basename "$file")
                local target_name="${basename//${suffix}.md/.md}"

                if [ "$SMOKE_MODE" = true ]; then
                    print_would "Copy: rules/${basename} → rules/${target_name}"
                else
                    cp "$file" "${claude_dir}/rules/${target_name}"
                fi
            fi
        done
    fi

    # Copy commands (if any exist with suffixes)
    if [ -d "${mock_claude_dir}/commands" ]; then
        for file in "${mock_claude_dir}/commands"/*${suffix}.md; do
            if [ -f "$file" ]; then
                local basename=$(basename "$file")
                local target_name="${basename//${suffix}.md/.md}"

                if [ "$SMOKE_MODE" = true ]; then
                    print_would "Copy: commands/${basename} → commands/${target_name}"
                else
                    cp "$file" "${claude_dir}/commands/${target_name}"
                fi
            fi
        done
    fi

    # Copy hooks (if any exist with suffixes)
    if [ -d "${mock_claude_dir}/hooks" ]; then
        for file in "${mock_claude_dir}/hooks"/*${suffix}.md; do
            if [ -f "$file" ]; then
                local basename=$(basename "$file")
                local target_name="${basename//${suffix}.md/.md}"

                if [ "$SMOKE_MODE" = true ]; then
                    print_would "Copy: hooks/${basename} → hooks/${target_name}"
                else
                    cp "$file" "${claude_dir}/hooks/${target_name}"
                fi
            fi
        done
    fi

    # Copy skills with suffix removal
    if [ -d "${mock_claude_dir}/skills" ]; then
        # Skills with suffixes (migration-validate, sas-analyze)
        for skill_dir in "${mock_claude_dir}/skills"/*; do
            if [ -d "$skill_dir" ]; then
                local skill_name=$(basename "$skill_dir")

                # Check if this skill has suffixed files
                if ls "${skill_dir}"/SKILL${suffix}.md 1> /dev/null 2>&1; then
                    if [ "$SMOKE_MODE" = true ]; then
                        print_would "Copy skill: ${skill_name}/ (using ${suffix} version)"
                    else
                        mkdir -p "${claude_dir}/skills/${skill_name}"
                        # Copy SKILL file
                        cp "${skill_dir}/SKILL${suffix}.md" "${claude_dir}/skills/${skill_name}/SKILL.md"

                        # Copy references directory if it exists
                        if [ -d "${skill_dir}/references" ]; then
                            mkdir -p "${claude_dir}/skills/${skill_name}/references"
                            # Copy all .md files, handling suffixes
                            for ref_file in "${skill_dir}/references"/*.md; do
                                if [ -f "$ref_file" ]; then
                                    local ref_basename=$(basename "$ref_file")
                                    # Check if file has the environment suffix
                                    if [[ "$ref_basename" == *${suffix}.md ]]; then
                                        local ref_target="${ref_basename//${suffix}.md/.md}"
                                        cp "$ref_file" "${claude_dir}/skills/${skill_name}/references/${ref_target}"
                                    elif [[ "$ref_basename" != *_python.md && "$ref_basename" != *_r.md && "$ref_basename" != *_combined.md ]]; then
                                        # Copy files without suffixes (common references)
                                        cp "$ref_file" "${claude_dir}/skills/${skill_name}/references/${ref_basename}"
                                    fi
                                fi
                            done
                        fi
                    fi
                fi
            fi
        done

        # Language-specific skills (no suffixes, copy entire directory)
        if [[ "$env_type" == "python" || "$env_type" == "python_r" ]]; then
            if [ -d "${mock_claude_dir}/skills/sas_to_python" ]; then
                if [ "$SMOKE_MODE" = true ]; then
                    print_would "Copy skill: sas_to_python/ (Python conversion)"
                else
                    cp -r "${mock_claude_dir}/skills/sas_to_python" "${claude_dir}/skills/"
                fi
            fi
        fi

        if [[ "$env_type" == "r" || "$env_type" == "python_r" ]]; then
            if [ -d "${mock_claude_dir}/skills/sas_to_r" ]; then
                if [ "$SMOKE_MODE" = true ]; then
                    print_would "Copy skill: sas_to_r/ (R conversion)"
                else
                    cp -r "${mock_claude_dir}/skills/sas_to_r" "${claude_dir}/skills/"
                fi
            fi
        fi
    fi

    if [ "$SMOKE_MODE" = true ]; then
        echo ""
        print_smoke "Claude configuration preview complete"
    else
        print_success "Claude configuration setup complete"
    fi

    return 0
}

# If run directly
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    setup_claude "$@"
fi
