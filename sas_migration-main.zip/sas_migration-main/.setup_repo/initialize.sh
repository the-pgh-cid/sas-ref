#!/bin/bash

# SAS Migration Repository Setup Script
# Main orchestration script with smoke test mode

set -e

# Color codes
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
MAGENTA='\033[0;35m'
NC='\033[0m'

# Helper functions
print_success() { echo -e "${GREEN}✓ $1${NC}"; }
print_error() { echo -e "${RED}✗ $1${NC}"; }
print_warning() { echo -e "${YELLOW}⚠ $1${NC}"; }
print_info() { echo -e "${BLUE}ℹ $1${NC}"; }
print_smoke() { echo -e "${CYAN}🔍 [SMOKE] $1${NC}"; }
print_would() { echo -e "${MAGENTA}  → Would: $1${NC}"; }

# Parse arguments
DRY_RUN=false
SMOKE_MODE=false

for arg in "$@"; do
    case $arg in
        --dry-run|--smoke|--test|-n)
            DRY_RUN=true
            SMOKE_MODE=true
            shift
            ;;
        --help|-h)
            echo "Usage: $0 [OPTIONS]"
            echo ""
            echo "Options:"
            echo "  --smoke, --dry-run, -n    Run in smoke test mode (preview actions)"
            echo "  --help, -h                Show this help message"
            echo ""
            echo "Smoke test mode shows what would be done without making changes."
            exit 0
            ;;
    esac
done

# Get script directory and repo root
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# Strip duplicate path output (workaround for environment issue)
SCRIPT_DIR="${SCRIPT_DIR%%$'\n'*}"
REPO_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"
REPO_ROOT="${REPO_ROOT%%$'\n'*}"

# Export smoke mode for child scripts
export SMOKE_MODE
export DRY_RUN

# Banner
if [ "$SMOKE_MODE" = true ]; then
    echo -e "${CYAN}================================${NC}"
    echo -e "${CYAN}🔍 SMOKE TEST MODE${NC}"
    echo -e "${CYAN}================================${NC}"
    echo -e "${YELLOW}Preview mode: No changes will be made${NC}\n"
fi

echo -e "${BLUE}================================${NC}"
echo -e "${BLUE}SAS Migration Repository Setup${NC}"
echo -e "${BLUE}================================${NC}\n"

if [ "$SMOKE_MODE" = true ]; then
    print_smoke "Repository root: ${REPO_ROOT}"
    print_smoke "Script directory: ${SCRIPT_DIR}"
    echo ""
fi

# Prompt for environment type
echo -e "${BLUE}Select the environment type to set up:${NC}"
echo "  1) Python only"
echo "  2) Python and R"
echo "  3) R/RStudio only"
echo ""

read -p "Enter your choice (1-3): " ENV_CHOICE

case $ENV_CHOICE in
    1)
        ENV_TYPE="python"
        print_info "Setting up Python environment only"
        ;;
    2)
        ENV_TYPE="python_r"
        print_info "Setting up Python and R environments"
        ;;
    3)
        ENV_TYPE="r"
        print_info "Setting up R/RStudio environment only"
        ;;
    *)
        print_error "Invalid choice. Exiting."
        exit 1
        ;;
esac

echo ""

if [ "$SMOKE_MODE" = true ]; then
    print_smoke "Environment type selected: ${ENV_TYPE}"
    echo ""
    print_info "=== Actions Preview ==="
    echo ""
fi

# Source and run appropriate setup modules
SETUP_SUCCESS=true

if [[ "$ENV_TYPE" == "python" || "$ENV_TYPE" == "python_r" ]]; then
    if [ -f "${SCRIPT_DIR}/setup_python.sh" ]; then
        source "${SCRIPT_DIR}/setup_python.sh"
        setup_python "$ENV_TYPE" || SETUP_SUCCESS=false
    else
        print_error "setup_python.sh not found!"
        SETUP_SUCCESS=false
    fi
fi

if [[ "$ENV_TYPE" == "r" || "$ENV_TYPE" == "python_r" ]]; then
    if [ -f "${SCRIPT_DIR}/setup_r.sh" ]; then
        source "${SCRIPT_DIR}/setup_r.sh"
        setup_r || SETUP_SUCCESS=false
    else
        print_error "setup_r.sh not found!"
        SETUP_SUCCESS=false
    fi
fi

# Setup Claude configuration
if [ -f "${SCRIPT_DIR}/setup_claude.sh" ]; then
    source "${SCRIPT_DIR}/setup_claude.sh"
    setup_claude "$ENV_TYPE" || SETUP_SUCCESS=false
else
    print_error "setup_claude.sh not found!"
    SETUP_SUCCESS=false
fi

# Final summary
echo ""
if [ "$SMOKE_MODE" = true ]; then
    echo -e "${CYAN}=====================================${NC}"
    echo -e "${CYAN}🔍 Smoke Test Complete!${NC}"
    echo -e "${CYAN}=====================================${NC}"
    echo -e "${YELLOW}This was a preview with your actual choices.${NC}"
    echo -e "${YELLOW}No files were created or modified.${NC}"
    echo ""
    echo -e "${BLUE}To run the actual setup with these settings:${NC}"
    echo "  $0"
    echo ""
elif [ "$SETUP_SUCCESS" = true ]; then
    echo -e "${GREEN}=====================================${NC}"
    echo -e "${GREEN}Repository Setup Complete!${NC}"
    echo -e "${GREEN}=====================================${NC}"
    echo -e "${BLUE}Repository Root:${NC} ${REPO_ROOT}"
    echo -e "${BLUE}Environment Type:${NC} ${ENV_TYPE}"
    echo ""
    echo -e "${YELLOW}Next Steps:${NC}"

    if [[ "$ENV_TYPE" == "python" || "$ENV_TYPE" == "python_r" ]]; then
        echo "  • Activate Python environment and start coding"
        echo "  • Run tests: pytest"
        echo "  • Format code: black src/"
    fi

    if [[ "$ENV_TYPE" == "r" || "$ENV_TYPE" == "python_r" ]]; then
        echo "  • Open RStudio or R console"
        echo "  • Load functions: source('R/utils.R')"
        echo "  • Run tests: testthat::test_dir('tests')"
    fi

    echo ""
    echo -e "${BLUE}Happy coding!${NC}"
else
    echo -e "${RED}=====================================${NC}"
    echo -e "${RED}Setup encountered errors!${NC}"
    echo -e "${RED}=====================================${NC}"
    echo -e "${YELLOW}Please review the errors above and try again.${NC}"
    exit 1
fi
